from pathlib import Path
import hashlib,json,re,shutil,zipfile

r=Path(__file__).parent;app=Path('/workspace/learning-tree');m=json.loads((r/'manifest.json').read_text());l=json.loads((r/'launch-log.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(app/'js/learn/node-prompt.js')==m['source_sha256']
assert all(q['status']=='completed' for q in l['authors']+l['graders'])
for a,q in m['authors'].items():
 for name,h in q['input_files_sha256'].items():
  assert sha(r/'writers'/a/name)==h
  assert sha(Path(q['neutral_dir'])/name)==h
 assert sha(r/'writers'/a/'lesson.txt')==q['lesson_sha256']
 packet_key=[x for x in l['authors'] if x['work_id']==a][0];assert packet_key['first_complete_sha256']==q['lesson_sha256']
for reader in m['orders']:
 d=Path(m['neutral_root'])/reader;assert sha(d/'packet.txt')==m['packet_sha256'][reader]
 for name in ['report.md','scores.json']:assert (d/name).read_bytes()==(r/'blind'/reader/name).read_bytes()
proof=json.loads((r/'split-proof.json').read_text());p=(r/'source/monolithic.txt').read_text();assert proof['original_sha256']==proof['reconstruction_sha256']==sha(r/'source/monolithic.txt')
assert ''.join(p[q['start']:q['end']] for q in proof['segments'].values())==p
struct=json.loads((r/'structural-audit.json').read_text());assert all(q['complete'] and q['questionsValid'] and all(not g['errors'] for g in q['graphs']) for q in struct.values())
keys=sum(len(re.findall(r'^\[(?:QUESTION|BONUS) \d+\]',(r/'writers'/a/'lesson.txt').read_text(),re.M)) for a in m['authors']);assert keys==19
(r/'completion-checks.json').write_text(json.dumps({'authors':4,'fresh_blind_graders':4,'all_jobs_confirmed_complete':True,'all_input_lesson_packet_hashes_valid':True,'all_four_pairings_balanced':True,'all_structure_checks_pass':True,'keys_checked':keys,'idea_2_tested':False,'production_prompt_unchanged':True},indent=2)+'\n')
shutil.copyfile('/workspace/build_node_skill_pilot.py',r/'build.py')
out=r/'experiment-records.zip';files=[p for p in sorted(r.rglob('*')) if p.is_file() and p.suffix!='.zip' and p.name!='archive.sha256']
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,'node-skill-pilot/'+str(p.relative_to(r)))
 for p in sorted(Path(m['neutral_root']).rglob('*')):
  if p.is_file():z.write(p,'node-skill-pilot/grading-packets/'+str(p.relative_to(m['neutral_root'])))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for reader in m['orders']:assert hashlib.sha256(z.read('node-skill-pilot/grading-packets/'+reader+'/packet.txt')).hexdigest()==m['packet_sha256'][reader]
(r/'archive.sha256').write_text(sha(out)+'  experiment-records.zip\n')
docs=app/'docs/experiments/node-skill-pilot';docs.mkdir(parents=True,exist_ok=True)
for name in ['README.md','aggregate.json','split-proof.json','completion-checks.json','experiment-records.zip','archive.sha256','content-audit.md','protocol.md']:shutil.copyfile(r/name,docs/name)
shutil.copytree(r/'source/skill',docs/'source/skill',dirs_exist_ok=True)
print(json.dumps({'report':str(docs/'README.md'),'archive_bytes':out.stat().st_size,'all_checks_pass':True,'app_prompt_unchanged':True},indent=2))
