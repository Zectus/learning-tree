from pathlib import Path
import hashlib,json,random,shutil,uuid

r=Path('/workspace/node-skill-pilot');r.mkdir(exist_ok=True);assert not list(r.iterdir())
source=Path('/workspace/learning-tree/js/learn/node-prompt.js')
assert hashlib.sha256(source.read_bytes()).hexdigest()=='f629442764c4a507f6a0dab6b1ea5551982ad1b9c52076d34746af9f21765ea8'
p=Path('/workspace/node-prompt-optimization/best-performing-prompt-limit-example.txt').read_text()
def heading(t):return p.index('\n\n'+t)+2
marks=[0,heading('HOW MANY QUESTIONS'),heading('OUTPUT FORMAT'),p.index('\n- Graphs,')+1,heading('LANGUAGE'),heading('DOCUMENT STRUCTURE'),heading('QUESTION CONSTRUCTION RULES ('),heading('FINAL REVIEW —'),len(p)]
names=['intro','planning','format','graphs','context','teaching','questions','review']
parts={name:p[a:b] for name,a,b in zip(names,marks,marks[1:])}
assert ''.join(parts[name] for name in names)==p
route='''\n\nWORKFLOW\nThis lesson skill is split into reference files. Before drafting, read references/planning.md, references/format.md, and references/teaching.md in full. Read references/graphs.md before creating or checking any graph. Read references/questions.md before drafting any question. Read references/review.md for the final read-through. Apply every relevant rule; the separate files organize the work, not lower its requirements. Work on your own; no delegated critique or feedback pass is part of this workflow.\n\n'''
skill='---\nname: write-node-lesson\ndescription: Write the assigned learning-tree node lesson.\n---\n\n'+parts['intro']+route+parts['context']
base=r/'source';base.mkdir();(base/'monolithic.txt').write_text(p);shutil.copyfile(source,base/'tested-template.js')
pack=base/'skill';(pack/'references').mkdir(parents=True);(pack/'SKILL.md').write_text(skill)
for name in ['planning','format','graphs','teaching','questions','review']:(pack/'references'/(name+'.md')).write_text(parts[name])
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
proof={'original_sha256':sha(base/'monolithic.txt'),'original_characters':len(p),'reconstruction_sha256':hashlib.sha256(''.join(parts[n] for n in names).encode()).hexdigest(),
       'segments':{n:{'start':a,'end':b,'characters':b-a,'sha256':hashlib.sha256(parts[n].encode()).hexdigest()} for n,a,b in zip(names,marks,marks[1:])},
       'additional_routing_text':route,'additional_skill_frontmatter':skill.split(parts['intro'])[0],
       'skill_entry_characters':len(skill),'modular_total_characters':len(skill)+sum(len(parts[n]) for n in ['planning','format','graphs','teaching','questions','review']),
       'note':'Every character of the original prompt is retained exactly once. Entry context is moved forward, and routing/frontmatter are added. Tests staged retrieval/packaging, not file-count alone or context eviction.'}
(r/'split-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
brief=Path('/workspace/node-prompt-optimization/round1/input/limit_intuition/context.txt').read_text();(r/'reader-context.txt').write_text(brief)
conditions=['monolithic','modular'];m={'node':'limit_intuition','conditions':conditions,'writer_model':'gpt-6.1-sol','writer_effort':'low','authors':{},'orders':{},'packet_sha256':{},'source_sha256':sha(base/'tested-template.js')}
for i,(condition,rep) in enumerate([('monolithic',1),('modular',1),('monolithic',2),('modular',2)],1):
 a=f'task_{i:02d}';neutral=Path('/workspace')/('lesson-author-'+uuid.uuid4().hex[:10]);neutral.mkdir()
 entry='input.txt' if condition=='monolithic' else 'SKILL.md'
 if condition=='monolithic':shutil.copyfile(base/'monolithic.txt',neutral/entry)
 else:
  shutil.copyfile(pack/'SKILL.md',neutral/entry);shutil.copytree(pack/'references',neutral/'references')
 archive=r/'writers'/a;shutil.copytree(neutral,archive)
 wrapper=f'Read {neutral/entry} in full, without truncation, and follow it to generate the complete requested lesson. You may read only that input and files it explicitly references. Save plain lesson text to {neutral/"lesson.txt"} (this file delivery replaces downloading). Do not inspect other lessons, reports or history. Work on your own, without subagents or external critique; retain your first complete output with the prompt’s own planning and self-check. Do not revise it from evaluator feedback. Final response: the saved path and the lesson-input filenames you actually read, in order; do not include internal reasoning.'
 m['authors'][a]={'node':'limit_intuition','condition':condition,'replicate':rep,'neutral_dir':str(neutral),'entry':entry,'entry_sha256':sha(neutral/entry),'input_files_sha256':{str(f.relative_to(neutral)):sha(f) for f in sorted(neutral.rglob('*')) if f.is_file()},'wrapper':wrapper}
order=list(m['authors']);random.Random(20261030).shuffle(order);m['writer_launch_order']=order
m['orders']={'reader_1':['task_01','task_02'],'reader_2':['task_02','task_03'],'reader_3':['task_04','task_01'],'reader_4':['task_03','task_04']}
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
rubric=Path('/workspace/node-prompt-optimization/lib/grading-instructions.txt').read_text().replace('three lessons','two lessons').replace('Lesson A, Lesson B, and Lesson C','Lesson A and Lesson B').replace(',"C":{same fields}','').replace('[["A"],["B"],["C"]]','[["A"],["B"]]').replace('all three overall scores','both overall scores')
(r/'grading-instructions.txt').write_text(rubric)
(r/'protocol.md').write_text('''# Small pilot: monolithic prompt versus skill-style files\n\nOnly idea 1 is tested. Four fresh GPT 6.1 Sol low writers: two per condition, same limit_intuition node and exact current coherent teaching content, Spanish output. First complete outputs only, no regeneration or quality selection. No author may delegate, receive evaluator feedback, or revise from it; idea 2 is expressly excluded. Author self-check already present in the original prompt remains in both conditions.\n\nMonolithic has one full input file. Modular has SKILL.md with topic/delivery/reader language/context plus a short file-routing workflow, and six references: planning, format, graphs, teaching, questions, final review. All original text is preserved verbatim and reconstructs byte-identically; metadata/routing is added and context is moved earlier. Thus this is a test of skill-style organization and staged retrieval, not a pure file-count intervention. Files read are recorded in author final responses. It does not measure automatic context removal or actual billed token savings.\n\nFreeze this plan, source hashes, launch order and all assignments before generation. Four fresh blind gpt-6-luna graders, fork none, no effort override. Exact prior five-criterion rubric adapted only from three to two labels. Each grader sees one output per condition, never the prompts or packaging identity. Two panels receive monolithic first, two modular first. Every output appears twice, once in each position; all four cross-condition output pairings occur once. Model scores do not measure human learning.\n\nSeparately verify every answer key, central reasoning, app parsing and graph expressions. Do not repair authored outputs or send feedback to authors. Aggregate equal-weight criteria, preserve raw judgments and preferences, flag arithmetic/factual errors transparently. This one-node two-output-per-condition pilot can identify promising differences or problems, not demonstrate broad superiority. Keep the app's production prompt unchanged.\n''')
print(json.dumps({'round':str(r),'launch_order':order,'authors':{a:{'entry':v['neutral_dir']+'/'+v['entry'],'wrapper':v['wrapper']} for a,v in m['authors'].items()},'proof':proof},indent=2))
