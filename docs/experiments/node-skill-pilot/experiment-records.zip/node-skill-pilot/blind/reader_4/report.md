# Evaluación de las lecciones

| Criterio | Lesson A | Lesson B |
|---|---:|---:|
| Claridad conceptual y motivación (20 %) | 9.6 | 9.6 |
| Andamiaje, ritmo y carga cognitiva (20 %) | 9.5 | 9.5 |
| Razonamiento trabajado y transferencia (20 %) | 9.7 | 9.6 |
| Preguntas y oportunidades de aprendizaje activo (20 %) | 9.5 | 9.6 |
| Corrección y precisión matemática (20 %) | 10.0 | 10.0 |
| **Total (promedio igualmente ponderado)** | **9.66** | **9.66** |

**Ranking:** empate entre A y B. **Confianza:** alta en la calidad de ambas; moderada en el empate, pues la pequeña diferencia entre sus fortalezas es una cuestión de preferencia pedagógica.

Las dos lecciones enseñan bien la idea central: el límite describe las salidas para entradas próximas y distintas del punto, por lo que no determina el valor de la función allí. Ambas comienzan con la misma función racional, muestran datos por ambos lados, explican el hueco gráfico y justifican el patrón al factorizar para obtener (f(x)=x+1) cuando (x\ne1). En ambas, la cancelación queda correctamente restringida a entradas distintas de 1; ninguna confunde una tabla finita con una demostración, y ninguna introduce herramientas fuera del alcance indicado.

La fortaleza principal de A es la explicación cuantitativa del ejemplo: (f(x)-2=x-1), así que la distancia de la salida a 2 es exactamente la distancia de la entrada a 1. Eso hace tangible cómo continuar el razonamiento más allá de las filas observadas. También ofrece transferencia local útil en el bonus sobre funciones que coinciden en un intervalo salvo en el punto, y distingue con precisión observación de conclusión en la tercera sección. Su debilidad menor es que la primera pregunta vuelve a evaluar una cancelación muy parecida a la del ejemplo; una pregunta de interpretación habría comprobado otra faceta de comprensión.

B tiene como rasgo más fuerte una secuencia fluida: la pregunta inicial pide interpretar una afirmación general de límite, la segunda separa valor y límite, y la tercera calibra exactamente qué puede concluirse de una tabla. Sus ejemplos son claros y las explicaciones de la tabla y la gráfica no prometen más de lo que esos medios muestran. Como debilidad menor, su razonamiento cuantitativo se expresa como una distancia que disminuye en la misma medida y luego como reducción del término cuadrado en el bonus; A hace esa relación más explícita en el ejemplo central. No es un error ni impide entender el concepto.

En aprendizaje activo, A ofrece algo más de variedad de transferencia en sus preguntas de práctica; B logra una progresión especialmente limpia entre interpretación, distinción y límites de la evidencia. Esa compensación no produce una diferencia material: cada pregunta es resoluble con lo enseñado y los distractores apuntan a confusiones pertinentes. Las respuestas están etiquetadas para el sistema y no hay señales de errores matemáticos sustantivos. A una persona que prefiera un vínculo algebraico explícito entre dos distancias podría resultarle más convincente A; quien prefiera preguntas iniciales de interpretación y una organización más lineal podría elegir B.
