# Evaluación comparativa

## Puntuaciones

| Criterio | Peso | Lección A | Lección B |
|---|---:|---:|---:|
| Claridad conceptual y motivación | 20% | 9.5 | 9.4 |
| Andamiaje, ritmo y carga cognitiva | 20% | 9.4 | 9.3 |
| Razonamiento trabajado y transferencia | 20% | 9.3 | 9.5 |
| Preguntas y oportunidades de aprendizaje activo | 20% | 9.4 | 9.4 |
| Corrección y precisión matemática | 20% | 10.0 | 10.0 |
| **Total (promedio igualmente ponderado)** | **100%** | **9.52** | **9.52** |

**Ranking:** empate entre A y B. **Confianza:** alta en que ambas son lecciones muy sólidas; media en el empate, porque sus ventajas dependen del estilo de aprendizaje.

## Evidencia y tradeoffs

Ambas lecciones construyen la idea con el mismo ejemplo útil: la función racional no está definida en (x=2), pero para (x\ne2) coincide con (x+2), y la distancia entre (f(x)) y 4 coincide con la distancia entre (x) y 2. Esto aporta una explicación que cubre todas las entradas cercanas permitidas y deja claro por qué una tabla finita solo sugiere un límite. Las dos también distinguen correctamente el límite del valor en el punto y de una aproximación numérica; sus preguntas de tabla advierten expresamente que los datos finitos no demuestran el comportamiento arbitrariamente cercano. No encontré errores matemáticos sustantivos.

A tiene una progresión conceptual algo más accesible: comienza con tabla y gráfico, introduce la notación del límite y luego usa la factorización para explicar el patrón. Su punto fuerte es integrar los tres objetos —valor en el punto, salida en una entrada concreta y límite— en una tabla comparativa explícita, seguida de un caso donde cambiar solo (h(3)) no altera el límite ni (h(3{,}01)). La debilidad más relevante es que su argumento algebraico decisivo aparece después de introducir la notación general; para lectores que quieran justificar la tendencia antes de nombrarla, esa secuencia puede sentirse ligeramente adelantada.

B presenta la factorización y la relación de distancias antes de definir la notación general, una elección especialmente buena para lectores que prefieren ver primero por qué funciona el ejemplo. Su punto fuerte es la transferencia: muestra gráficamente una función con un valor aislado (h(2)=1) y después formula que el límite puede coincidir con el valor, diferir o existir aunque no haya valor definido. También incluye una pregunta final que pide qué dato sí permitiría determinar (u(0)), reforzando con precisión que el límite por sí solo no lo fija. La debilidad principal es que la distinción entre valor, aproximación y límite queda más repartida en la prosa que en A; una tabla breve de síntesis podría ayudar a quien necesite comparar explícitamente esos tres conceptos.

El empate refleja compensaciones pequeñas, no una falla importante en ninguna lección. A es algo mejor como primera presentación organizada de las tres cantidades; B da prioridad al razonamiento algebraico temprano y ofrece una ilustración gráfica adicional del valor puntual. Un lector que necesita una síntesis comparativa probablemente preferirá A; quien aprende mejor viendo primero la justificación o el punto aislado en una gráfica puede preferir B.
