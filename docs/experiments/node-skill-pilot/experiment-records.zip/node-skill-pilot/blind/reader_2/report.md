# Evaluación comparativa

## Puntuaciones

| Criterio | Lección A | Lección B |
|---|---:|---:|
| Claridad conceptual y motivación | 9.3 | 9.5 |
| Andamiaje, ritmo y carga cognitiva | 9.3 | 9.4 |
| Razonamiento desarrollado y transferencia | 9.2 | 9.6 |
| Preguntas de aprendizaje activo | 9.0 | 9.2 |
| Corrección y precisión matemática | 10.0 | 10.0 |
| **Total (promedio)** | **9.36** | **9.54** |

**Clasificación:** B primero, A segundo. **Confianza:** alta.

## Evidencia y comparación

Ambas lecciones enseñan con precisión la idea central: el límite describe las salidas para entradas próximas y distintas del punto, y no determina por sí mismo el valor de la función allí. En ambas, la factorización justifica el patrón que sugieren los datos, se advierte que una tabla finita no demuestra un límite y se explica la limitación gráfica del círculo abierto. No encuentro errores matemáticos sustantivos.

La fortaleza principal de A es su recorrido directo y fácil de seguir. La tabla de (f(x)=(x^2-4)/(x-2)), la simplificación válida solo para (x\ne2), y la igualdad (f(x)-4=x-2) conectan observación, explicación y afirmación del límite. A también diferencia explícitamente el valor exacto (3.999), la aproximación numérica y el límite (4). Su debilidad más importante es que la transferencia queda algo más acotada: los ejemplos y preguntas se centran sobre todo en huecos y valores reasignados, y la mayoría de las preguntas comprueba una distinción ya explicada. Aun así, la práctica sobre los límites de lo que una tabla permite afirmar es pertinente y alcanzable.

B obtiene una ventaja pequeña por hacer más explícito qué información basta para razonar: señala que se consideran entradas del dominio próximas al punto, muestra con (f(x)-2=x-1) cómo acercar la salida cuanto haga falta y aclara que acercarse no exige que las salidas sean siempre distintas del destino. La tabla que separa las preguntas «¿cuánto vale (f(a))?» y «¿cuál es el límite?» ayuda a fijar la distinción. Su mejor oportunidad de transferencia es el bonus 2: dos funciones con las mismas salidas en un entorno perforado de (3) comparten el límite aunque difieran en el punto o fuera de ese entorno. La principal debilidad de B es una carga verbal algo mayor, en particular en la explicación general y en ese bonus; exige mantener presente la idea de entorno. Para el lector descrito, la explicación cercana y los ejemplos hacen esa demanda manejable.

Las preguntas de ambas lecciones son correctas, legibles y requieren aplicar las ideas a casos concretos. B ofrece una gama ligeramente más amplia, incluido el caso de funciones que coinciden cerca del punto y el de una función constante; A ofrece una buena secuencia de interpretación, valor en el punto y límites de la evidencia tabular. En ambas, las opciones múltiples dan práctica, aunque no incluyen explicación individual de las respuestas en el texto. Es una limitación menor frente a las explicaciones trabajadas de cada sección.

El total de B supera a A por 0.18 puntos, una diferencia pequeña que refleja mejor transferencia y precisión verbal, no una falla de enseñanza en A. Un lector que prefiera una progresión más breve y lineal podría preferir A; quien valore más los matices sobre qué datos locales determinan un límite probablemente preferirá B. En ambas, quedan solo detalles menores de mejora para este lector.
