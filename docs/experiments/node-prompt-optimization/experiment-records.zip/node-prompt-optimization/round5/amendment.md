# Prospective candidate amendment before generation

The untouched-node reserve and reader scopes were frozen before Round 3 scores. The initially prepared Round 5 candidate set was baseline/synthesis/guided. It was not run: zero authors launched, zero lessons or grades exist. That entire original plan remains in round5-original-plan with NOT-RUN.md.

Round 3 then provided transfer evidence: coherent led the baseline and synthesis means on all four topics, and beat baseline in 18 of 24 blind preferences; synthesis had a small mean lead in the earlier tuning round but did not retain it on new topics. The sensible candidate to carry into a confirmation test is therefore coherent. Before generating any additional-node lesson, replace synthesis with coherent, keeping baseline and guided. This is a transparent developmental selection using prior topics, not selection based on these still-unseen node outcomes. Guided remains unchanged and included regardless of its pending development grades. No source prompt, scope, rubric, output or grade was changed.

This replacement is an amendment to the earlier proposed candidate set, not an unchanged preregistration. It is recorded explicitly so a future report cannot claim that the final candidate set was fixed before Round 3 results. The untouched-node set itself was fixed earlier and is unchanged.
