# Round 5 untouched-node confirmation, amended before generation

Compare baseline/coherent/guided on sigma_notation, average_rate, projective_measurement, and wkb_tunneling. Scopes and prerequisites are unchanged from additional-holdouts.json, frozen before Round 3 outcomes. See amendment.md for the transparent replacement of synthesis by coherent using prior transfer evidence, before any generation on these nodes.

Two fresh first outputs per node/condition, all GPT 6.1 Sol low with fresh histories; 24 fresh writers and 24 fresh blind Luna panels, all six orders per node and three balanced-position ratings per output. No output reuse or quality selection. Same exact rubric, separate correctness audit, and no rewriting candidates from this round's outcomes within this round.

Report per-node scores and preferences, sample variability, factual defects, and verified review mistakes. An aggregate gain cannot conceal a substantial node-specific loss. Target is repeated 9.5+ with no important correctness/scope defect; these are model judgments, not measured human learning. No runtime fallback, topic-specific prompt instruction, fixed quota, or new application feature is part of this test.
