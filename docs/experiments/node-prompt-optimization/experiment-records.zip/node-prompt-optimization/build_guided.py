from pathlib import Path
import difflib, hashlib, json

base = Path('/workspace/node-prompt-optimization')
source = (base / 'variants/synthesis.js').read_text()
old = ('Let the reader complete one understandable use of the central idea before adding several qualifications, representations, or cases. '
       'Introduce notation and cautions where they first do useful work. State a limitation clearly once; return to it only when the next task needs a new distinction. '
       'If the opening carries too many new elements, distribute them across the progression rather than shortening the reasoning that makes the idea understandable.')
new = ('Let the reader complete one understandable use of the central idea before adding qualifications, representations, or cases. '
       'Teach the next unfamiliar step when its purpose is visible from the current problem, not several steps in advance. '
       'If a passage introduces a new representation and a new operation together, separate their first uses or work through their connection before compressing it. '
       'Give the reader a natural chance to attempt a newly learned step before shifting to another difficulty; an accessible first check can precede later integration. '
       'Introduce notation and cautions where they first do useful work. State a limitation clearly once; return to it only when the next task needs a new distinction. '
       'Simplify the sequence rather than removing the reasoning that makes it understandable.')
assert source.count(old) == 1
guided = source.replace(old, new)
start = guided.index('CONCISENESS. ')
end = guided.index('\n\nDISTRACTORS.', start)
guided = guided[:start] + ('CONCISENESS. State what is given and what is asked, with enough context to interpret the task. '
    'Remove repeated scene-setting and redundant notation. Keep a brief reference or tool cue when needed for an early check whose goal is application; '
    'remove it when choosing the tool is what the question tests. Keep values and options concise without deleting reasoning the reader is being asked to evaluate.') + guided[end:]
old = 'DISTRACTORS. Should be clearly wrong on reflection;'
new = ('DISTRACTORS. Base wrong options on plausible incomplete understanding or likely mistakes in this setup, while keeping them unambiguously wrong. '
       'Diagnose understanding rather than tricking the reader. Avoid wording or answer-length cues that reveal the key without using the lesson. '
       'They should be clearly wrong on reflection;')
assert guided.count(old) == 1
guided = guided.replace(old, new)
(base / 'variants/guided.js').write_text(guided)
(base / 'variants/guided.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True), guided.splitlines(True), fromfile='synthesis', tofile='guided')))
(base / 'variants/guided-manifest.json').write_text(json.dumps({'parent': 'synthesis', 'characters': len(guided), 'sha256': hashlib.sha256(guided.encode()).hexdigest()}, indent=2) + '\n')
