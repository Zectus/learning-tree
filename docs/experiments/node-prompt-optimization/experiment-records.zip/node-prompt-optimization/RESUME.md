# Study completed

Latest user request was to finish the current experiment and document all findings and the best prompt. This is complete: four grading rounds, 44 unique saved lessons, 60 fresh blind Luna graders, six nodes, 243 checked keys. See FINDINGS.md and study-results.json.

Round 4 grading and aggregate were saved before the usage limit; root read all reports and completed its manager notes. Round 3 independent content-audit.md was also fully saved before its agent hit the usage limit; all 24 files and 138 keys are covered. No new lessons or grades were fabricated during finalization. The four-node Round 5 never launched an author; original and amended unrun plans are preserved.

The selected exact variant is coherent, SHA f629442764c4a507f6a0dab6b1ea5551982ad1b9c52076d34746af9f21765ea8. It has been copied byte-for-byte into the app node-prompt.js. Best text/source/exact calculus input and all findings are exported. Application checks: 117/117; companion: 16/16. No runtime fallback added. Documentation is mirrored under learning-tree/docs/experiments/node-prompt-optimization.

Round 1 factual correction was made by the same grader and is preserved alongside originals. Round 3 same-grader adjudication did not happen before session interruption; keep its raw scores unchanged. Its verified false penalty is documented with an explicit upper-bound sensitivity calculation, which does not change the selected broad winner. Round 4 has another verified formula-absence oversight, also retained without rescoring.

Do not restart generation or grading merely because old manager status said failed: the saved current experiment is complete. Further experiments require a new active user instruction. All writer models in this study were explicitly GPT 6.1 Sol low; no outdated Sol substitution.
