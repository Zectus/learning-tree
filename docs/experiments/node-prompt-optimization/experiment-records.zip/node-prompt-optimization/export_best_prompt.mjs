import fs from 'node:fs';
import vm from 'node:vm';
import crypto from 'node:crypto';
const root = '/workspace/node-prompt-optimization';
const source = fs.readFileSync(root + '/best-performing-prompt.js', 'utf8');
const assembly = fs.readFileSync('/workspace/learning-tree/js/learn/prompts.js', 'utf8');
const start = assembly.indexOf('function buildPrompt(');
const end = assembly.indexOf('\n}', start) + 2;
const nodes = new Map([
  [1, {label: '{{NODE_TOPIC}}', slug: '{{NODE_ID}}', explanation: '{{NODE_SCOPE}}'}],
  [2, {label: '{{PREREQUISITE_LABEL}}', explanation: '{{PREREQUISITE_SCOPE}}'}],
  [3, {label: '{{LATER_TOPICS}}'}],
]);
const context = vm.createContext({state: {topic: '{{TREE_TOPIC}}', nodes}, uiLanguage: 'en',
  prereqsOf: () => [2], dependentsOf: () => [3], slugify: text => text});
vm.runInContext(source, context);
vm.runInContext(assembly.slice(start, end), context);
const prompt = vm.runInContext('buildPrompt(1, "{{OUTPUT_LANGUAGE}}")', context);
fs.writeFileSync(root + '/best-performing-prompt.txt', prompt);
const names = ['best-performing-prompt.js', 'best-performing-prompt.txt', 'best-performing-prompt-limit-example.txt', 'best-performing-prompt.diff'];
const manifest = {condition: 'coherent', source_is_byte_identical_to_tested_variant: true,
  reusable_text: 'Teaching instructions rendered through the existing app assembly, with context placeholders; not an additional experimental input.',
  exact_limit_example: 'Byte-identical to round1/writers/task_05/prompt.txt, the actual archived calculus writer input. The separate save-to-file task wrapper is recorded in the experiment launch log.',
  files: Object.fromEntries(names.map(name => {const bytes = fs.readFileSync(root + '/' + name); return [name, {bytes: bytes.length, characters: bytes.toString('utf8').length, sha256: crypto.createHash('sha256').update(bytes).digest('hex')}];}))};
fs.writeFileSync(root + '/best-prompt-manifest.json', JSON.stringify(manifest, null, 2) + '\n');
