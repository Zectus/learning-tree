# Addendum to the original manager notes

The original manager notes describe the initial, uncorrected evaluations. A verified factual grading mistake was subsequently sent to that same grader for a factual recheck, without revealing condition identities or asking for a broader reassessment. Original reports, scores and aggregate remain preserved. The grader confirmed that it had swapped output labels in baseline task_08 Bonus 1: b=-a gives output 1 with certainty under the supplied R, as the lesson correctly keys. It changed only that lesson’s correctness score from 8.5 to 10; the other four criteria and the reader’s preference ranking did not change.

Corrected overall means: baseline 9.4150, application 9.4533, coherent 9.5200. Corrected relative-phase means: baseline 9.3800, application 9.4033, coherent 9.4767. Limit means and all preference counts are unchanged. The coherent mean advantage over baseline is now 0.1050, rather than the larger uncorrected difference.

See adjudication.json and aggregate.pre-adjudication.json for provenance; current aggregate.json uses the same grader’s factual correction. This is not a discretionary rescore for a preferred outcome.
