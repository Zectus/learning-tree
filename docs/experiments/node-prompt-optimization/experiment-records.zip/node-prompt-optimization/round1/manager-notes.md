# Round 1 manager notes

All 12 independent writers completed in the manifest launch order, using gpt-6.1-sol with low effort and fresh histories. All 12 independent blind readers completed with fresh gpt-6-luna agents. At most four children were active. No lesson was regenerated, no evaluation was authored by the coordinator, and no prompt, lesson, result, criterion, or assignment was edited. prepare.py ran exactly once after writer completion; aggregate.py validated frozen hashes and assignments. No arithmetic discrepancies were reported. Model/task settings are in launch-log.json.

## Aggregate findings

| Scope | Baseline | Application | Coherent |
|---|---:|---:|---:|
| Overall | 9.3900 | 9.4533 | 9.5200 |
| Informal limits | 9.4500 | 9.5033 | 9.5633 |
| Relative phase | 9.3300 | 9.4033 | 9.4767 |

Coherent received four of six first-place votes for limits; application and baseline received one each. Coherent beat application 5–1 and baseline 4–2 in paired limit comparisons. Application beat baseline 5–1. For relative phase, coherent and application each received three first-place votes, and their pairwise comparison split 3–3. Coherent beat baseline 5–0 with one tie; application beat baseline 4–2. These preferences and totals remain the original evaluations, including the review mistake documented below.

## Recurring teaching findings

Across the six limits reports, reviewers valued a connected progression from a two-sided table and graph with a missing point to cancellation restricted to the allowed domain, then to a reason the nearby behavior persists. The distance identity was repeatedly useful. For example, task_05 explicitly derives f(x)-4=x-2, explains equal input/output distances, separates g(2)=9 from limit 4, and adds a constant-7 example showing that outputs may already equal their limit. Reviewers often credited this additional distinction to the coherent lessons. They also praised exact evaluation versus numerical approximation versus an exact limit statement, and questions that require identifying what finite data cannot establish. Baseline task_01's narrower-neighborhood counterexample, which equals 6 within distance 0.001 of the center despite matching the supplied measurements elsewhere, was repeatedly singled out as strong active reasoning.

The limits weaknesses were modest and often involved tradeoffs: additional distinctions and bonus practice could accumulate cognitive load; a compact section on finite tables could provide less guided reasoning; a general statement could omit an explicit domain qualification even though its example made the intention clear. Reviewers disagreed about whether more repetition improved consolidation or made the path longer. The graph format's inability to display an open circle was generally treated as adequately explained in text, rather than a mathematical defect.

Across the phase reports, reviewers valued the operational puzzle that plus/minus states have identical direct probabilities but opposite certain outputs after the supplied recombination matrix. Worked complex amplitudes and unequal-magnitude extensions were common transfer strengths, especially P(0)=1/2+rs cos(phi) and explanations of incomplete cancellation for unequal contributions. Unit-circle graphs helped connect Euler's formula to phase; unequal-magnitude sliders helped show the probability range. Questions distinguishing global phase equivalence from merely matching one device's output distribution received repeated praise. The reports also valued explicit repeated-preparation statistics and cautions against inferring a trajectory.

The main phase weakness was sequencing and density. Some definitions-first lessons introduced Euler's formula, phase factoring, component ratios, and zero-component qualifications before the recombination experiment made their purpose concrete. Some example-first lessons postponed formal terminology. Several reviewers found that adding phase identifiability, unequal magnitudes, and bonus extensions made a long sequence, while others rewarded that same breadth. Application versus coherent preferences split evenly for this node, so the mean-score edge is not a decisive preference result between those two conditions.

## Verified review mistake

relative_phase__reader_6 incorrectly penalized packet C (baseline task_08) for Bonus 1. The lesson specifies R(a,b)=(a+b,a-b)/sqrt(2), with the first component outcome 0 and second outcome 1. Bonus 1 asks for outcome 1 with probability one and keys E: b=-a and |a|=1/sqrt(2). That key is correct: a+b=0 and |a-b|^2/2=1. The report reverses the condition, asserting that outcome 1 requires a-b=0 and b=a. That condition instead gives outcome 0 with certainty. The lesson's opening worked sign examples also explicitly establish the correct labeling. The review's 8.5 correctness score and conclusion that the key has a substantive reversal are therefore unsupported. No grades or preferences were changed or rescored. This mistake may affect the observed baseline disadvantage; the experiment does not quantify a corrected result.

No other substantive review error was verified in the targeted lesson checks. All reports were read; the coordinator did not independently regrade all lessons.

## Implications and limits

The observed coherent advantage is small: about 0.13 over baseline and 0.067 over application on the ten-point scale. All overall means exceed 9.3. These high scores indicate minor remaining weaknesses according to this rubric and these readers; they do not establish human learning. There are only two author samples per condition per node, with repeated reviews of the same samples. Reader variability, author-sample variability, near-ceiling scores, and the verified grading error limit causal interpretation. The evidence supports retaining the connected reasoning and transfer patterns as promising for a future test, while preserving the observed disagreements about density and sequencing. It does not establish a universal winner across topics or learners.
