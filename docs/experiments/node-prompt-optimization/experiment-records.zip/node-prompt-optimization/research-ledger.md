# Prompt optimization ledger

Fixed writer model: GPT 6.1 Sol low. Baseline source: English current app node template after Spanish-template removal, semantically the historical Oct 12 English template. No API model substitution. All outputs fresh unless a round explicitly declares byte-identical reused references before grading. No output selection after seeing quality.

Initial hypotheses, before pilot results:
- Application candidate: a concrete meaningful use, followed by independently achievable use, may improve transfer without losing the integrated Oct 12 exposition.
- Coherence candidate: pacing protection and repairs to contradictory scaffolding/answer-leakage/graph rules may prevent overpacked openings and make initial checks accessible without replacing meaningful later transfer.
- Mixing both may outperform either, but each intervention must first be observed rather than assumed helpful.

Pilot round 1: limit_intuition and relative_phase; two generations per condition (baseline/application/coherent), six blind Luna panels per node, all orders. This gives three ratings per generation in distinct positions. Same criterion definitions and high-score anchors throughout subsequent rounds. Every source version and exact rendered input is archived.

Preselected held-outs: one_sided_limits and bra_ket_notation for accessible transfer beyond tuning nodes; chain_rule and partial_trace for a procedural method and a substantially more abstract operation. sigma_notation is available as an additional beginner stress test. Scope/background are fixed from the existing trees, never adjusted to make an output easier to grade.

Gate for app adoption: repeatable improvements over the baseline on tuning and new nodes; no important correctness/scope regression; preserve parser contract; independently audit concrete calculations/questions. A tiny single-panel win is not enough. Target is repeated scores >=9.5 with no substantive remaining defect; model scores do not establish actual human-learning perfection. If improvement fails to reproduce, retain app baseline and state the evidence honestly rather than ship an unverified prompt.

Runtime fallbacks, model substitutions, topic-specific teaching instructions, rigid section/question/word quotas, and changes to the reader's prerequisite background are outside the optimization. Existing feedback constraints may be clarified to permit teaching general principles on different cases without exposing a question's particular solution.

The user authorized sustained autonomous experimentation, iteration and subagents. This ledger is descriptive research planning, not an approval requirement.


Resumed October 30: all four new Round 2 lessons survived the usage interruption; no writer regenerated. Task_06 final agent message cannot be recovered, but its complete first output was present and parser-valid. Round 2 uses fresh Luna graders, fork none, with no effort override; resolved inherited grader effort is not exposed, so cross-round absolute scores must be interpreted cautiously. Round 3 candidate set frozen before Round 2 results: baseline/coherent/synthesis on the four preselected hold-outs, two fresh generations each; all six blind orders.

Round 4 guided hypothesis frozen before Round 3 results: synthesis plus explicit staging of unfamiliar operations/representations, a conciseness-versus-scaffolding consistency repair, and plausible misconception-based distractors. Two original tuning nodes; eight declared fixed references, four fresh guided samples, twelve fresh blind panels. No claim that this candidate is better until compared; no app changes.

Additional untouched-node reserve frozen before Round 3 results and before Round 4 generation: sigma_notation, average_rate, projective_measurement, wkb_tunneling. Exact existing scopes/prerequisites archived in additional-holdouts.json; intended to span two beginner topics and two more demanding quantum procedures, not selected from unseen lesson quality. A subsequent candidate-selection decision can use development evidence, but these reader backgrounds must not be softened.

Round 5 candidate set frozen before Round 3 teaching outcomes and before any Round 4 lesson completes: baseline/synthesis/guided on all four additional reserves, two fresh outputs each. Planned confirmation is independent of whether the newer guided variant wins its development test; no candidate excluded after seeing unfavorable evidence.

Round 5 PROSPECTIVE AMENDMENT before any new-reserve author launch: replace synthesis with coherent, which led all four Round 3 transfer means and beat baseline 18–6. Original unrun plan archived intact as round5-original-plan/NOT-RUN.md. Additional node set/scopes, rubric, baseline and guided sources unchanged; no additional-node outcome was available. This candidate-set amendment uses prior developmental selection and is not represented as the original untouched preregistration. See round5/amendment.md.

FINALIZED: four completed grading rounds, 44 unique outputs, 60 fresh blind panels, six nodes and 243 checked keys. Round 4 aggregation survived the limit; root completed notes and exports. Round 3 audit report fully saved despite later agent error. Round 5 has zero authors/lessons/grades and remains unrun. Exact coherent source selected and applied byte-for-byte to app; six-node direct comparison 9.5044 vs 9.4122, preferences 27–8 with one tie. Human-learning perfection was not established. App 117/117 and companion 16/16 checks pass; one overly broad Continue-word test was narrowed to actual batch commands.
