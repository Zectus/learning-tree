from pathlib import Path
from collections import Counter
import json,hashlib,shutil,statistics,itertools,re,sys
r=Path(sys.argv[1]);m=json.loads((r/'manifest.json').read_text());n=Path(m['neutral_root']);keys=['conceptual_clarity','scaffolding','worked_reasoning_transfer','active_learning','correctness'];readers={};ratings={a:[] for a in m['authors']};arithmetic=[]
for reader,order in m['orders'].items():
 assert hashlib.sha256((n/reader/'packet.txt').read_bytes()).hexdigest()==m['packet_sha256'][reader]
 for f in ['report.md','scores.json']:shutil.copyfile(n/reader/f,r/'blind'/reader/f)
 d=json.loads((n/reader/'scores.json').read_text());assert set(d['scores'])==set('ABC');assert sorted(x for g in d['ranking'] for x in g)==list('ABC')
 scores={}
 for pos,(label,a) in enumerate(zip('ABC',order),1):
  q=d['scores'][label];assert all(isinstance(q[k],(int,float)) and 0<=q[k]<=10 for k in keys);v=statistics.mean(q[k] for k in keys)
  if abs(v-q['overall'])>.051:arithmetic.append({'reader':reader,'label':label,'reported':q['overall'],'calculated':v})
  scores[a]={**q,'overall':v};ratings[a].append({'reader':reader,'position':pos,**scores[a]})
 readers[reader]={'node':m['reader_nodes'][reader],'order':order,'scores':scores,'ranking':[[order['ABC'.index(x)] for x in g] for g in d['ranking']],'confidence':d['confidence'],'decisive_tradeoff':d['decisive_tradeoff']}
samples={}
for a,meta in m['authors'].items():
 p=r/'writers'/a/'lesson.txt';text=p.read_text();assert hashlib.sha256(p.read_bytes()).hexdigest()==meta['lesson_sha256'];assert hashlib.sha256((p.parent/'prompt.txt').read_bytes()).hexdigest()==meta['prompt_sha256']
 assert len(ratings[a])==6/m['config']['replicates'];assert len(set(q['position'] for q in ratings[a]))==len(ratings[a])
 samples[a]={**meta,'means':{k:statistics.mean(q[k] for q in ratings[a]) for k in keys+['overall']},'ratings':ratings[a],'structure':{'characters':len(text),'sections':len(re.findall(r'^=== ',text,re.M)),'main_questions':len(re.findall(r'\[QUESTION \d+\]',text)),'bonus_questions':len(re.findall(r'\[BONUS \d+\]',text)),'graphs':text.count('[GRAPH]')}}
by_node={}
for node in m['nodes']:
 row={}
 for c in m['conditions']:
  members=[v for v in samples.values() if v['node']==node and v['condition']==c];v=[q['means']['overall'] for q in members]
  row[c]={'means':{k:statistics.mean(q['means'][k] for q in members) for k in keys+['overall']},'sample_means':v,'first_place_votes':sum(any(m['authors'][a]['condition']==c for a in z['ranking'][0]) for z in readers.values() if z['node']==node)}
 by_node[node]=row
pairwise=[]
for node in m['nodes']:
 for c1,c2 in itertools.combinations(m['conditions'],2):
  win=tie=loss=0
  for v in readers.values():
   if v['node']!=node:continue
   rank={m['authors'][a]['condition']:i for i,g in enumerate(v['ranking']) for a in g};win+=rank[c1]<rank[c2];tie+=rank[c1]==rank[c2];loss+=rank[c1]>rank[c2]
  pairwise.append({'node':node,'a':c1,'b':c2,'a_wins':win,'ties':tie,'b_wins':loss})
overall={c:statistics.mean(row[c]['means']['overall'] for row in by_node.values()) for c in m['conditions']};result={'overall':overall,'by_node':by_node,'samples':samples,'readers':readers,'pairwise':pairwise,'arithmetic_discrepancies':arithmetic};(r/'aggregate.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'overall':overall,'by_node':by_node,'pairwise':pairwise,'arithmetic_discrepancies':arithmetic},indent=2))
