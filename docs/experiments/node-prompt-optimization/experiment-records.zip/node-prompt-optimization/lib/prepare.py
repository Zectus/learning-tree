from pathlib import Path
from collections import Counter
import json,hashlib,itertools,random,sys,uuid,shutil
r=Path(sys.argv[1]);p=r/'manifest.json';m=json.loads(p.read_text());conditions=m['conditions'];perms=list(itertools.permutations(conditions))
if 'orders' not in m:
 orders={};reader_nodes={}
 for node in m['nodes']:
  candidates={}
  for c in conditions:
   positions=[[i for i,row in enumerate(perms) if row.index(c)==j] for j in range(3)]
   assignments=[]
   if m['config']['replicates']==2:
    for first in itertools.product(*positions):assignments.append({i:(1 if i in first else 2) for i in range(6)})
   elif m['config']['replicates']==3:
    def pairings(xs):
     if not xs:yield [];return
     for k in range(1,len(xs)):
      for rem in pairings(xs[1:k]+xs[k+1:]):yield [(xs[0],xs[k])]+rem
    for pairs in pairings(list(range(6))):
     if all(perms[a].index(c)!=perms[b].index(c) for a,b in pairs):assignments.append({i:k+1 for k,pair in enumerate(pairs) for i in pair})
   else:raise ValueError('Use 2 or 3 replications')
   candidates[c]=assignments
  best=None
  for combo in itertools.product(*(candidates[c] for c in conditions)):
   selection={c:q for c,q in zip(conditions,combo)};triples=[tuple((c,selection[c][i]) for c in conditions) for i in range(6)];score=6-len(set(triples))
   pairlist=[tuple(sorted(z)) for row in triples for z in itertools.combinations(row,2)];counts=Counter(pairlist);score=score*100+sum(max(0,v-2) for v in counts.values())
   if best is None or score<best[0]:best=(score,selection)
   if score==0:break
  by={(v['condition'],v['replicate']):a for a,v in m['authors'].items() if v['node']==node}
  for i,perm in enumerate(perms):
   name=node+'__reader_'+str(i+1);orders[name]=[by[(c,best[1][c][i])] for c in perm];reader_nodes[name]=node
 m['orders']=orders;m['reader_nodes']=reader_nodes
 launch=[a for a,q in m['authors'].items() if not q.get('reused_from')];random.Random(411).shuffle(launch);m['writer_launch_order']=launch
 p.write_text(json.dumps(m,indent=2)+'\n')
if '--plan' in sys.argv:print(json.dumps({'writers':len(m['authors']),'graders':len(m['orders']),'orders':m['orders']},indent=2));sys.exit()
assert 'neutral_root' not in m,'Packets already prepared; do not silently rerun'
n=Path('/workspace')/('lesson-eval-'+uuid.uuid4().hex[:8]);n.mkdir();m['neutral_root']=str(n);m['packet_sha256']={}
for a,meta in m['authors'].items():
 f=r/'writers'/a/'lesson.txt';assert f.exists() and f.stat().st_size>0;meta['lesson_sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
for reader,order in m['orders'].items():
 d=n/reader;d.mkdir();(r/'blind'/reader).mkdir(parents=True);text=(r/'input'/m['reader_nodes'][reader]/'context.txt').read_text()
 for label,a in zip('ABC',order):text+='\n\nLESSON '+label+'\n\n'+(r/'writers'/a/'lesson.txt').read_text()
 (d/'packet.txt').write_text(text);shutil.copyfile('/workspace/node-prompt-optimization/lib/grading-instructions.txt',d/'instructions.txt');m['packet_sha256'][reader]=hashlib.sha256((d/'packet.txt').read_bytes()).hexdigest()
p.write_text(json.dumps(m,indent=2)+'\n');print(n)
