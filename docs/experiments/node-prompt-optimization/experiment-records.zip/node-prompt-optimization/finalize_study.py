from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import shutil
import statistics

B = Path('/workspace/node-prompt-optimization')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
rounds = {}
unique = {}
checks = {}
for name in ['round1', 'round2', 'round3', 'round4']:
    r = B / name
    m = json.loads((r / 'manifest.json').read_text())
    d = json.loads((r / 'aggregate.json').read_text())
    neutral = Path(m['neutral_root'])
    for a, meta in m['authors'].items():
        p = r / 'writers' / a / 'lesson.txt'
        assert sha(p) == meta['lesson_sha256']
        assert sha(p.parent / 'prompt.txt') == meta['prompt_sha256']
        assert sha(Path(m['config']['variants'][meta['condition']])) == meta['variant_sha256']
        unique.setdefault(sha(p), {'round': name, 'author': a, 'node': meta['node'],
                                  'condition': meta['condition'], 'lesson_sha256': sha(p),
                                  'main': len(re.findall(r'^\[QUESTION \d+\]', p.read_text(), re.M)),
                                  'bonus': len(re.findall(r'^\[BONUS \d+\]', p.read_text(), re.M))})
    for reader, order in m['orders'].items():
        assert sha(neutral / reader / 'packet.txt') == m['packet_sha256'][reader]
        for f in ['report.md', 'scores.json']:
            assert (neutral / reader / f).is_file()
            assert sha(neutral / reader / f) == sha(r / 'blind' / reader / f)
        labels = json.loads((neutral / reader / 'scores.json').read_text())
        assert sorted(x for group in labels['ranking'] for x in group) == list('ABC')
        assert set(labels['scores']) == set('ABC')
    for node in m['nodes']:
        for condition in m['conditions']:
            rows = [v for v in m['authors'].values() if v['node'] == node and v['condition'] == condition]
            assert len(rows) == 2
            assert len({v['prompt_sha256'] for v in rows}) == 1
    structural = json.loads((r / 'structural-audit.json').read_text())
    assert len(structural) == len(m['authors'])
    assert all(q['complete'] and q['questionsValid'] and all(not g['errors'] for g in q['graphs']) for q in structural.values())
    rounds[name] = {'overall': d['overall'],
                    'by_node': {node: {c: q['means']['overall'] for c, q in rows.items()} for node, rows in d['by_node'].items()},
                    'pairwise': d['pairwise'], 'arithmetic_discrepancies': d['arithmetic_discrepancies'],
                    'new_lessons': sum(not q.get('reused_from') for q in m['authors'].values()),
                    'blind_panels': len(m['orders'])}
    checks[name] = {'lesson_slots': len(m['authors']), 'blind_panels': len(m['orders']),
                    'prompt_lesson_packet_hashes_valid': True, 'copied_reports_match': True,
                    'within_condition_prompts_identical': True, 'balanced_assignments_previously_validated': True,
                    'all_structure_and_graph_expression_checks_pass': True}

pooled = {}
for condition in ['baseline', 'coherent']:
    vals = [q[condition] for name in ['round1', 'round3'] for q in rounds[name]['by_node'].values()]
    pooled[condition] = statistics.mean(vals)
preferences = Counter()
for name in ['round1', 'round3']:
    for q in rounds[name]['pairwise']:
        if {q['a'], q['b']} != {'baseline', 'coherent'}:
            continue
        preferences['coherent_wins'] += q['a_wins'] if q['a'] == 'coherent' else q['b_wins']
        preferences['baseline_wins'] += q['b_wins'] if q['a'] == 'coherent' else q['a_wins']
        preferences['ties'] += q['ties']

# This is an explicit hypothetical bound, not a changed grade.
raw = json.loads((B / 'round3/aggregate.pre-adjudication.json').read_text())
maximum_rating_increase = ((10 - 9.2) + (10 - 8.8)) / 5
sensitivity = {
    'status': 'raw grades retained; same-grader factual adjudication not completed before usage interruption',
    'disputed_reader': 'chain_rule__reader_5', 'label': 'B', 'author': 'task_08',
    'raw_correctness': 9.2, 'raw_active_learning': 8.8,
    'hypothetical': 'Set only these two affected criteria to their maximum 10; keep other criteria fixed. This is an upper bound, not a rescore.',
    'maximum_increase_in_single_rating': maximum_rating_increase,
    'round3_raw_baseline': raw['overall']['baseline'],
    'round3_hypothetical_maximum_baseline': raw['overall']['baseline'] + maximum_rating_increase / 6 / 4,
    'round3_coherent_unchanged': raw['overall']['coherent'],
    'six_node_baseline_hypothetical_maximum': pooled['baseline'] + maximum_rating_increase / 6 / 6,
    'six_node_coherent_unchanged': pooled['coherent'],
    'affected_reader_raw_overall': 9.22, 'affected_reader_hypothetical_maximum_overall': 9.22 + maximum_rating_increase,
    'other_reader_overalls': [9.64, 9.72],
    'conclusion': 'Coherent remains ahead on the affected node and pooled comparisons; even the maximum adjusted B total remains below both alternatives in that panel.'}
(B / 'round3/adjudication-sensitivity.json').write_text(json.dumps(sensitivity, indent=2) + '\n')
p = B / 'round3/adjudication-pending.json'
pending = json.loads(p.read_text())
pending['status'] = 'closed without rescoring: usage interruption ended the old grader session; factual error documented, original grades retained, explicit sensitivity bound saved'
p.write_text(json.dumps(pending, indent=2) + '\n')

best = B / 'variants/coherent.js'
shutil.copyfile(best, B / 'best-performing-prompt.js')
shutil.copyfile(B / 'variants/coherent.diff', B / 'best-performing-prompt.diff')
shutil.copyfile(B / 'round1/writers/task_05/prompt.txt', B / 'best-performing-prompt-limit-example.txt')
assert sha(best) == 'f629442764c4a507f6a0dab6b1ea5551982ad1b9c52076d34746af9f21765ea8'
assert sha(B / 'best-performing-prompt.js') == sha(best)
assert sha(B / 'best-performing-prompt-limit-example.txt') == sha(B / 'round1/writers/task_05/prompt.txt')

totals = {'unique_lessons': len(unique), 'fresh_blind_panels': sum(q['blind_panels'] for q in rounds.values()),
          'unique_nodes': len({q['node'] for q in unique.values()}),
          'main_keys_checked': sum(q['main'] for q in unique.values()),
          'bonus_keys_checked': sum(q['bonus'] for q in unique.values()),
          'unique_lessons_by_round': dict(Counter(q['round'] for q in unique.values()))}
result = {'totals': totals, 'rounds': rounds,
          'best_supported_general_candidate': 'coherent',
          'six_node_direct_comparison': {'means': pooled, 'coherent_advantage': pooled['coherent'] - pooled['baseline'],
                                         'panel_preferences': dict(preferences),
                                         'rounds_used': ['round1', 'round3'],
                                         'note': 'Equal node weights; each node has two independent author outputs per condition. Repeated reviews in rounds 2/4 excluded from this pooled comparison.'},
          'round3_false_penalty_sensitivity': sensitivity,
          'unique_lesson_manifest': list(unique.values()),
          'unrun': {'round5': '24 planned authors and 24 panels; zero authors launched, zero lessons, zero grades',
                    'round5_original_plan': 'superseded before generation; no outputs or grades'},
          'application_changed': Path('/workspace/learning-tree/js/learn/node-prompt.js').read_bytes() == best.read_bytes()}
(B / 'study-results.json').write_text(json.dumps(result, indent=2) + '\n')
(B / 'completion-checks.json').write_text(json.dumps({'rounds': checks, 'totals': totals, 'best_source_matches_tested_candidate': True,
                                                    'exact_limit_example_matches_archived_writer_input': True,
                                                    'app_prompt_matches_selected_source': result['application_changed']}, indent=2) + '\n')
print(json.dumps({'totals': totals, 'six_node_comparison': result['six_node_direct_comparison'], 'all_checks_pass': True}, indent=2))
