# Round 4 content check

Root separately checked the two new phase lessons, task_11 and task_12, against the neutral scope brief. This is a content audit, not an independent blind teaching-quality grade. All eight main and four bonus keys are uniquely correct.

Task_11: a common factor -1 gives the keyed equivalent column. Recombination of (1,-2)/sqrt(5) gives probabilities (1/10,9/10). The complex-phase question has relative angle pi/3 and probability 3/4. The two candidate preparations in Q4 have distinct but overlapping R distributions. The lower-component phase setting pi/2 aligns i with i; the unequal-magnitude maximum is (2+sqrt(3))/4.

Task_12: recombination of (3,4)/5 gives (49/50,1/50). A common factor -i gives the keyed equivalent column. The general probability in Q3 is 1/2+(sqrt(3)/4)cos(phi). States (1,+/-i)/sqrt(2) are not globally equivalent but share direct and R probabilities. The unequal-magnitude minimum is 1/5; P(0)=1/4 implies cos(phi)=-1/2 with unrestricted global phase.

Both lessons explicitly supply R, show matrix action and Born probabilities, explain Euler notation and global-versus-relative phase, and avoid trajectory or intermediate-measurement assumptions. Questions on unequal magnitudes are solvable with the established R and complex arithmetic even where the fully general unequal-magnitude formula is left to the learner. Their pedagogical sufficiency is left to the blind readers. No substantive mathematical or scope error found.

The eight fixed references retain their previous content audits. The new limits lessons will be checked after their writers finish.

## New limits lessons complete

Root checked task_05 and task_06 completely. All six main and four bonus keys are uniquely defensible; no substantive mathematical/scope error was found.

Task_05 uses f(x)-2=x-1 only for x != 1, and interprets missing/changed point values independently of the limit. Main keys B,D,C follow from limit 3, invariance under one-point modification, and finite-data insufficiency. Bonus keys E,A follow from limit 4 for 4+x^2 and cancellation giving x+2 off 2.

Task_06 derives the absolute-distance identity and explains absolute-value notation; its strict output-error example is correct. Main keys C,B,D follow from limit -1, changes at the center and a fixed distant point leaving a neighborhood unchanged, and the finite-sample-compatible rule taking value 9 at every unmeasured point. Bonus keys A,E follow from error 0.003 at input 4.001 and the incompatibility of an all-nearby constant-11 rule with limit 12. Both lessons preserve the informal scope, treat tables as suggestive rather than proof, and explain the missing-circle rendering limitation without inventing a gap interval.

Total for the four new Round 4 lessons: 14 main keys and eight bonus keys checked; all correct. The unchanged references are covered by preceding round audits. The complete round passed the shared structural audit with valid question blocks and no graph-expression issue. This audit does not decide the blind teaching-quality ranking.
