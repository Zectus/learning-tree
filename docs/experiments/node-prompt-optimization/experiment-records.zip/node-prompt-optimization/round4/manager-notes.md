# Round 4 final notes

All four new writers and all 12 fresh blind graders finished before the usage interruption. The coordinator saved a valid aggregate but hit the usage limit before writing notes. Root completed these notes from all 12 original reports and the frozen lesson texts. No new lesson, replacement output, fresh grade, criterion change, or preference change was introduced during finalization. The final aggregation again validated the packet, prompt and lesson hashes and balanced assignments, with no arithmetic discrepancies.

Eight reference lessons were reused byte-for-byte as declared before grading: baseline from Round 1 and synthesis from Round 2. Four guided lessons were new, all explicitly GPT 6.1 Sol low with fresh histories. Every saved lesson received three ratings, one at each position, across the six condition orders per node. Graders were fresh gpt-6-luna agents, fork none, without an effort override. The grader coordinator used a three-child cap while the preceding round and content auditor were active. Writer and grader launch logs remain separate and unchanged.

| Node | Baseline | Synthesis | Guided |
|---|---:|---:|---:|
| Informal limits | 9.4900 | 9.4833 | 9.5433 |
| Relative phase | 9.4933 | 9.5600 | 9.4233 |
| Equal-node mean | 9.4917 | 9.5217 | 9.4833 |

| Node | First condition | Second condition | First wins | Ties | Second wins |
|---|---|---|---:|---:|---:|
| Limits | Baseline | Synthesis | 3 | 0 | 3 |
| Limits | Baseline | Guided | 2 | 0 | 4 |
| Limits | Synthesis | Guided | 3 | 0 | 3 |
| Phase | Baseline | Synthesis | 2 | 0 | 4 |
| Phase | Baseline | Guided | 5 | 0 | 1 |
| Phase | Synthesis | Guided | 5 | 1 | 0 |

The newer guided revision is not a general improvement. Its small limits lead coexists with a lower phase mean and a 0–5 head-to-head result against synthesis, with one tie. Across both nodes it loses to baseline 5–7 and to synthesis 3–8 with one tie. First-place counts are baseline/synthesis/guided = 2/2/2 on limits and 2/4/0 on phase. There is no basis for selecting it simply because it was the last revision.

The limits reports consistently value an explicit closeness relation and a useful precision task. Synthesis task_03 gives f(x)-2=x-1, an open input interval guaranteeing error below 0.01, and a sensor question distinguishing limit 10 from output 10.008. Guided task_06 introduces absolute value as distance, applies the same precision relation, distinguishes modifications at the center and a distant point, and asks the learner to identify a finite-sample-compatible counterexample. Readers 3 and 4 particularly value that connected transfer. The competing cost is extra notation and density in an introductory lesson. Guided task_05's clearer conceptual consolidation receives strong scores from its three readers but offers less quantitative application. The reports disagree over how much elaboration the first encounter needs.

The phase reports strongly favor a reusable unequal-magnitude derivation followed by a worked prediction. Both synthesis outputs derive P(0)=1/2+rs cos(phi) and apply it before later transfer. The guided outputs stage the distinctions and checks more explicitly, but develop the phase formula mainly for equal magnitudes. Task_11 leaves an unequal-magnitude maximum to a bonus; task_12 works one unequal complex input and asks for a new unequal-family expression without first developing the general rule. The established matrix and complex arithmetic suffice to solve those questions, so this is not a wrong key or an untaught physical premise. It is a real difference in how much support precedes transfer. The guided phase worked-reasoning criterion averages 9.0333, versus synthesis 9.6833; more checkpoints did not replace the missing reusable development.

The pacing-versus-transfer interpretation is an observed lesson pattern, not proof that one particular sentence caused it. Guided bundles three changes: more explicit staging, a conciseness/scaffolding consistency repair, and plausible distractors. These effects were not isolated, and two author samples cannot establish a universal response to any one change.

## Verified report error, grades retained

Relative-phase reader 5 labels baseline task_07 as B and says it “never generalizes the interference formula to arbitrary input magnitudes.” This is false: Section 3 explicitly derives P0=((r+s cos(delta))^2+(s sin(delta))^2)/2=1/2+rs cos(delta), states the complementary P1, and works r=sqrt(3)/2, s=1/2, delta=pi/3. Readers 1, 3 and 4 correctly recognize that development in the same saved lesson. The absence claim is therefore a factual oversight, not merely a preference about clarity. The original report, 9.50 overall score and ranking are preserved. Its effect on a revised judgment is unknown; root did not choose a replacement score. This weakens a close baseline-versus-synthesis comparison in this round, but does not change the direct coherent-versus-baseline evidence from Rounds 1 and 3.

Limit reader 6 considers task_06 Question 3 option B difficult to read. That option assigns 6 at all nonzero inputs and 9 at zero; its intended meaning and the keyed counterexample D are mathematically sound. The wording criticism is treated as a minor clarity judgment, not a verified wrong key and not grounds for changing a score.

Root's separate content audit checked all 22 keys in the four new lessons (14 main, eight bonus), and the unchanged references retain their earlier audits. No substantive mathematical or scope defect was found. All 12 saved outputs passed the app's structural and graph-expression checks. Runtime screenshots and human learning were not measured.

Round 4 contains four new author samples, not 12 new lessons or 36 independent generations. Reused references, near-ceiling scores, reviewer variation and the verified oversight limit interpretation of small gaps. The finding is narrower: guided helped one introductory sample set but did not preserve phase transfer, so it should not replace the more consistently supported coherent variant as the general prompt.
