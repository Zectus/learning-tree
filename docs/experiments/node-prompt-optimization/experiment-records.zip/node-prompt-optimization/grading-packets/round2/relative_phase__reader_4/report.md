# Independent lesson evaluation

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.5 | 9.3 | 9.4 | 9.4 | 10.0 | 9.52 |
| B | 9.5 | 9.4 | 9.7 | 9.5 | 10.0 | 9.62 |
| C | 9.3 | 9.1 | 9.3 | 9.3 | 10.0 | 9.40 |

**Ranking:** B > A > C. **Confidence:** Moderate-high.

## Discussion

**B** is the strongest overall for a reader who wants to learn to calculate and transfer the idea. It introduces the device and amplitude addition with a concrete sign-flip example, then develops the general unequal-magnitude result (P_0=1/2+rq\cos\phi), (P_1=1/2-rq\cos\phi). The worked (r=3/5,q=4/5,\phi=\pi/3) case and the attainable range (1/50\) to (49/50\) make the formula usable beyond the equal-input illustration. Its question about maximizing output 1 also tests the distinction between changing a global phase and changing relative phase. Strongest feature: the most complete bridge from derivation to transfer. Most important weakness: Section 2 places several ideas—unit-circle phase, global equivalence, relative phase, and comparing columns—together before the central phase-dependent recombination derivation, so a reader may have to hold a fair amount of vocabulary before seeing its payoff.

**A** makes the initial motivation especially clear: equal direct probabilities can lead to opposite certain outputs, and it explicitly distinguishes the prepared input from a hypothetical intermediate measurement. Its later section on what the output distribution can and cannot identify is a useful interpretive extension, and the questions progress from calculation to inference. Strongest feature: connecting the mechanics to the limits of what a measured distribution tells us. Most important weakness: the full unequal-magnitude probability formula arrives late in Section 3 after the equal-magnitude derivation; this delays the general transfer rule. Its bonus applying (R) twice adds a further operation without much preceding setup, though it is clearly marked as bonus and is mathematically sound.

**C** is accurate and has a deliberate progression from probabilities, to phase, to recombination. Its derivation of (P_R(0)) and (P_R(1)) for arbitrary amplitudes, including the normalization check, is particularly clear. Strongest feature: the explicit general probability identity and careful accounting of the factor (1/\sqrt2). Most important weakness: it introduces Euler's formula and a unit-circle graph before the reader has met the recombination matrix or seen why phase will matter. That is a reasonable conceptual route, but it delays the motivating operation and asks the reader to process abstract phase language before its practical role is concrete. It also gives less worked practice with unequal magnitudes than B.

All three lessons are mathematically correct within the stated scope. Their central calculations, normalization, and answer keys check out. The differences are teaching choices rather than substantive errors. A learner who prefers an early phase-first conceptual picture may prefer C; a learner drawn to the initial paradox and interpretation may prefer A. For a reader seeking a balanced route with the most directly reusable calculation, B is the best choice.
