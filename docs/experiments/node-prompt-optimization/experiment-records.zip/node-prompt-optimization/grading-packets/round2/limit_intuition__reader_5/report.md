# Evaluación de las lecciones

## Puntuaciones

| Lección | Claridad conceptual y motivación | Andamiaje y ritmo | Razonamiento y transferencia | Aprendizaje activo | Corrección matemática | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.3 | 9.2 | 9.4 | 9.0 | 10.0 | 9.38 |
| B | 9.5 | 9.4 | 9.5 | 9.4 | 10.0 | 9.56 |
| C | 9.4 | 9.2 | 9.4 | 9.2 | 10.0 | 9.44 |

**Ranking:** B > C > A. **Confianza:** alta; las tres lecciones son sólidas y la diferencia es pequeña.

## Evidencia y tradeoffs

**B** ocupa el primer lugar por cómo enlaza la intuición con una justificación general y después enseña a evaluar afirmaciones basadas en datos. La cancelación lleva a (f(x)=x+1), y la igualdad (f(x)-2=x-1) explica por qué el acercamiento de las salidas se mantiene para entradas no incluidas en la tabla. Después, la lección distingue con cuidado una igualdad exacta de una aproximación y explica por qué una tabla finita o datos redondeados no demuestran un límite. La Pregunta 3 convierte esa advertencia en una decisión concreta sobre datos exactos; la práctica adicional sobre dos reglas con distinta pendiente transfiere la idea a otro caso. Su punto más fuerte es esa progresión desde el ejemplo hasta el juicio sobre evidencia. Su debilidad más importante es cierta repetición entre la discusión de la tabla finita y la de la pantalla redondeada; aun así, refuerza una distinción central y no pesa mucho.

**C** da una explicación clara y precisa del hueco, la tendencia y la diferencia entre valor puntual y límite. La sección de aproximaciones también advierte que una gráfica con muestras finitas, igual que una tabla, puede ocultar el comportamiento más cercano al punto. La Pregunta 1 prueba bien la lectura de una garantía de límite: entradas suficientemente cercanas, distintas del centro, pueden asegurar una tolerancia elegida. Su principal coste pedagógico es introducir notación por casos en la segunda sección; el texto la explica, pero supone un pequeño paso adicional para alguien que solo trae los prerrequisitos indicados. Además, aunque reconoce las limitaciones de la gráfica, no presenta puntos marcados que ayuden a visualizar la recta y su hueco. Son límites menores, no errores matemáticos.

**A** destaca por convertir el límite en una herramienta de precisión concreta: a partir de (f(x)-2=x-1), muestra qué intervalo de entradas garantiza un error menor que (0.01), e incluye un ejemplo numérico. También separa con claridad límite, valor en el punto y salida aproximada. Su debilidad principal es que esa aplicación cuantitativa aparece después de que la idea ya se ha explicado y se desarrolla menos la cautela ante tablas finitas: la lección la menciona, pero no incluye una pregunta que haga al lector detectar una conclusión injustificada a partir de datos limitados. La convención de usar puntos decimales se explica y no causa un problema sustancial.

Las tres lecciones presentan correctamente las matemáticas principales: las cancelaciones se restringen a entradas distintas del punto excluido, los límites calculados son correctos y las preguntas tienen respuestas coherentes con sus enunciados. No encuentro errores sustantivos de corrección. En las tres hay preguntas variadas y oportunidades de práctica; como el formato oculta las etiquetas de respuesta y no se ofrece una explicación correctiva por pregunta, el lector dispone de práctica, pero menos apoyo explícito para diagnosticar un error.

Un lector que prefiera aplicar límites a estimaciones con tolerancia concreta podría elegir A. Quien valore especialmente leer tablas o pantallas con cautela podría preferir B. C ofrece una mezcla equilibrada con una visualización explicada con cuidado. Esas preferencias podrían cambiar cuál resulta más agradable, aunque B conserva la ventaja general por el enlace entre explicación y evaluación de evidencia.
