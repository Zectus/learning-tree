# Evaluación comparativa

## Puntuaciones

| Lección | Claridad y motivación | Andamiaje y carga | Razonamiento y transferencia | Aprendizaje activo | Corrección | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.2 | 9.2 | 9.1 | 9.2 | 10.0 | 9.34 |
| B | 9.2 | 9.2 | 9.2 | 9.2 | 10.0 | 9.36 |
| C | 9.5 | 9.0 | 9.5 | 9.3 | 10.0 | 9.46 |

**Clasificación:** C, B, A. **Confianza: media-alta.** Las diferencias son pequeñas; las tres lecciones enseñan correctamente la idea central y ofrecen oportunidades de práctica pertinentes.

## Evidencia y tradeoffs

**C** es la más convincente para un lector que quiere entender por qué la aproximación funciona. Tras la tabla y la gráfica, factoriza y compara explícitamente distancias: \(|f(x)-2|=|x-1|\). El ejemplo “a menos de 0,01” convierte la idea general en una relación concreta y reutilizable. La sección 2 añade una gráfica con el valor aislado \(g(1)=4\), haciendo visible que ese punto no cambia los valores cercanos. La pregunta 2 pide ordenar límite y valor puntual; la pregunta 3 distingue evidencia de demostración, y el bonus 2 prueba la idea con una función constante salvo en el punto. Su debilidad más importante es que introduce valor absoluto y notación más densa que las otras, aunque lo explica y el caso sencillo justifica el costo para el lector previsto. C es la mejor opción para quien aprende con comparaciones explícitas de distancias y apoyo gráfico.

**B** ofrece un recorrido muy bien dosificado: tabla y gráfica, factorización, sustitución \(x=2+h\), y después la definición informal. La frase “No hay una última entrada antes de 2” apoya con sencillez la diferencia entre una lista finita y acercarse tanto como se quiera. Sus preguntas cubren lectura de una regla local, separación entre valor y límite, y límites que los datos no demuestran; el bonus final también corrige la idea de que alguna salida debe alcanzar exactamente el límite. Su rasgo más fuerte es la progresión directa y clara sin cargar al lector con más notación. La principal limitación frente a C es que la conexión entre proximidad de entrada y salida aparece en un ejemplo sencillo, pero no se desarrolla como comparación de distancias que el lector pueda generalizar con la misma facilidad. Puede convenir más a quien prefiere una explicación verbal y ligera.

**A** también explica bien la cancelación válida solo para \(x\ne2\) y separa las tres posibilidades del valor puntual: indefinido, distinto del límite o igual a él. Su mejor recurso de evaluación es la pregunta 3: las salidas redondeadas a dos decimales no garantizan que el límite sea exactamente 10, lo que enseña una cautela numérica útil. La debilidad principal es que esa pregunta se apoya en el redondeo, mientras B y C usan datos concretos que sugieren una tendencia; además, su explicación de cercanía “en la misma medida” es clara, pero menos explícita que la igualdad de distancias de C. A puede resultar preferible para quien se beneficia de ejemplos sobre precisión y redondeo.

No encontré errores matemáticos sustantivos ni problemas de alcance en ninguna lección. La diferencia entre las puntuaciones refleja principalmente cuán explícitamente se conecta la idea informal con el razonamiento reutilizable, no una falla importante en A o B.
