# Evaluación de las tres lecciones

| Lección | Claridad y motivación | Andamiaje y ritmo | Razonamiento y transferencia | Preguntas y oportunidades de práctica | Corrección | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 9.2 | 9.3 | 9.2 | 10.0 | 9.42 |
| B | 9.6 | 9.6 | 9.5 | 9.5 | 10.0 | 9.64 |
| C | 9.5 | 9.4 | 9.2 | 9.4 | 10.0 | 9.50 |

**Ranking:** B > C > A. **Confianza:** alta en que B ofrece la experiencia más completa; media en el orden entre C y A, cuyas diferencias son pequeñas.

Las tres lecciones enseñan correctamente la idea central: un límite describe salidas cercanas, no necesariamente el valor en la entrada central. Cada una combina una tabla, una gráfica y una simplificación algebraica válida solo fuera del punto excluido; también advierte que unas pocas filas no prueban el comportamiento de todas las entradas cercanas. No encontré errores matemáticos ni problemas sustanciales de alcance.

**B** queda primera porque convierte la intuición en un procedimiento que el lector puede usar. Tras mostrar que (f(x)=x+1) fuera de (1), obtiene (f(x)-2=x-1) y usa esa igualdad para justificar qué entradas garantizan una salida a menos de (0.01) de (2), incluso explicando por qué los extremos (0.99) y (1.01) no se incluyen. El ejemplo (x=1.004) hace comprobable el razonamiento. La sección final distingue con precisión una salida concreta del límite exacto. Sus preguntas y bonus vuelven sobre identificación, valor puntual, datos finitos y escalas distintas de acercamiento. Su rasgo más fuerte es esa transferencia cuantitativa; su debilidad más clara es leve: la explicación de la ventana abierta y sus extremos exige atención adicional para una primera lectura, aunque está bien guiada y no introduce una carga formal ajena al alcance.

**C** presenta la secuencia más limpia: la factorización de (x^2-4), la relación (f(x)-4=x-2), y luego la separación entre límite y valor puntual forman una explicación muy coherente. La limitación del dibujo sin círculo abierto se explica bien, y la pregunta sobre la tabla desconocida comprueba una distinción importante. En el bonus, el lector debe transferir la invariancia del límite incluso cuando solo sabe que dos funciones coinciden en un entorno perforado, lo que es una buena oportunidad de razonamiento. Su punto menos fuerte frente a B es que deja la transferencia sobre precisión concreta más implícita; no hay un caso resuelto donde el lector use la regla para garantizar una tolerancia numérica.

**A** también arranca con una buena explicación: demuestra (f(x)-2=x-1), distingue la entrada excluida y añade el caso de una nueva función con (F(1)=8). Su bonus compara (5+x) y (5+100x), y muestra que pendientes distintas no cambian el límite aunque sí cambien el tamaño de la diferencia a igual distancia. La debilidad principal es que el conjunto de práctica se concentra más en reconocer o identificar afirmaciones y menos en desarrollar un método reutilizable para decidir cuán cerca deben estar las entradas; el bonus ofrece esa comparación, pero no la trabaja paso a paso. La explicación sigue siendo clara y correcta.

Un lector que prefiera una exposición breve y lineal podría elegir C: organiza el contenido en una progresión sencilla y sus secciones no se expanden hacia una aplicación de tolerancias. Para alguien que quiera un ejemplo operativo de cómo el límite ayuda a controlar una aproximación concreta, B es la mejor elección. A puede resultar especialmente atractiva a quien valore comparar funciones con tasas de cambio distintas.
