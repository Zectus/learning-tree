# Evaluación de las tres lecciones

## Puntuaciones

| Lección | Claridad conceptual | Andamiaje y carga | Razonamiento y transferencia | Aprendizaje activo | Corrección | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.7 | 9.6 | 9.7 | 9.5 | 10.0 | 9.70 |
| B | 9.7 | 9.7 | 9.8 | 9.6 | 10.0 | 9.76 |
| C | 9.7 | 9.6 | 9.7 | 9.5 | 10.0 | 9.70 |

**Ranking:** B > A = C. **Confianza:** media-alta. Las tres lecciones son sólidas y cubren correctamente el nodo; la ventaja de B es pequeña y se debe a que hace más explícito el puente entre la cercanía de entradas y salidas.

## Evidencia y tradeoffs

**B** ofrece el andamiaje más tangible. Tras factorizar, define la distancia mediante valor absoluto y muestra que \(|f(x)-2|=|x-1|\); luego concreta que entradas a menos de \(0{,}01\) producen salidas a menos de \(0{,}01\) del límite. Eso convierte «tan cerca como queramos» en una relación que el lector puede reutilizar, sin introducir la definición formal épsilon-delta. Su gráfica posterior añade efectivamente el punto aislado \((1,4)\), lo que permite comparar una coordenada puntual con el hueco \((1,2)\). Las preguntas cubren lectura de la notación, separación entre límite y valor puntual, y los límites de una tabla finita. Su mayor debilidad es menor: el cambio de variables entre el primer ejemplo en (x=1), la función (g) con valor asignado y las funciones de práctica exige mantener varios casos en mente, aunque la prosa los conecta con claridad.

**A** desarrolla una intuición geométrica y algebraica muy limpia: (f(x)-4=x-2), así que las distancias de entrada y salida coinciden. Además aclara que el hueco es un solo punto y que el límite puede ser alcanzado (la función constante (7)), evitando dos ideas equivocadas frecuentes. Sus preguntas principales distinguen bien límite, valor puntual y evidencia finita; la práctica adicional transfiere a otro hueco y a una función constante con una excepción. La limitación más visible es que no desarrolla explícitamente la notación de distancia con valor absoluto ni da un umbral numérico general como hace B; aun así, la igualdad de diferencias basta en este ejemplo para justificar la conclusión y el alcance informal queda explicado.

**C** es coherente y legible, con la misma explicación de distancias que A expresada mediante (2+h) y (4+h). La pregunta sobre (g(x)=3+2(x-5)) obliga a identificar entrada y salida y a obtener el límite desde una regla; la segunda sección aclara con cuidado que el valor puntual puede diferir, faltar o coincidir. Las preguntas y los bonos cubren la diferencia entre observación finita y comportamiento general. Su debilidad, también menor, es que el razonamiento central queda anclado en el ejemplo lineal y no ofrece una segunda relación cuantitativa o un umbral concreto que amplíe la transferencia. No presenta errores matemáticos sustantivos.

Las diferencias de estilo no cambian el orden de manera importante: quien prefiera una explicación breve basada en desplazamientos iguales puede encontrar A o C más directa; quien se beneficie de ver distancias escritas y un ejemplo con tolerancia numérica probablemente preferirá B. No hay en ninguna lección una deficiencia sustancial de enseñanza o precisión que justifique una puntuación baja.
