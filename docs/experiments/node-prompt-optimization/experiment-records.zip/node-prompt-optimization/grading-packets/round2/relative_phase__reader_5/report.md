# Evaluation of Lessons A, B, and C

## Scores

| Criterion (equal weight) | A | B | C |
|---|---:|---:|---:|
| Conceptual clarity and motivation | 9.5 | 9.3 | 9.6 |
| Scaffolding, pacing, and cognitive load | 9.4 | 9.2 | 9.4 |
| Worked reasoning and transfer | 9.6 | 9.4 | 9.5 |
| Active learning and feedback opportunities | 9.4 | 9.3 | 9.6 |
| Mathematical correctness and precision | 10.0 | 10.0 | 10.0 |
| **Overall** | **9.58** | **9.44** | **9.62** |

## Ranking

1. **C — 9.62**
2. **A — 9.58**
3. **B — 9.44**

Confidence: **Moderate**. C edges A by a small margin; the ranking mainly reflects how well each lesson completes the learner’s conceptual picture, rather than any correctness difference.

## Evidence and tradeoffs

**Lesson C** is the strongest overall for a learner who works through the whole lesson. Its opening distinguishes direct measurement from the specified recombination procedure, and its worked complex example at \(\phi=2\pi/3\) explicitly squares real and imaginary parts. The later section, “What an interference result tells you,” adds an especially useful limit: a distribution depending on \(\cos\phi\) cannot distinguish \(\phi\) from \(-\phi\), and one outcome cannot identify a preparation. Question 4 asks the learner to apply exactly that inference. This is a substantial teaching strength for interpreting predictions rather than treating them as state-identification rules. The main weakness is that the general unequal-magnitude formula appears after the equal-magnitude example without a separate worked numerical case in that general setting; its transfer is still well supported by the derivation and bonus problem. The lesson is slightly more demanding because it develops the measurement-identifiability distinction in its own section.

**Lesson A** has the clearest route from the motivating sign example to a general reusable result. It carefully derives \(P_R(0)=1/2+ab\cos\phi\), checks an unequal-magnitude case at \(\phi=\pi\), and then works backward from a desired output probability to possible phase settings. Its statement that matching one measurement’s statistics does not prove global-phase equivalence is a valuable, concise transfer point. The questions cover applying the matrix, recognizing a global phase, and solving for phase, while the bonus items extend range and repeated-operation reasoning. Its most important weakness is a thinner treatment of the limits on inference from outcomes than C gives: it briefly notes that a random outcome does not identify a preparation, but does not develop the ambiguity in a whole distribution as explicitly. That is a modest scope difference, not a mathematical or structural defect.

**Lesson B** gives a well-paced, economical progression: the initial sign contrast, global and relative phase, then the equal-magnitude phase family and the unequal-magnitude formula. It provides a helpful graph with a slider for input magnitude, and its third main question combines two useful checks: equal output distributions can arise without global-phase equivalence. Its strongest feature is this efficient progression from a simple family to a transfer case that tests both phase concepts. Its main weakness is that the central worked examples emphasize equal magnitudes; the unequal case is derived and graphed, but receives less numerical walkthrough than A’s unequal-magnitude calculation. The question set and bonus practice compensate in part. The lesson is not substantially weaker in correctness or clarity, but it offers somewhat less explicit support for interpreting what a single measurement distribution can establish.

All lessons’ mathematical results and keyed answers are correct on review, including their normalization, output probabilities, phase choices, and repeated-\(R\) results. None has a substantive scope error: each treats \(R\) as a supplied rule, avoids an observable-trajectory claim, and stays within the stated background.

A learner who prefers shorter lessons and a smooth progression from a standard example to a general formula might prefer **A**. Someone who values the explicit discussion of ambiguous evidence and state inference will likely prefer **C**. A learner who likes a compact presentation and a slider-based exploration may prefer **B**.
