# Independent lesson evaluation

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding, pacing, and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.6 | 9.3 | 9.6 | 9.5 | 10.0 | **9.60** |
| B | 9.5 | 9.6 | 9.2 | 9.5 | 10.0 | **9.56** |
| C | 9.6 | 9.4 | 9.8 | 9.6 | 10.0 | **9.68** |

**Ranking:** C > A > B  
**Confidence:** Moderate. All three are strong, accurate lessons; the distinctions are small and mostly concern how much transfer is demonstrated explicitly.

## Evaluation

**Lesson C ranks first.** Its strongest feature is the bridge from the general interference rule to usable predictions. Section 3 derives (P_0=1/2+rqcosphi) and (P_1=1/2-rqcosphi), then works the unequal-magnitude case (r=3/5, q=4/5, phi=pi/3) to obtain (37/50) and (13/50), and shows the full possible range for those magnitudes. That progression makes the role of both phase and amplitude sizes concrete. The opening (psi_+,psi_-) comparison gives an immediate reason to care about amplitude addition, and the later global-phase explanation is supported by both the direct-probability calculation and (R(e^{i	heta}psi)=e^{i	heta}Rpsi). Questions include calculation, global-phase recognition, optimization, and phase ambiguity. Its main weakness is sequencing: the reader first encounters the recombination device and the plus/minus example before phase and global phase are named in Section 2. The opening makes that sequence workable, though readers who want definitions before examples may need to hold a temporary distinction in mind.

**Lesson A is a close second.** Its strongest feature is the deliberate conceptual sequence: it defines phase and relative phase before introducing recombination, then derives the equal- and unequal-magnitude formulas and closes by explaining what one device and one observed result can establish. The discussion that identical cosine values need not identify a unique phase, and that a single run need not identify a preparation, is especially useful for interpreting the predictions. The worked probability calculations and questions test both computation and interpretation. Its main weakness is density in the first section: Euler's formula, global phase, relative phase, factoring, and the zero-component caveat arrive before the reader has seen recombination make phase matter. That is a pacing cost, not a correctness or scope problem.

**Lesson B places third, by a narrow margin.** Its strongest feature is scaffolding: the unit-circle graph introduces phase as a direction with fixed magnitude, then the lesson separates global from relative phase before presenting the matrix. The worked (phi=pi/3) prediction and the question comparing (pi/4) with (7pi/4) give the reader clear opportunities to apply the result. Its main weakness is that it develops the phase-dependent probability formula only for equal input magnitudes. Unequal magnitudes appear in a bonus maximum-probability question, but the general (r,q) relationship is not derived or made explicit as in A and C, so transfer to that case is less supported. This is a meaningful but limited teaching gap; the lesson remains accurate and well paced.

I found no substantive mathematical errors in any lesson. Their stated answer keys are consistent with the calculations, including the bonus problems. C is the best choice for a learner who benefits from a general rule followed by a worked unequal-magnitude application; A may suit someone who prefers to establish the phase vocabulary before meeting the device; B may suit someone who finds a visual unit-circle introduction especially helpful.
