# Evaluación de las lecciones

## Puntuaciones

| Lección | Claridad conceptual | Andamiaje y ritmo | Razonamiento y transferencia | Aprendizaje activo | Corrección | Total / 10 |
|---|---:|---:|---:|---:|---:|---:|
| B | 9.6 | 9.5 | 9.6 | 9.4 | 10.0 | **9.62** |
| C | 9.5 | 9.3 | 9.5 | 9.3 | 10.0 | **9.52** |
| A | 9.4 | 9.4 | 9.4 | 9.3 | 10.0 | **9.50** |

**Ranking:** B > C > A. **Confianza:** media-alta; las tres lecciones son sólidas y las diferencias son pequeñas.

## Evaluación

**B** es la opción más completa para este lector. Su ejemplo inicial conecta tabla, factorización, gráfica y una relación útil para cualquier entrada permitida: `f(x)-4=x-2`. La frase que compara las distancias de entrada y salida convierte la simplificación algebraica en una explicación de por qué la tendencia continúa, y la definición informal generaliza esa idea. Atiende explícitamente el hueco que el trazador no puede dibujar y evita que el lector interprete la cancelación como una definición de `f(2)`. La sección sobre cambiar el valor puntual incluye una función por casos y distingue bien los dos objetos; el apunte de que una función constante puede producir exactamente el valor límite también corrige la posible idea errónea de que acercarse exige salidas siempre distintas. Las preguntas cubren interpretación, distinción entre valor y límite, y límites de tablas redondeadas; los bonus añaden decisiones transferibles. Su punto más débil es que los escenarios de preguntas son algo repetitivos respecto del ejemplo central, y la afirmación inicial de “resultados a menos de una millonésima” puede exigir traducir una frase verbal sobre cercanía, aunque la respuesta correcta deja claro que se requiere estar suficientemente cerca. Son detalles menores.

**C** tiene un hilo matemático especialmente claro: su tabla y gráfica incluyen puntos a ambos lados, la cancelación se justifica para `x≠1`, y `f(x)-2=x-1` vincula explícitamente las distancias. Su discusión de `≈` frente a una igualdad exacta y de tablas finitas es precisa, y la pregunta 3 plantea una inferencia plausible que el lector debe limitar con cuidado. También explica que el comportamiento debe sostenerse para entradas suficientemente cercanas del dominio. La secuencia concentra varias distinciones antes y alrededor de la segunda pregunta, así que puede sentirse algo más densa que B; además, no incluye en la tabla una fila central “no definida” y esa ausencia se debe inferir del texto y de la restricción. El texto sí declara el hueco con claridad, por lo que esto es una pequeña pérdida de apoyo coordinado, no un error sustancial. Sus bonus practican la transferencia a funciones con distinta escala y un factor grande.

**A** presenta con claridad la separación entre valor puntual, límite y aproximación finita. La igualdad `f(x)=x+2` para entradas permitidas sustenta la tendencia general, y la pregunta 3 distingue correctamente evidencia sugestiva de una garantía. La explicación de que una tabla puede omitir comportamientos diferentes en entradas no registradas ayuda a evitar una concepción errónea común. Las preguntas son alcanzables y cada una se concentra en una idea. Frente a B y C, el razonamiento sobre la distancia entre entrada y salida está menos desarrollado: la expresión `4+h` da un ejemplo convincente, pero no se expone también como diferencia `f(x)-4=x-2`, que haría más explícito el puente para transferir el método. La gráfica explica con cuidado su limitación, aunque la curva puede parecer continua por la representación. Es una limitación menor bien mitigada por el texto.

No encuentro errores matemáticos sustanciales: las cancelaciones se restringen correctamente al dominio permitido, los valores límite calculados son correctos, y se mantiene la diferencia entre una tabla indicativa y un argumento sobre el comportamiento. Las tres ofrecen trabajo activo con opciones plausibles y oportunidades adicionales; las respuestas correctas no convierten las tablas en demostraciones.

La ventaja de B sobre C y A es modesta: su relación de diferencias y su tratamiento explícito de lo que el límite no exige hacen algo más fácil construir una idea reutilizable. C podría ser preferible para alguien que aprende mejor con notación de aproximación y datos tabulados cuidadosamente discutidos; A podría gustar a quien prefiera explicaciones más directas y menos elaboradas. Para el lector descrito, B ofrece el mejor equilibrio.
