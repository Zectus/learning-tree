# Evaluation

| Lesson | Conceptual clarity (20%) | Scaffolding (20%) | Worked reasoning and transfer (20%) | Active learning (20%) | Correctness (20%) | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.2 | 9.4 | 8.9 | 9.1 | 10.0 | 9.32 |
| B | 9.4 | 9.1 | 9.4 | 9.3 | 10.0 | 9.44 |
| C | 9.4 | 8.9 | 9.5 | 9.1 | 10.0 | 9.38 |

**Ranking:** B, C, A. **Confidence:** moderate; the three lessons are all strong, and the gaps are small.

All three correctly distinguish direct measurement from measurement after the supplied recombination matrix, explain why amplitudes must be added before squaring, and preserve the distinction between a common phase and a relative phase. I found no substantive mathematical errors. Their equations, answer keys, and worked numerical results agree.

**B** ranks first because it combines a clear operational explanation with the strongest range of transfer. It works from the matrix rule to the equal-magnitude cosine pattern, then generalizes to (P_0=1/2+rs\cos\phi) for unequal magnitudes. Its example with (r=3/5,s=4/5,\phi=\pi) makes incomplete cancellation concrete, while the later discussion cautions that matching cosine-based statistics do not prove global-phase equivalence. The questions test global phase, unequal magnitudes, phase invariance, and applying (R) twice. The main cost is density: the general case and the epistemic cautions add several ideas beyond the core equal-magnitude derivation. The sequencing is still manageable for the specified engaged reader, but it asks for more sustained attention than A.

**C** is a close second, and has the strongest worked transfer: after deriving the general unequal-magnitude formula, it uses both an incomplete-cancellation example and a reverse prediction of which phases yield a target probability. Its graph and examples connect the algebra to constructive and destructive interference. Its main weakness is pacing and notation load: the general (a,b,\phi) calculation arrives in one dense section, with substantial algebra and interpretive caveats before the reader has many opportunities to consolidate the basic pattern. Its three main questions are meaningful, but offer fewer checkpoints than B. The graph's marked endpoints use filled points, consistent with the stated rendering behavior.

**A** is the most straightforwardly paced. It separates global and relative phase before introducing recombination, gives a useful phase-circle graph, and carefully walks through the equal-magnitude derivation and a φ=π/3 prediction. Its main weakness is transfer beyond that special family: the general unequal-magnitude result is left to a bonus question, and the main path does not show how imbalance limits cancellation. That makes it slightly less prepared for new cases than B and C, despite its approachable progression. The question about π/4 versus 7π/4 appropriately tests that equal output distributions do not imply equal states.

A learner who prefers a shorter, carefully staged introduction may prefer A. A learner who values broader algebraic transfer and boundary cases will likely prefer B or C; C may suit someone who likes deriving target phase settings, while B offers more checkpoints and explicit interpretation of what the experiment can establish.
