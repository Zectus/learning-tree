# Evaluation: Partial Trace and Reduced Density Operators

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding, pacing, and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.3 | 8.8 | 9.5 | 9.3 | 10.0 | 9.38 |
| B | 9.2 | 8.6 | 9.2 | 9.2 | 10.0 | 9.24 |
| C | 9.1 | 8.9 | 9.0 | 9.2 | 10.0 | 9.24 |

**Ranking:** A > B = C (effectively a very close second-place tie).  
**Confidence:** Moderate. All three lessons are strong and mathematically sound; the small distinctions concern how much explicit worked practice versus derivation a first-time learner benefits from.

## Evidence and tradeoffs

**A** has the strongest teaching feature: it repeatedly connects the operation to its purpose. It first derives the reduced operator from local outcome probabilities, then gives the pure-state vector construction, the general index rule, and a fully worked mixed preparation. In Section 2, the example made from half a |+⟩A|0⟩B preparation and half a |0⟩A|+⟩B preparation explicitly computes a reduced off-diagonal entry and the resulting matrix. Section 3 then proves that every local projector gives the same probability from the joint and reduced descriptions, and checks this with a plus-basis calculation. These are especially useful bridges from the recipe to transfer.

A’s main weakness is density: Section 2 moves from the rank-one rule to matrix entries, a four-index qubit formula, a mixed-state example, and proofs of trace, Hermiticity, and positivity in one stretch; Section 4 also gives a fairly formal basis-change proof. An engaged reader can follow it, but this is the heaviest pacing of the three. Its strength outweighs that cost because the examples make the algebra concrete. The later Bell-state comparison clearly distinguishes local mixedness from a physical change to the joint state.

**B** is a close second. Its strongest feature is the explicit route from local measurement probabilities to the partial-trace entry formula: Section 2 derives the rule by comparing the joint probability trace with the reduced-state trace, then checks a complex-amplitude example entry by entry. Section 3 follows through with a plus-basis probability calculated both ways. This makes the result feel motivated rather than merely defined. Its weakness is that Section 2 accumulates several representations and cases (projector trace, contraction, outer product, pure-state formula, worked pure state, and block-index rule), so the reader must keep a lot of notation in view. The main lesson still gives enough worked support, though it lacks A’s explicit numerical mixed-joint-matrix reduction example. B’s treatment of local versus joint predictions and the no-collapse point is clear.

**C** is also strong and has the gentlest pacing of the three. It opens with a concrete measurement problem, derives the pure-state coefficient formula, and then introduces the general mixed-state matrix rule and a worked two-qubit reduction. Its cleanly segmented sequence—general local probabilities in Section 3, then basis invariance, then pure-joint/mixed-local states—supports an engaged reader. Section 4’s rotated-basis contractions make the cancellation tangible. The most important weakness is that the mixed-state matrix example only explicitly works one entry before saying the rest follow; a novice who needs to see the full block sum may want one more line of arithmetic. Some core ideas are also stated in compact index notation, though the prose does explain the role of the summed label.

I found no substantive mathematical errors in the lessons or their worked calculations and embedded questions. Their main limitation is cognitive density around index notation and basis-change algebra, not correctness. The score differences are small: A earns the edge for its richer end-to-end worked transfer, while B and C trade off derivational detail against smoother pacing. A learner who prefers fewer derivation steps and a more segmented exposition might prefer C; someone who wants a probability-first derivation and extra concrete cases is better served by A or B.
