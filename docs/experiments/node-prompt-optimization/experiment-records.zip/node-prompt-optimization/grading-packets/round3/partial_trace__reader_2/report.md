# Evaluation: Partial Trace and Reduced Density Operators

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 9.1 | 9.5 | 9.4 | 9.9 | 9.46 |
| B | 9.2 | 9.2 | 9.3 | 9.4 | 9.9 | 9.40 |
| C | 9.5 | 9.4 | 9.5 | 9.3 | 9.9 | 9.52 |

**Ranking:** C > A > B. **Confidence:** moderate to high. The lessons are all strong, and the score gaps are small.

## Evidence and tradeoffs

**C ranks first.** Its strongest feature is the way it connects the motivation to the general recipe: it starts by showing what a local outcome does for a concrete entangled state, then derives “(\(\rho_A\)) entries equal the sum over the shared environment index” by comparing the joint measurement trace with the reduced-state trace. The worked \(|\chi\rangle\) calculation makes the surviving local coherence visible, and later sections separately verify local predictions and discarded-basis invariance. This sequence gives an engaged first-time reader a clear reason for the index rule as well as practice using it. Its main weakness is density: Section 2 carries several notational jobs at once (two pairs of indices, operator traces, the pure-state formula, and a matrix shortcut). A reader who carefully follows it can manage the load, but the section is demanding. Questions are well targeted, though several test calculations more than invite explanation.

**A ranks second, close behind.** It is especially strong at broad transfer: it starts with arbitrary finite dimensions, derives the pure-state expression from local outcome probabilities, then treats mixed states, matrix ordering, retaining either subsystem, basis changes, and arbitrary local projectors. Its explicit warning that the environment labels must match (rather than the subsystem labels) is a useful correction to a common error. The plus-basis contraction example and the Bell-state purity discussion make the key ideas concrete. Its most important weakness is pacing: the opening general derivation is followed by a long formal treatment, and the reader must carry several conventions and sums before reaching the all-measurements verification. That makes it somewhat harder to absorb than C, although the extra coverage is useful rather than gratuitous. The questions provide varied calculation practice, including a different environment dimension and phase-sensitive outcomes.

**B ranks third, still excellent.** The opening example is an effective scaffold: it shows why computational-basis probabilities alone are insufficient, compares the reduced state with a tempting but incorrect single-qubit ket, and then generalizes to arbitrary amplitudes. Its worked mixed-state matrix and local plus-outcome probability also show that off-diagonal entries matter. The main weakness is that its general partial-trace rule is introduced as a definition after the pure-state derivation, with less step-by-step index reasoning for how the mixed-state matrix rule follows from the local measurement probability. Its basis-invariance section is rigorous, but uses a compact index contraction before the concrete example. This makes the central operator construction slightly less transparent than in C or A for a learner new to the procedure. Its active questions are useful and varied, including comparing both reductions and testing phase-sensitive predictions.

No substantial mathematical or scope errors stood out; the checked formulas and answer keys agree with the stated calculations. All three distinguish an unconditioned reduction from a physical measurement or collapse, and all explain that local predictions do not determine joint correlations. The ranking reflects sequencing and explanatory load, not a correctness gap.

A learner who prefers an opening concrete example and a more compact exposition might favor B. A reader who values broad finite-dimensional generality and explicit treatment of both retained subsystems might prefer A. For the stated average first-time learner, C's link from local measurement probabilities to the index rule gives it the edge.
