# Evaluación de las lecciones

| Lección | Claridad conceptual | Andamiaje y ritmo | Razonamiento y transferencia | Aprendizaje activo | Corrección | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 9.1 | 9.3 | 9.1 | 10.0 | 9.38 |
| B | 9.2 | 8.8 | 9.2 | 9.1 | 10.0 | 9.26 |
| C | 9.5 | 9.1 | 9.4 | 9.3 | 10.0 | 9.46 |

**Orden:** C > A > B. **Confianza:** moderada; las tres lecciones son sólidas y las diferencias son pequeñas.

## C

La fortaleza principal de C es que hace visible dónde se evalúa cada tasa y cómo se aplica la regla a una expresión más compleja que una sola potencia. En la sección 3 contrasta (g'(1)) con (f'(2)), pues (g(1)=2), y muestra por qué usar (f'(1)) atendería a un lado distinto. La pregunta 2 refuerza esto con datos para (g(2)), (g'(2)), (f'(2)) y (f'(5)). También transfiere la regla a una suma: al derivar ((x^2+3)^5+2x), el factor (2x) corresponde solo al término compuesto; la pregunta 3 pide detectar precisamente ese error de alcance.

La explicación local y la gráfica de la tangente completan bien la motivación. La sección 2 aclara que no se divide por (Delta u), y razona por qué el error exterior sigue siendo pequeño en relación con (h), incluso cuando el cambio intermedio puede ser cero. La debilidad más importante es que esta parte del argumento con cotas y errores relativos exige atención y abstracción para una primera lección; la secuencia de aproximaciones previa ayuda, aunque no la elimina. No es un problema de corrección: las condiciones y el razonamiento son válidos. La práctica principal es algo más breve que en A y B, pero sus preguntas son variadas y enfocadas.

## A

A tiene la mejor conexión concreta entre las dos tasas y el límite. En la lámina, calcula el cambio exacto de área (12h+4h^2), luego la tasa media (12+4h), y explica por qué no necesita dividir por el cambio del lado. Esta experiencia prepara la regla general y hace palpable que un cambio intermedio nulo no se debe cancelar. Su gráfico incluye la tangente y la recta, y la pregunta 4 distingue tasa instantánea nula de función constante.

Su debilidad principal es de carga notacional al pasar a la explicación general: se introducen (r) y (s) como errores y se combinan con rapidez. El ejemplo exacto anterior amortigua esa dificultad, pero el puente formal es menos desarrollado que en B y C. También hay menos variedad de transferencia algebraica: la mayor parte de la práctica se centra en potencias compuestas o datos de tasas. La matemática y las respuestas señaladas son correctas.

## B

B ofrece una transición explícita desde dos aproximaciones locales hasta la regla general. Su explicación de por qué el error de la etapa exterior es pequeño en comparación con (h), aun cuando no se divide por (Delta u), es precisa; también recuerda que (f'(g(x))) es una evaluación y luego se multiplica por (g'(x)). La pregunta 4 compara las composiciones en ambos órdenes, una buena transferencia que comprueba si el lector consulta la entrada correcta en cada caso. El ejemplo de potencia conserva el polinomio sin desarrollarlo, y los ejercicios cubren composiciones anidadas.

Su rasgo menos logrado para este lector es el ritmo de la prueba: el párrafo sobre errores relativos y el cociente (Delta u/h) concentra lenguaje abstracto antes de volver a una aplicación numérica. La primera sección motiva bien la multiplicación de unidades, aunque la gráfica solo marca el punto y no muestra una tangente que ayude a leer visualmente la tasa. Además, las preguntas de práctica se inclinan más hacia reconocimiento y ejecución de fórmulas que hacia explicar el alcance de un factor o el significado de una tasa nula. Son oportunidades de profundización, no errores sustantivos; los cálculos y la regla son correctos.

Las preferencias podrían cambiar la elección: quien comprenda mejor con un cálculo exacto y concreto puede preferir A; quien valore el argumento formal más detallado, B. C es la opción más completa para quien aprende al alternar entre explicación, evaluación en el punto correcto y diagnóstico de errores. No encontré errores matemáticos sustantivos en ninguna de las tres.
