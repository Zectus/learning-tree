# Evaluación de las lecciones

| Lección | Claridad conceptual | Andamiaje y ritmo | Razonamiento y transferencia | Preguntas | Corrección | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 9.2 | 9.3 | 9.1 | 10.0 | 9.4 |
| B | 9.2 | 9.0 | 9.1 | 9.2 | 10.0 | 9.3 |
| C | 9.5 | 9.1 | 9.5 | 9.4 | 10.0 | 9.5 |

**Ranking:** C > A > B. **Confianza:** moderada; las tres enseñan bien el criterio central y las diferencias son pequeñas.

C ofrece la transferencia más completa. Primero muestra el salto con ramas y explica por qué cada lado llega a una altura distinta; luego formula el criterio y lo aplica inmediatamente al hueco, incluido el papel de cambiar el valor aislado en el punto. La pregunta 2 comprueba una confusión frecuente (tomar el valor de la fila central como el límite) y la pregunta 3 pide elegir una constante que haga coincidir las llegadas y determinar el límite. Sus preguntas adicionales también prueban que conocer un solo lado es insuficiente y contrastan una función sin límite con otra cuyo límite sí existe. Su punto más débil es de ritmo: el ejemplo del hueco aparece dentro de la sección dedicada al criterio, así que esa sección acumula el teorema, una aplicación y una representación gráfica. Es una carga algo mayor, pero el ejemplo está explicado paso a paso y sirve a la comparación prevista.

A tiene la exposición más deliberada del razonamiento del criterio: explica por qué un destino bilateral debe servir para cada lado y cómo reunir las dos cercanías cuando ambos destinos coinciden. También distingue con cuidado el punto excluido del gráfico y muestra que cancelar en el cociente solo vale para entradas distintas del punto. La pregunta 3 contrasta de forma útil un hueco y una función con valor central distinto, y los ejercicios de práctica exploran una constante y el valor absoluto. Su debilidad principal es que la transferencia está algo más concentrada en contrastar ejemplos ya desarrollados: hay menos práctica que pida construir o justificar una decisión nueva que en C.

B también explica correctamente la necesidad y suficiencia del acuerdo lateral, y sus ejemplos de salto y hueco son claros. Su pregunta 2 hace que el lector razone sobre cambiar solo el valor en el punto; el bono final compara los límites en dos puntos distintos. La debilidad más visible es el gráfico inicial: dibuja las rectas auxiliares completas y depende de que el lector retenga la advertencia de que las prolongaciones no son parte de la función. La explicación lo aclara, de modo que no es un error matemático, pero la representación exige una corrección mental innecesaria frente a A y C. Además, sus ejemplos practican menos explícitamente cómo elegir una constante para hacer coincidir las tendencias.

No encontré errores matemáticos sustantivos: los límites, cancelaciones, condiciones laterales y respuestas marcadas son coherentes en las tres lecciones. La diferencia entre las puntuaciones es pedagógica, no de corrección. Un lector que prefiera un recorrido más pausado y una explicación más explícita de la lógica del criterio podría preferir A; quien se beneficie de más transferencia entre casos elegiría C.
