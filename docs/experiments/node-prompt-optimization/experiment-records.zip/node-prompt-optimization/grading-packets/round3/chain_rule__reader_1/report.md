# Evaluación de las lecciones

## Puntuaciones

| Lección | Claridad conceptual | Andamiaje y ritmo | Razonamiento y transferencia | Preguntas y oportunidades de práctica | Corrección matemática | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.3 | 9.0 | 9.2 | 9.2 | 10.0 | 9.34 |
| B | 9.1 | 8.8 | 9.1 | 9.0 | 10.0 | 9.20 |
| C | 9.5 | 9.4 | 9.4 | 9.1 | 10.0 | 9.48 |

**Ranking:** C > A > B. **Confianza:** alta.

## Evaluación

**C** ofrece la progresión más fácil de seguir para este lector: empieza con un cambio concreto, obtiene la tasa a partir de incrementos exactos y solo después generaliza a la regla. El ejemplo de la lámina lleva de \(\Delta u=3\Delta t\) a \(\Delta A=30\Delta t+9(\Delta t)^2\), de modo que el lector ve por qué el término cuadrático desaparece en la tasa instantánea. El gráfico añade una tangente interpretable en el punto marcado. Más adelante, el ejercicio sobre \((x^2-4x+6)^4\) corrige una inferencia plausible: aunque la base siempre es positiva, la derivada puede anularse porque la derivada interior se anula. Su debilidad principal es que el núcleo ofrece menos preguntas obligatorias que A y concentra la práctica en la regla y la evaluación de entradas; los dos ejercicios adicionales amplían bien esa cobertura. No hay error matemático sustantivo.

**A** combina una buena motivación con una explicación general cuidadosa. El ejemplo del área distingue explícitamente una tasa local de una afirmación exacta para cambios grandes, y la sección de la regla explica por qué no se cancela \(\Delta u\) cuando podría ser cero. La práctica transfiere la regla a unidades, potencias, datos tabulados y composiciones en ambos órdenes; el recordatorio de que no se necesita conocer \(p(5)\) ayuda a separar valor y derivada. Su punto más débil es el ritmo: la justificación general ocupa bastante espacio y presenta varias ideas de límite antes de que el lector haya visto un ejemplo algebraico sencillo de la cadena. El gráfico inicial tampoco muestra la tangente que se usa después para interpretar la pendiente, aunque el texto sí interpreta la curva. Son costes leves de secuencia y representación, no fallos de contenido.

**B** tiene un buen ejemplo de incrementos exactos y un gráfico con tangente, y cubre un caso especialmente útil: una derivada interior nula no obliga a que la función sea constante cerca del punto. La sección de composición con datos tabulados también pide seleccionar la entrada correcta para la derivada exterior. Sin embargo, la explicación general introduce de golpe dos errores auxiliares, \(r\) y \(s\), y sus condiciones límite; para un principiante, eso hace más difícil ver la idea que la argumentación directa con incrementos de C o la explicación verbal de A. La notación es válida y el caso \(\Delta u=0\) está atendido, pero el tratamiento es más denso de lo necesario para esta audiencia. Esa carga explica la diferencia, no una deficiencia de corrección.

Las tres lecciones son matemáticamente correctas en sus ejemplos y respuestas, y las tres respetan el alcance. Una persona que prefiera una justificación más algebraica y una variedad de ejercicios podría elegir A; quien valore especialmente el caso de tasa interior nula y su interpretación también encontrará algo útil en B. Para el lector descrito, C ofrece la ruta más gradual y conectada entre ejemplo, regla y transferencia.
