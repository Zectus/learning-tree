# Evaluación de las lecciones

## Puntuaciones

| Criterio | Peso | A | B | C |
|---|---:|---:|---:|---:|
| Claridad conceptual y motivación | 20% | 9.0 | 9.5 | 9.4 |
| Secuencia, ritmo y carga cognitiva | 20% | 9.1 | 9.6 | 9.3 |
| Razonamiento trabajado y transferencia | 20% | 8.9 | 9.4 | 9.4 |
| Preguntas y oportunidades de aprendizaje activo | 20% | 9.0 | 9.4 | 9.2 |
| Corrección y precisión matemática | 20% | 10.0 | 10.0 | 10.0 |
| **Total** | **100%** | **9.20** | **9.58** | **9.46** |

**Orden:** B, C, A. **Confianza:** alta en que las tres son sólidas y en que B ofrece la mejor secuencia para este lector; media-alta en la distancia pequeña entre C y A.

## Evaluación

**B** ocupa el primer lugar por cómo convierte el criterio de los laterales en una idea que el lector puede aplicar y defender. En la sección 2 descarta uno por uno los destinos posibles del salto —incluida una altura intermedia— y luego explica por qué coincidir en ambos lados basta: se puede escoger una cercanía que sirva para ambos. La pregunta sobre el promedio comprueba precisamente una confusión plausible, y las secciones posteriores vuelven a separar el límite del valor en el punto mediante el hueco de (p). Las preguntas progresan desde calcular laterales hasta juzgar una afirmación y comparar ejemplos; los bonos añaden un parámetro y el efecto de cambiar el valor en el punto. Su rasgo más fuerte es esa secuencia de explicación, criterio y comprobación. Su pequeña debilidad es que las gráficas son referencias auxiliares completas: el lector debe apoyarse en las condiciones para recordar qué rama pertenece a la función, aunque el texto lo advierte expresamente. No es un error matemático ni impide seguir la lección.

**C** también construye una comprensión transferible. La explicación de por qué la igualdad de laterales implica el bilateral es clara, y la sección 3 ofrece un procedimiento explícito para una función por tramos, incluido cómo resolver un parámetro. La pregunta de (m) pide tanto el parámetro como el límite, y los bonos prueban la lectura de ||x|| y distinguen un cambio puntual de uno en una rama. La mejor característica es que organiza el uso del criterio como método reutilizable. Frente a B, el paso inicial mezcla más tareas: introduce hueco y salto en la segunda sección, con una explicación gráfica larga sobre la recta de referencia; después vuelve al procedimiento en la tercera. Ese recorrido sigue siendo comprensible, pero la exposición podría separar mejor la consolidación del criterio de su aplicación. No hay un fallo de contenido: los resultados y las respuestas indicadas son correctos.

**A** ofrece una exposición directa y matemáticamente precisa. Su primer ejemplo cuantifica las diferencias respecto de los destinos (((x+1)-2=x-1) y ((x+3)-4=x-1)); la sección 2 enuncia y justifica el criterio en ambas direcciones; y el ejemplo factorizado muestra limpiamente por qué un hueco no impide un límite. Las tres preguntas principales contrastan salto, valor puntual y hueco, y los bonos ofrecen práctica adicional. Su rasgo más fuerte es la economía de los ejemplos y el contraste claro entre los dos casos centrales. En comparación con B y C, ofrece menos ayuda para transferir el criterio a una tarea nueva: las orientaciones de procedimiento son breves y la práctica de parámetros aparece solo como bono. Además, en la primera gráfica las dos rectas se prolongan por regiones donde no rigen; el texto lo explica, aunque el lector tiene que mantener presente esa salvedad mientras lee la figura. Esto es una carga menor de representación, no una inexactitud.

Las tres lecciones son correctas en los cálculos, los criterios y las respuestas de sus ejercicios. Ninguna presenta un problema sustancial de enseñanza. Un lector que prefiera una explicación compacta podría elegir A; alguien que quiera un procedimiento de aplicación más destacado podría preferir C. Para el lector promedio definido en el encargo, B combina mejor el razonamiento explícito con preguntas que ponen a prueba errores previsibles.
