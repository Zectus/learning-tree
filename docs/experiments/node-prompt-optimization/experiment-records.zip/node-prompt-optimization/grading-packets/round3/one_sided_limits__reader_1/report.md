# Evaluación de las lecciones

## Puntuaciones

| Lección | Claridad conceptual | Andamiaje y carga | Razonamiento y transferencia | Aprendizaje activo | Corrección | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 8.8 | 8.7 | 8.7 | 8.8 | 10.0 | 9.00 |
| B | 9.2 | 9.2 | 9.4 | 9.2 | 10.0 | 9.40 |
| C | 9.3 | 9.1 | 9.0 | 9.0 | 10.0 | 9.08 |

**Ranking:** B, C, A. **Confianza:** moderada-alta.

## Comparación

Las tres lecciones son matemáticamente correctas, mantienen el tema dentro del alcance y explican que el valor asignado en el punto no decide el límite. En cada una, las respuestas de las preguntas y los cálculos son coherentes. Ninguna introduce límites infinitos ni pide conocimientos posteriores.

**B** ofrece la ruta de aprendizaje más completa. Después de comparar las alturas 2 y 4, descarta explícitamente el promedio como candidato al límite y explica por qué la coincidencia de ambos lados basta. Su ejemplo del hueco desarrolla la cancelación válida para (x\ne1), y la pregunta 2 confronta la confusión concreta entre denominador nulo y límite. La sección 3 convierte la idea en un procedimiento y aplica ese procedimiento a un parámetro en la pregunta 3. Su rasgo más fuerte es conectar explicación, ejemplo y uso en una situación nueva; la debilidad principal es que acumula bastante explicación antes de la práctica final, aunque las preguntas intercaladas ayudan a sostener el ritmo.

**C** es especialmente claro al motivar la comparación: muestra por qué fallarían tanto 2 como 4 y una altura intermedia, y luego formula el criterio bilateral. La explicación de (p(x)=x+1) junto al hueco es legible y la pregunta 3 comprueba que el alumno separe el límite del valor puntual en dos funciones distintas. Su rasgo más fuerte es la precisión conceptual y el buen contraste entre salto y hueco; su debilidad más importante es que la transferencia a parámetros queda relegada a una pregunta extra y no se practica en la secuencia principal. Una preferencia por explicaciones más concisas y geométricas podría hacer que C fuera la opción favorita sobre B.

**A** presenta un ejemplo inicial bien apoyado por tabla, y aclara que la tabla ilustra mientras que las fórmulas justifican el comportamiento. También ofrece un criterio correcto y ejemplos de salto, hueco y parámetros. Su característica más útil es esa tabla inicial, que hace visible el acercamiento desde ambos lados; su debilidad sustancial comparada con B y C es que explica con menos detalle por qué coincidir los límites laterales asegura un límite bilateral. El criterio aparece con una justificación breve, así que el lector tiene menos apoyo para reconstruirlo por sí mismo. El resto es correcto y funcional; la diferencia es de profundidad didáctica, no de precisión matemática.

La ventaja de B sobre C es pequeña: B practica más explícitamente el método y el ajuste de parámetros, mientras C tiene una explicación geométrica y conceptual algo más pulida. Un alumno que prefiera leer una argumentación detallada antes de seguir un procedimiento podría elegir C. A queda detrás por el menor desarrollo del razonamiento central, no por su brevedad en sí.
