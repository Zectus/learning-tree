# Evaluación de las tres lecciones

## Puntuaciones

| Lección | Claridad conceptual | Andamiaje y ritmo | Razonamiento y transferencia | Preguntas y práctica | Corrección | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.2 | 9.0 | 9.2 | 9.1 | 10.0 | 9.30 |
| B | 9.4 | 9.6 | 9.4 | 9.5 | 10.0 | 9.58 |
| C | 9.3 | 9.2 | 9.4 | 9.4 | 10.0 | 9.46 |

**Ranking:** B > C > A. **Confianza:** alta. Las tres presentan correctamente la regla y ofrecen una ruta viable para aprenderla; la diferencia principal está en cuánta práctica guiada y apoyo concreto recibe el lector.

## Evidencia y tradeoffs

**B** queda primera porque construye la idea en más pasos verificables. En la sección inicial obtiene la tasa 12 con unidades y luego comprueba la aproximación mediante el cambio exacto \(12h+4h^2\); eso ayuda a conectar intuición, gráfica y límite. La prueba general controla los errores y explica por qué no hace falta dividir por el cambio interior. Después, la sección sobre tasa interior cero desarrolla \(V(x)=(x^2+2)^3\), muestra el cambio de orden cuadrático y acompaña la explicación con una gráfica de tangente horizontal. Las preguntas principales y adicionales avanzan desde identificar entradas hasta composiciones anidadas y tasas nulas. Su rasgo más fuerte es esa secuencia de intuición, verificación y transferencia. Su debilidad más importante es que la lección es extensa y exige sostener atención durante varias secciones; aun así, el ejemplo exacto y los subtítulos hacen que la carga sea razonable para el lector previsto. No encontré errores matemáticos sustantivos.

**C** es una segunda opción muy cercana. Su prueba con \(\varepsilon(h)\) y \(\eta(\Delta u)\) es precisa y directa: sustituye las dos aproximaciones en el cociente y trata explícitamente el caso \(\Delta u=0\). El ejemplo de \((2x^3+x+1)^4\) enseña a conservar la estructura y a evaluar la derivada después, y las preguntas cubren composición, lectura de datos, regla de potencia y derivadas con valor interior cero. Su rasgo más fuerte es la claridad del razonamiento algebraico y de la notación. La principal limitación didáctica es que la sección sobre tasas nulas queda enunciada de forma general, con una pregunta breve, sin un ejemplo desarrollado como el de B; por ello ofrece menos apoyo a quien necesite entender qué significa concretamente una pendiente cero. Es una diferencia de enseñanza, no de corrección.

**A** presenta una motivación clara con el cuadrado cuyo lado depende de \(t\), y el paso de \(g'(1)\) y \(f'(2)\) a la tasa del área comunica bien dónde evaluar cada derivada. También explica por qué no se cancela un incremento potencialmente nulo y distingue la composición de una suma como \((x^2+3)^5\) frente a \(x^2+3^5\). Su rasgo más fuerte es la conexión inicial entre unidades, composición y pendiente local. Su principal debilidad es que ofrece menos escalones de práctica y menos desarrollo de casos variados que B y C: hay tres preguntas principales, mientras que la práctica adicional no añade un ejemplo guiado de tasa cero ni de composición con varias capas. La demostración es razonable pero más comprimida en el control de los errores. No hay un problema sustantivo de corrección.

B aventaja a C sobre todo por el ejemplo trabajado de tasa cero y la comprobación exacta de la aproximación; C aventaja ligeramente a A por su prueba más explícita y por una cobertura más amplia en las preguntas. Un lector que prefiera una demostración compacta y simbólica podría preferir C; quien aprenda mejor con una comprobación concreta y una gráfica de tasa cero probablemente elegirá B. A puede resultar atractiva para quien valore una presentación más corta.
