# Independent lesson evaluation

## Scores

| Lesson | Conceptual clarity | Scaffolding | Worked reasoning and transfer | Active learning | Correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.7 | 9.5 | 9.6 | 9.5 | 9.9 | **9.64** |
| C | 9.6 | 9.6 | 9.6 | 9.5 | 9.9 | **9.64** |
| B | 9.4 | 9.2 | 9.4 | 9.4 | 9.9 | **9.46** |

**Ranking:** A and C tied for first, followed by B. **Confidence: moderate.** A and C are exceptionally close; their tenth-point distinctions are not meaningful enough to support a confident winner.

## Evidence and tradeoffs

All three lessons accurately teach the central construction: retain the accessible row and column labels, set the environment labels equal, and sum over them. They also explain that this is a change in description rather than a collapse, establish the local Born-rule equivalence, demonstrate basis independence, and distinguish a mixed subsystem from a pure entangled whole. I found no substantive mathematical error or scope failure.

Lesson A’s strongest feature is its opening derivation from the reader’s actual task. It first shows why computational-basis probabilities alone are insufficient, checks a plus-basis outcome, and then derives ​\((\rho_A)_{ij}=\sum_\mu c_{i\mu}c_{j\mu}^*\) by expanding an arbitrary local outcome probability. That gives the rule a clear purpose before introducing it for mixed joint operators. Its worked block-trace example, general proof that all local projective probabilities are preserved, and separate unitary-basis calculation make a particularly coherent progression. The most important weakness is that the material is dense: several definitions, proofs, and calculations arrive in succession, so a learner may need to pause and consolidate. This is a pacing concern, not a correctness problem.

Lesson C is essentially tied with A. Its strongest feature is unusually careful scaffolding around the index notation and contractions: it defines primed indices, explains what the contraction map does to a product vector, groups amplitudes by environment label, and warns that the unnormalized vectors already carry their weights. It then checks local probabilities both from the reduced matrix and directly from the joint state. Its central weakness is mild repetition and abstraction load: after an opening derivation, Section 2 revisits much of that construction in more formal notation, and the text explains several symbols at length. This supports a cautious reader, though a reader comfortable with the notation may find the middle sections slower.

Lesson B’s strongest feature is economical, usable calculation practice. Its termwise outer-product rule is immediately tested in a short exercise, then extended to matrices and a three-dimensional environment; the examples make clear that matching labels belong to the discarded system. Its main weakness is sequencing: it proves basis independence before the dedicated section that establishes preservation of every local measurement probability, and it gives less space to the motivating local-probability derivation and the pure-whole/mixed-part explanation than A and C. Nothing essential is omitted, but that ordering makes the conceptual through-line somewhat less direct for a first-time learner.

The first-place tie reflects a preference tradeoff rather than a material quality gap. A learner who benefits most from a purpose-first derivation and a smooth theorem sequence may prefer A. A learner who wants more explicit notation support and intermediate explanation may prefer C. A learner who prefers a compact, calculation-forward treatment may prefer B.
