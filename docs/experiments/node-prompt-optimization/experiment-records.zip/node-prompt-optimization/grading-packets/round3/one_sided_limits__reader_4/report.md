# Evaluación comparativa

## Puntuaciones

| Criterio | A | B | C |
|---|---:|---:|---:|
| Claridad conceptual y motivación | 9.0 | 9.2 | 9.1 |
| Andamiaje, ritmo y carga cognitiva | 8.9 | 9.2 | 8.9 |
| Razonamiento trabajado y transferencia | 8.8 | 8.9 | 9.2 |
| Preguntas y oportunidades de aprendizaje | 8.7 | 8.8 | 9.2 |
| Corrección y precisión matemática | 10.0 | 10.0 | 10.0 |
| **Total igualmente ponderado** | **9.08** | **9.22** | **9.28** |

**Orden:** C > B > A. **Confianza:** media; las tres lecciones son sólidas y las diferencias son pequeñas. Los puntajes no llegan a 9.5 porque, aunque las preguntas son correctas y útiles, la mayoría son de opción múltiple y ofrecen poca retroalimentación explicativa después de responder; la práctica no llega a desarrollar soluciones completas por cuenta del lector.

## Discusión

**C queda primera por un margen estrecho.** Su punto más fuerte es la transferencia: la pregunta 2 pide clasificar tres situaciones a partir de información lateral distinta, incluida una llegada izquierda que no es un número finito único. La pregunta 3 separa correctamente la constante que determina el acuerdo lateral del valor puntual (b), y el bonus 2 combina dos condiciones (existencia del límite y valor puntual distinto). Esas tareas hacen que el lector aplique el criterio a casos nuevos, no solo que sustituya el punto en dos expresiones. La tabla inicial también contrasta entradas de ambos lados y aclara que es ilustrativa, mientras que las fórmulas justifican las llegadas. Su debilidad más visible es que la notación del gráfico con dos trazas condicionadas mediante `0/0` puede resultar menos transparente que la explicación algebraica; el propio texto sí explica la exclusión del extremo. Además, los ejercicios no dan feedback desarrollado.

**B ocupa el segundo lugar y ofrece el andamiaje más claro.** Define por separado ambas notaciones laterales, las lee en palabras y conecta la definición con (x<a) y (x>a). Luego deriva el criterio en ambas direcciones y da un procedimiento de tres pasos para aplicarlo a funciones por tramos. La sección del hueco justifica la cancelación solo para (x\ne2), y la pregunta 3 compara un hueco con una función por tramos cuyo valor puntual no coincide con la llegada. La principal limitación es que su práctica tiende a repetir cálculos directos: la pregunta 1 evalúa dos sustituciones límite y la pregunta 2 concluye que ajustar (c) es inútil porque las llegadas ya difieren. Aun así, la secuencia es muy fácil de seguir para alguien que aprende la notación por primera vez.

**A queda tercera, también con una diferencia pequeña.** Explica bien por qué un límite bilateral no puede ser ninguno de los dos valores cuando las llegadas laterales difieren, y ofrece una explicación intuitiva de por qué el acuerdo lateral basta. Su pregunta 2 aborda una confusión importante al separar (p(2)) de las dos llegadas, y la pregunta 3 exige encontrar una constante que las haga coincidir. El hueco se representa con una recta de referencia y el texto advierte explícitamente que no es una asignación de (h(2)), una elección clara dada la limitación gráfica. La debilidad principal es que el andamiaje operativo y la variedad de transferencia son algo menores: el procedimiento aparece, pero con menos desglose que en B, y varias preguntas vuelven a reconocer directamente el criterio ya enunciado. No hay un error matemático sustantivo.

Las tres lecciones son correctas en sus cálculos y mantienen el tema en límites finitos. No encontré un problema de alcance ni una afirmación falsa. Para un lector que prefiera definiciones y pasos explícitos, B podría ser la mejor elección; para quien aprenda mejor clasificando casos variados y combinando condiciones, C resulta más atractiva. A puede convenir a quien valore una explicación directa de las confusiones entre salto, hueco y valor puntual.
