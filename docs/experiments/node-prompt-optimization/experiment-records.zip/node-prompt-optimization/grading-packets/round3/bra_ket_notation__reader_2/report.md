# Evaluation: Bras, Kets, and Outer Products

## Scores

| Criterion (weight) | Lesson A | Lesson B | Lesson C |
|---|---:|---:|---:|
| Conceptual clarity and motivation (20%) | 9.3 | 9.0 | 9.5 |
| Scaffolding, pacing, and cognitive load (20%) | 9.1 | 9.1 | 9.4 |
| Worked reasoning and transfer (20%) | 9.4 | 9.1 | 9.5 |
| Active learning and feedback opportunities (20%) | 9.2 | 9.0 | 9.3 |
| Mathematical correctness and precision (20%) | 10.0 | 10.0 | 10.0 |
| **Overall** | **9.40** | **9.24** | **9.54** |

**Ranking:** C > A > B. **Confidence:** moderate. The lessons are all accurate and strong; the small gaps reflect differences in how completely their examples lead an engaged reader from notation to usable projection reasoning.

## Evidence and tradeoffs

**Lesson C** is the strongest fit for this node. Its opening frames the bra as the operation that extracts a scalar and the ket as the direction that turns it back into an output vector. It then derives the projection coefficient from the orthogonality condition, rather than presenting (P=|n\rangle\langle n|) as a formula to memorize. The complex example explicitly computes the conjugated row, matrix, coefficient, projected vector, and orthogonal remainder; the later real-coordinate example and graph make the geometry visible while stating the limits of that plane picture for complex vectors. The final normalization discussion explains when the denominator is needed. Its questions include transfer from a prescribed input-output rule to an outer product (Q2) and a complex projector calculation (Q3). The main weakness is density: the projector section introduces a complex example, a real graph example, eigenvector properties, idempotence, and the unnormalized case in succession. An engaged reader can follow them, but it is a substantial concentration of ideas.

**Lesson A** is a close second. Its first sections cleanly contrast scalar inner products with matrix-valued outer products, including a useful explicit application of an outer product to an arbitrary input. The projector derivation is especially well motivated: it asks for the removed remainder to be perpendicular and solves for the coefficient, then checks the removed vector numerically. The graph, idempotence, eigenvector relations, and unnormalized-direction formula give a sound chain of intuition and transfer. Four main questions distribute retrieval and calculation across the exposition, including a projector calculation with a complex direction. Its main weakness is that the projector section layers several follow-on properties and the unnormalized generalization after a fairly detailed real example; the extra depth is valuable but can make the lesson feel less paced than C. Some practice (notably Q1 and Q2) checks direct conjugation or multiplication more than broader interpretation.

**Lesson B** teaches the notation and map action accurately and clearly. The worked outer-product example demonstrates both column-by-row construction and the shortcut for applying the map, and the table is a helpful compact reference for distinguishing the four expression types. Its projector derivation correctly shows why normalization makes the discarded component orthogonal, then verifies idempotence and handles a complex example while explaining what the real-plane graph can and cannot show. Q2 usefully tests which outer product realizes a specified action. The weakness is that the projector construction and its geometry receive less development than in A or C: the real graph illustrates a perpendicular remainder, but there is no accompanying numerical check of that remainder's inner product, and the three main questions leave less embedded practice for the full projector workflow. This is a modest teaching-depth difference, not a correctness problem.

All three lessons' displayed calculations and answer keys check out, including the conjugation-sensitive complex projector problems and the bonus items. No substantive scope or correctness error warrants a penalty. A learner who prefers a compact table and a worked operator-action shortcut may prefer B; someone who values an additional stepwise projector exercise may prefer A. Those preferences could narrow or reverse the choice for those learners, though C is the most complete overall progression for the stated average first-time reader.
