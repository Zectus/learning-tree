# Evaluación comparativa

## Puntuaciones

| Lección | Claridad conceptual y motivación | Andamiaje, ritmo y carga | Razonamiento trabajado y transferencia | Aprendizaje activo | Corrección y precisión | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.6 | 9.5 | 9.6 | 9.5 | 10.0 | 9.64 |
| B | 9.4 | 9.2 | 9.5 | 8.8 | 9.2 | 9.22 |
| C | 9.7 | 9.6 | 9.7 | 9.6 | 10.0 | 9.72 |

**Ranking:** C > A > B. **Confianza:** moderadamente alta. C supera a A por un margen pequeño; B queda detrás por un error en la respuesta indicada para un ejercicio y por algo más de densidad formal.

## Evidencia y tradeoffs

**C** es la opción más fuerte para un lector que trabaja el material. Su mejor rasgo es que conecta la intuición con el límite de forma concreta: después de obtener (Delta Aapprox12h), calcula exactamente (Delta A=12h+4h^2) y muestra por qué el cociente tiende a 12. Luego explica el argumento general, incluida la cota que hace que el error exterior sea despreciable respecto de (h), sin dividir por el cambio interior. El ejemplo de (V(x)=(x^2+2)^3) también desarrolla una interpretación útil de derivada cero: el cambio (12h^2+6h^4+h^6) no desaparece, pero su tasa sí. Las preguntas recorren lectura de datos, derivación, corrección de un error y composición en distinto orden. Su única pequeña desventaja frente a A es que el tratamiento explícito de los dos factores que pueden anularse aparece en una frase final, mientras que A los distingue con más desarrollo.

**A** queda muy cerca. Su rasgo más logrado es el uso consistente de las tasas y las unidades desde el ejemplo del cuadrado hasta la regla general; además calcula exactamente (Delta A=30Delta t+9(Delta t)^2), y su argumento general aclara por qué no se necesita dividir por (Delta u). El ejemplo con (G(2)), (G'(2)), (F'(5)) ayuda a separar el valor interior de la tasa interior. La pregunta sobre (J(x)) es una buena comprobación de que una base siempre positiva no impide que la derivada se anule por el factor interior. La debilidad relativa es menor: ofrece menos variedad de pasos de práctica que C, aunque sus preguntas principal y adicional siguen dando oportunidades suficientes para aplicar y transferir la regla.

**B** explica con cuidado la aproximación mediante errores (arepsilon(h)) y (eta(Delta u)), y el ejemplo de la tabla hace visible dónde consultar cada derivada. Su trabajo con potencias, sumas y datos en un punto es sólido. Sin embargo, la respuesta marcada para BONUS 1 es incorrecta: para (V(x)=[(x^2+1)^3+2]^4), la derivada es la opción **E**, con factor (24x); la etiqueta indica **C**, que omite ese factor. Como las preguntas son parte del aprendizaje y de la retroalimentación, esto es un problema sustancial de corrección y no solo de presentación. Además, la demostración con dos funciones de error es más formal y densa que las explicaciones de A y C, aunque está explicada y no llega a impedir seguir el argumento. Su fortaleza es la derivación explícita del producto sin cancelar el cambio interior.

Los tres materiales son matemáticamente correctos en sus explicaciones centrales y cubren el alcance pedido. El error de B está localizado en la clave de una pregunta adicional, no en la regla enseñada. Un lector que prefiera una justificación más algebraica podría preferir B; uno que valore separar con más énfasis los datos de una tabla podría preferir A. Esas preferencias estrecharían la elección, pero no eliminan el problema de retroalimentación de B.
