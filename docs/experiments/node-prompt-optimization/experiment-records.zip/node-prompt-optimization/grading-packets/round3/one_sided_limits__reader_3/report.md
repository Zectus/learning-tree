# Evaluación de las lecciones

## Puntuaciones

| Lección | Claridad conceptual | Andamiaje y ritmo | Razonamiento y transferencia | Aprendizaje activo | Corrección | Total / 10 |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.3 | 9.2 | 9.2 | 9.3 | 10.0 | 9.40 |
| B | 9.4 | 9.5 | 9.5 | 9.3 | 10.0 | 9.54 |
| C | 9.4 | 9.4 | 9.3 | 9.3 | 10.0 | 9.48 |

**Ranking:** B, C, A. **Confianza:** alta; las tres lecciones son sólidas y la diferencia entre las dos primeras es pequeña.

## Evidencia y comparación

**B** queda primera por el desarrollo más completo de la regla central. Explica por qué cada dirección del criterio funciona: un límite bilateral cubre ambos lados, y dos laterales iguales permiten escoger una cercanía que funcione a ambos. La tabla de la primera sección ofrece ejemplos numéricos sin presentarlos como demostración; luego las fórmulas justifican por qué las alturas se mantienen al acercarse más. Las preguntas también recorren tareas distintas: calcular laterales, decidir entre casos con datos parciales, distinguir hueco de salto y encontrar un parámetro. Su rasgo docente más fuerte es esa progresión desde la observación hasta la justificación y la aplicación. La debilidad más importante es menor: la sección del salto podría abordar explícitamente la tentación de promediar las dos alturas, que A sí corrige.

**C** queda segunda por su explicación clara del criterio y su advertencia útil de que el punto dibujado o ausente no decide por sí solo el límite. Sus preguntas comprueban varias confusiones relevantes: si el valor puntual puede reparar laterales distintos, si un hueco impide el límite y si se puede promediar. La práctica con parámetro amplía la transferencia. Su punto más fuerte es conectar con precisión las reglas por tramos, el gráfico y la diferencia entre valor puntual y comportamiento cercano. Frente a B, la prueba verbal del criterio está algo más comprimida y la secuencia ofrece menos apoyo numérico intermedio; es una diferencia pequeña de andamiaje, no un error matemático.

**A** ofrece una explicación especialmente buena de por qué un salto no se arregla tomando el promedio, y deja claro que cambiar solo el valor en el punto no aproxima las ramas entre sí. También propone una tarea de parámetro bien resuelta y práctica adicional variada. Su mayor debilidad relativa es que el criterio se explica con menos desarrollo que en B: el argumento de que los dos lados iguales cubren cualquier entrada próxima está presente, pero menos desplegado. La tabla breve de B también facilita comprobar el acercamiento paso a paso. Aun así, la presentación es clara y no tiene errores sustantivos.

Las tres lecciones mantienen correctamente la distinción entre límites laterales y bilaterales, explican por qué se puede cancelar en un hueco cuando (x\ne a), y dejan claro que el valor puntual no determina el límite. No encontré errores matemáticos ni problemas de alcance. Para un estudiante que prefiera ejemplos numéricos antes de generalizar, B podría ser aún más atractiva; quien valore una refutación explícita de la idea del promedio quizá prefiera A. Cualquier preferencia así podría cambiar la elección personal, pero no altera mi orden general.
