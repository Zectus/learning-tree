# Evaluación comparativa

| Lección | Claridad conceptual | Andamiaje y ritmo | Razonamiento y transferencia | Aprendizaje activo | Corrección | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 9.1 | 9.4 | 9.3 | 10.0 | 9.44 |
| B | 9.6 | 9.5 | 9.7 | 9.5 | 10.0 | 9.66 |
| C | 9.5 | 9.5 | 9.5 | 9.6 | 10.0 | 9.62 |

**Orden:** B, C, A. **Confianza:** moderada; las tres son lecciones sólidas y las diferencias son pequeñas.

## B

B queda primera por la combinación más completa de motivación, demostración y transferencia. El ejemplo del cuadrado empieza con unidades y tasas, y luego calcula exactamente \(\Delta A=30\Delta t+9(\Delta t)^2\), mostrando por qué el término cuadrático desaparece en la tasa instantánea sin dividir por \(\Delta u\). Después, la explicación general añade el control del error necesario para justificar la composición. El ejemplo de \((x^2+3x+1)^5\), la tabla que exige consultar \(f'(g(1))\), y el ejercicio bonus que compara \(f(g(x))\) con \(g(f(x))\) permiten transferir la regla a formas distintas.

Su punto más fuerte es esa secuencia de un caso concreto exacto a la regla general y a tareas de transferencia. La debilidad más relevante es que la explicación abstracta del error y sus acotaciones es un tramo algo denso; un lector puede necesitar releerlo. Es una carga localizada, no un problema sustancial de comprensión: la intuición y los ejemplos circundantes la sostienen.

## C

C ofrece un recorrido especialmente legible. El gráfico del área, el producto de unidades y la expansión exacta \(\Delta A=12h+4h^2\) se refuerzan entre sí. La explicación posterior trata con cuidado los errores \(r\) y \(s\), aclara por qué no se cancela el cambio interior, y el ejercicio sobre \(K'(2)=0\) pese a que \(K(2+h)\ne K(2)\) comprueba una distinción conceptual importante. La pregunta de unidades de cable, la tabla de tasas y la composición anidada amplían la práctica.

Su rasgo más fuerte es conectar el significado de derivada nula con una función que sí cambia alrededor del punto. La limitación es que la derivación abstracta pasa con rapidez de las aproximaciones locales al límite; algunos lectores pueden seguir el procedimiento sin retener del todo por qué los errores desaparecen. En conjunto, sus preguntas y explicaciones alivian esa dificultad. Frente a B, la diferencia es pequeña: B hace más explícita la transferencia entre composiciones de orden distinto.

## A

A también es matemáticamente precisa y atiende bien a la evaluación correcta de la derivada exterior: aclara que \(f'(g(x))\) significa evaluar \(f'\) en la salida interior. La demostración con \(\varepsilon(h)\) y \(\eta(\Delta u)\) evita explícitamente dividir por un incremento interior que pueda ser cero. El ejemplo de una potencia de polinomio y las preguntas sobre datos tabulados y factores que se anulan proporcionan práctica pertinente.

Su mejor rasgo es la justificación cuidadosa de la regla precisamente en el caso problemático de incremento interior nulo. Su debilidad principal es el salto a esa notación de errores en la segunda sección: resulta más formal y menos acompañada por pasos intermedios que las explicaciones de B y C. No es un defecto matemático, pero para el lector promedio puede elevar la carga cognitiva y reducir la claridad del argumento. La estructura general sigue siendo comprensible.

Las tres lecciones son correctas en los cálculos y en el alcance descrito; no encontré errores sustantivos. Las diferencias de preferencia podrían alterar la elección: alguien cómodo con notación de límites y errores quizá prefiera la concisión formal de A; quien aprende mejor a partir de un ejemplo gráfico y de cambios explícitos podría preferir C. Para el lector promedio indicado, B da la progresión más equilibrada.
