# Evaluación de las lecciones

## Puntuaciones

| Lección | Claridad conceptual | Andamiaje y ritmo | Razonamiento y transferencia | Aprendizaje activo | Corrección | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9,7 | 9,6 | 9,6 | 9,7 | 10,0 | 9,72 |
| B | 9,7 | 9,7 | 9,7 | 9,7 | 10,0 | 9,76 |
| C | 9,6 | 9,6 | 9,6 | 9,6 | 10,0 | 9,68 |

**Ranking:** B > A > C. **Confianza:** alta en que las tres son lecciones muy eficaces; moderada en el orden de las diferencias pequeñas.

## Evidencia y tradeoffs

**B** queda primera por un margen estrecho. La progresión desde la tabla bilateral y la recta con hueco hasta la igualdad `f(x)-4=x-2` ofrece tanto intuición visual como una razón que abarca todas las entradas permitidas. Explica que no basta con unas entradas favorables y distingue con precisión el dato observado de la conclusión sobre el comportamiento cercano. Sus preguntas cubren interpretación, valor puntual frente a límite y límites de una tabla; el bonus final añade una transferencia útil: la salida queda al doble de distancia de 5 que la entrada de 1. Su rasgo docente más fuerte es esa variedad de práctica con razonamiento accesible. La debilidad más importante es menor: tras explicar la limitación de la tabla en la sección 3, vuelve a expresarla en varios términos, lo que hace esa parte algo reiterativa.

**A** ofrece una enseñanza casi igual de sólida. Destaca al separar explícitamente el resultado exacto `f(0,999)=1,999`, una aproximación numérica y el límite exacto 2; la relación `f(x)-2=x-1` da sustento general a la intuición. También hace que las preguntas exijan discriminar entre valor puntual, límite y evidencia finita. Su punto más fuerte es esa distinción concreta entre evaluación exacta y destino del acercamiento. Pierde unas centésimas frente a B porque la transferencia numérica adicional de sus ejercicios es algo menos variada; su práctica sigue siendo correcta y pertinente. No hay un problema sustancial de enseñanza.

**C** también construye bien la idea central: factoriza para obtener `f(x)=x+2` en el dominio permitido, usa `2+h` para mostrar cómo se relacionan las distancias, y retoma esa relación al explicar por qué la tabla sugiere pero no demuestra. La explicación del hueco reconoce adecuadamente la limitación gráfica. Su punto más fuerte es conectar el cambio de entrada `h` con el cambio de salida, y el bonus pregunta si el límite puede ser un valor que ninguna entrada alcance. La pequeña desventaja es de ritmo y precisión expositiva: la tabla incluye explícitamente la fila `x=2` con “No está definida”, aunque el foco son las entradas permitidas cercanas; queda bien rotulada y no es un error, pero interrumpe ligeramente la lectura de la secuencia de aproximación. Además, parte de la explicación sobre el hueco y las tablas repite ideas ya presentadas. No afecta la corrección ni impide aprender.

Las tres lecciones son matemáticamente correctas dentro del alcance informal. Ninguna presenta una tabla como demostración ni requiere conocimiento posterior. Las diferencias son de énfasis: B favorece a quien aprende con práctica de transferencia variada; A, a quien necesita fijar con claridad qué es un valor evaluado y qué es un límite; C, a quien le ayuda ver la perturbación `h` de forma explícita. Esa preferencia podría cambiar cuál resulta más cómoda, pero no altera mucho la valoración general: las tres son opciones excelentes para este lector.
