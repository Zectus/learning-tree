# Lesson evaluation

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding, pacing, and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.6 | 9.5 | 9.6 | 9.5 | 10.0 | **9.64** |
| B | 9.5 | 9.6 | 9.8 | 9.4 | 10.0 | **9.66** |
| C | 9.5 | 9.3 | 9.1 | 9.5 | 10.0 | **9.48** |

## Ranking and evidence

**B narrowly ranks first, A second, and C third. Confidence: moderate.** All three are accurate, readable lessons that teach the central distinction: a shared phase leaves the output probabilities unchanged, while a relative phase can change interference at the supplied recombination matrix. The gap is small between B and A; the more material difference is that C does not carry the derivation through to a general unequal-magnitude probability formula.

B’s strongest feature is its worked transfer beyond the balanced example. After deriving (P_R(0)=1/2+ab\cos\phi), it uses (a=3/5,b=4/5,\phi=\pi) to calculate both output probabilities and explain why cancellation is incomplete. It then solves backward for settings that produce (P_R(0)=1/2), making clear that distinct relative phases can share statistics in this arrangement. Its questions also practice global-phase equivalence, phase settings, and the possible range of an output probability. The main weakness is a little notation density when it shifts from the general complex entries \(\alpha,\beta\) to positive magnitudes \(a,b\), though it explicitly explains that shift. The bonus about applying the matrix twice extends beyond the core scope, but is clearly optional and correct.

A’s strongest feature is its direct and well-paced narrative: the opening pair demonstrates how equal direct probabilities conceal a sign difference, then the lesson builds from a global phase to a relative phase and finally derives the balanced and unequal cases. The unit-circle graph explains phase factor magnitude and explicitly says it is not a particle trajectory. The unequal-input derivation and numerical example provide useful transfer, while Question 4 distinguishes matching statistics in one arrangement from global-phase equivalence. Its main weakness is that the lesson’s active practice is mostly multiple-choice recognition or calculation, with fewer opportunities to explain reasoning in the reader’s own words. This is a modest limitation, not a breakdown in learning: the sequence includes several meaningful applications, and the math is precise.

C’s strongest feature is its careful explanation of the global-phase equivalence and its scope: it checks that the same factor must act on every component, shows that it factors through the matrix, and later distinguishes one arrangement’s inability to tell phases apart from physical equivalence. The graph and questions reinforce the balanced-phase curve and measurement limits. Its main teaching weakness is that the probability derivation and graph focus on equal magnitudes; it never derives or works through (P_0=1/2+r_0r_1\cos\phi) for general normalized magnitudes. That leaves less reusable guidance for the unequal case than A and B provide, despite the unequal-magnitude bonus. The reader could reconstruct it by applying the matrix directly, but the lesson supplies less scaffolding for that transfer.

All calculations and answer keys checked in the three lessons are consistent with the stated matrix and Born rule. No substantive correctness error changes the ranking. A learner who prefers a particularly careful treatment of global-phase equivalence before seeing the device may prefer C’s opening, while a learner who values a shorter route to the main interference calculation may prefer A. For broad worked transfer across input magnitudes, B has a slight edge.
