# Evaluation

| Lesson | Conceptual clarity | Scaffolding | Worked reasoning and transfer | Active learning | Correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 9.5 | 9.3 | 9.3 | 10.0 | 9.50 |
| B | 9.4 | 9.3 | 9.1 | 9.4 | 10.0 | 9.44 |
| C | 9.4 | 8.9 | 9.6 | 9.3 | 10.0 | 9.44 |

**Ranking:** A first; B and C tied second. The numerical gap is small, and confidence is **moderate**.

All three lessons accurately distinguish global from relative phase, apply the supplied recombination matrix before the Born rule, and correctly derive the phase-dependent output probabilities. Their calculations and answer keys are consistent. Each also appropriately limits the interpretation: the probabilities describe repeated preparations and do not reveal a trajectory. There is no substantive correctness or scope error.

**A** is the most smoothly scaffolded for this reader. It begins with a direct contrast between two states that look identical under direct measurement, then supplies a concrete unequal-amplitude example before introducing Euler’s formula and the general phase family. The calculation for ψ(φ) makes the cosine term visible, and the last section carefully distinguishes differing distributions from identifying a source in one run. Its questions check global-phase matching, recombination arithmetic, a non-equal phase case, and the limits of inference. The strongest feature is its clean conceptual progression. Its main weakness is that transfer beyond the equal-magnitude phase family is sampled more briefly than in C; the unequal-amplitude example illustrates reinforcement but does not develop a reusable general probability rule. This is a modest depth limitation, not a teaching failure.

**B** offers a particularly accessible opening and makes the procedure explicit: apply the device, then use the Born rule. Its cancellation of cross terms to show normalization is a useful check, and its global-phase argument is concise. The graph and questions give the reader several meaningful chances to predict outcomes, including a phase-adjustment problem and an optimization problem. The strongest feature is the direct, readable explanation of why adding amplitudes matters. Its main weakness is the thinner bridge from the equal-magnitude derivation to arbitrary unequal magnitudes: there is no worked unequal-amplitude case, so the transfer questions ask the reader to extend a pattern with less prior demonstration. That is a moderate scaffolding gap, while the lesson remains coherent and accurate.

**C** gives the most reusable mathematical account. It derives (P_R(0)=1/2+ab\cos\phi), works an unequal-magnitude example at φ=π, and then solves for phase settings that produce a target probability. This makes transfer to new magnitudes and target distributions especially strong. Its phase-circle graph also offers a clear visual way to connect angle and unit magnitude. The strongest feature is the progression from the general formula to a concrete prediction and an inverse problem. Its main weakness is density: it introduces the phase-factor graph and global-phase equivalence before returning to relative-phase interference, and Section 3 carries more notation and algebra at once than A or B. A careful learner can follow it, but the extra cognitive load slightly offsets its superior transfer support.

A reader who prefers concise, linear explanations is best served by A. A reader who wants a single general formula and practice using it to solve for phase settings may prefer C. B may appeal to someone who values a direct procedural explanation and many short checks. Those preferences could change an individual choice, but they do not outweigh A’s small overall advantage for the stated first-time learner.
