# Evaluación de las lecciones

| Criterio | A | B | C |
|---|---:|---:|---:|
| Claridad conceptual y motivación | 9.4 | 9.3 | 9.5 |
| Andamiaje, ritmo y carga cognitiva | 9.2 | 9.4 | 9.5 |
| Razonamiento trabajado y transferencia | 9.5 | 9.3 | 9.6 |
| Preguntas y oportunidades de aprendizaje activo | 9.0 | 9.4 | 9.4 |
| Corrección y precisión matemática | 9.8 | 9.9 | 9.9 |
| **Promedio** | **9.38** | **9.46** | **9.58** |

## Ranking

1. **C — 9.58**
2. **B — 9.46**
3. **A — 9.38**

Confianza: **media-alta**. Las diferencias son pequeñas; las tres enseñan correctamente la idea central y ofrecen práctica útil. C queda primero por conectar de manera especialmente directa la regla algebraica con la cercanía de las salidas y por ofrecer buena transferencia en la práctica adicional. B queda muy cerca y tiene una explicación particularmente clara de por qué una tabla finita no basta. A desarrolla una secuencia sólida, aunque una opción de una pregunta está redactada de forma confusa.

## Evidencia y tradeoffs

**C** empieza con muestras a ambos lados de 2 y explica con cuidado que el hueco es un solo punto y que el trazado no puede dibujar el círculo abierto. Su desarrollo de \(f(x)=x+2\) a \(f(x)-4=x-2\) muestra por qué las distancias de entrada y salida coinciden, y luego usa esa relación para justificar el límite, no solo para adivinarlo desde la tabla. La pregunta 3 distingue bien una tendencia sugerida de una conclusión demostrada, y el bonus 2 transfiere la comparación de distancias a un caso donde la salida cambia al doble de la distancia de entrada. Su punto más fuerte es ese hilo de razonamiento continuo, desde tabla y gráfica hasta afirmación exacta y nuevo caso. La principal limitación es menor: la frase general sobre salidas que pueden mantenerse próximas a \(L\) exige cierta atención para distinguirla de una mera colección de muestras, aunque el resto de la lección aclara esa diferencia.

**B** presenta una progresión muy manejable. La tabla, la gráfica y la cancelación de \((x-2)\) llevan a \(x+2\); el ejemplo \(x=2+h\) hace visible cómo se traslada una variación pequeña de entrada a la salida. La explicación de la sección 3 —«No hay una última entrada antes de 2»— es una forma accesible de desmontar la idea de que el límite es la última salida de una tabla. La pregunta 3 pide un informe prudente a partir de datos parciales y el bonus 2 separa correctamente límite y valor exacto. Su fortaleza es el ritmo y el tratamiento claro de las inferencias a partir de datos; tiene algo menos de desarrollo explícito de distancias que C y A, por lo que el paso a casos de transferencia queda un poco menos trabajado. No hay errores matemáticos relevantes.

**A** trabaja con detalle tanto la cercanía como el papel del valor puntual. Su identidad \(|f(x)-2|=|x-1|\) fundamenta la afirmación informal, y la sección 2 extiende bien la idea: cambiar el valor en 1 y también una asignación lejana en 20 no altera el límite en 1. La sección 3 y la pregunta 3 refuerzan que las muestras no determinan lo que ocurre en todas las entradas cercanas. Su mayor debilidad es la opción B de la pregunta 3, «distintas de 0 y 9 en 0», cuya redacción resulta difícil de interpretar y reduce la calidad de ese distractor. Aun así, la respuesta correcta y la idea evaluada son identificables; es un problema menor de redacción, no de matemáticas. El tratamiento del intervalo cercano ofrece un apoyo útil, aunque añade algo de carga frente a la secuencia algo más fluida de B y C.

Las tres evitan introducir la definición formal y no presentan las tablas como pruebas. C sería especialmente adecuada para quien aprende mejor siguiendo transformaciones algebraicas; B puede resultar más cómoda para quien necesita una explicación verbal de qué permiten concluir los datos; A puede atraer a quien se beneficia de trabajar con distancias y con cambios en puntos cercanos o lejanos. Esa preferencia podría cambiar la elección individual, pero no desplaza el orden general por calidad de enseñanza.
