# Independent lesson evaluation

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding, pacing, and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.2 | 9.0 | 8.8 | 9.2 | 10.0 | 9.24 |
| B | 9.4 | 9.3 | 9.6 | 9.4 | 10.0 | 9.54 |
| C | 9.1 | 8.8 | 8.7 | 9.1 | 10.0 | 9.14 |

**Ranking:** B, then A, then C. **Confidence: medium-high.** All three lessons are mathematically sound and teach the central distinction; the ordering reflects how well they equip a learner to predict cases beyond the equal-magnitude illustration.

## Evidence and tradeoffs

**Lesson B** is strongest overall because it makes the transfer rule explicit and then uses it in varied cases. It derives (P_0=1/2+rq\cos\phi) and (P_1=1/2-rq\cos\phi) from real and imaginary parts, explains the role of the cross term, and applies the result to unequal magnitudes (r=3/5,q=4/5), including the attainable probability range. This gives a reader a reusable method rather than only a result for one family. Its questions also test distinct skills: complex output calculation, global-phase comparison, phase optimization, and solving for phases consistent with a probability. The key limitation is density: global and relative phase, including the general component factorization, arrive together in Section 2 before the probability derivation. The prose is careful and the examples help, but a learner who needs to consolidate one distinction at a time may find that section busy. Its strongest feature is the general derivation plus concrete bounds; its main weakness is that concentrated conceptual load.

**Lesson A** gives the clearest staged narrative. It starts with same direct probabilities but different recombined outcomes, then isolates a common phase, and only afterward develops relative phase and interference. The unit-circle slider has a clear interpretive explanation, and the equal-magnitude probability graph is paired with an unequal-magnitude example. Questions cover output calculations, global equivalence, unequal-magnitude phase dependence, and the limits of inference from statistics. The notable transfer gap is that it does not derive the general unequal-magnitude probability rule; it gives one unequal example and asks a focused application, so learners have less support for predicting a broad range of inputs than in B. Its strongest feature is the accessible sequence and motivation; its main weakness is the less complete reusable treatment of unequal magnitudes.

**Lesson C** is accurate and conceptually careful. It explicitly distinguishes the supplied physical equivalence rule for global phase from what the calculations show, explains that the graph depicts separate preparations rather than a trajectory, and addresses what an interference result can and cannot establish. It also includes a useful unequal-amplitude worked calculation. However, it develops the interference formula only for equal magnitudes; learners must infer how the result generalizes, and the practice is correspondingly concentrated on that family plus isolated cases. The opening introduces global and relative phase before presenting the recombination device, which may leave a new learner waiting to see why relative phase matters. Its strongest feature is its careful limits on interpretation; its main weakness is the narrower worked transfer and sequencing of motivation.

There are no substantive mathematical errors in the presented calculations or answer keys. A's and C's unequal-magnitude examples, B's general formula and phase solutions, and the bonus results are consistent with the supplied matrix and Born rule. The gaps described above are teaching and transfer differences, not correctness defects.

A learner who prefers a slower, story-like progression and first wants a vivid demonstration before generalization may prefer A. A learner who values explicit formulas and being able to solve new unequal-magnitude cases is better served by B. C may suit someone who especially values careful limits on what measurements establish, though it offers less support for general calculation.
