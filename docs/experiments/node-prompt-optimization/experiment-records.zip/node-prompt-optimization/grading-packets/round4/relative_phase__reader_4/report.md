# Independent lesson evaluation

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding and cognitive load | Worked reasoning and transfer | Active learning | Correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 9.2 | 9.6 | 9.3 | 10.0 | 9.50 |
| B | 9.3 | 9.4 | 8.9 | 9.5 | 10.0 | 9.42 |
| C | 9.4 | 9.2 | 9.4 | 9.4 | 10.0 | 9.48 |

**Ranking:** A > C > B. **Confidence:** moderate; the lessons are close, with each making a different instructional tradeoff.

## Evidence and tradeoffs

**A** is the strongest overall for a learner who wants to build a reusable way to predict interference. It starts with the supplied matrix and a direct contrast between the plus and minus states, then develops the global/relative distinction, and derives the general result (P_0=1/2+rq\cos\phi), (P_1=1/2-rq\cos\phi). The unequal-magnitude example and the attainable range (1/50) to (49/50) make the formula useful beyond balanced inputs. Its discussion that equal cosines can produce the same statistics, that finite frequencies are not guaranteed, and that no trajectory follows from the calculation gives the result appropriate limits. The questions also progress from calculation to equivalence and phase optimization. Its main weakness is density: Section 2 introduces several conceptual points (unit-circle phases, factoring a common phase, and zero-component cases) before the next check, and the lesson has fewer main questions than B or C. The explanations remain readable for an engaged learner, so this is a modest pacing issue rather than a teaching failure.

**C** comes close to A. Its opening makes the matrix convention and the sequence “apply the matrix, then square magnitudes” especially explicit; it also verifies that the output probabilities sum to one. The balanced case is tied to specific graph locations, and the later unequal-magnitude derivation makes the general dependence concrete. The controlled lower-component phase question is a useful transfer task: the reader must apply a phase operation, then predict the recombined distribution. Its strongest feature is the connection between calculating a probability and understanding what can or cannot be inferred from it, including the cosine inversion and the ambiguity between phase angles. The main weakness is that the later inference discussion is somewhat compressed: after giving the inverse-cosine relation, the learner gets just one question about equal output distributions, rather than a check that practices recovering all compatible phases. The supplied derivations are sound and the gap is limited.

**B** has the most incremental practice and the clearest explicit question sequence. The opening example is followed by an arithmetic application; its global-phase section walks through a common multiplier; and its later questions check the general unequal-magnitude expression, statistical ambiguity, and optimization. The explanation that global-phase equivalence is a physical identification, with calculations showing its consequence for these measurements, is careful. Its most important weakness is transfer: unlike A and C, it does not derive the general unequal-magnitude probability formula. It illustrates an unequal complex input with equal output probabilities and asks the learner to use the formula for another case, leaving a small gap between the balanced derivation and the broader rule. That makes it slightly less complete for independent new cases despite its strong question scaffolding.

All three lessons are mathematically correct, including their keyed answers and bonus items. A different learner might prefer B's smaller steps and additional main-question checkpoints; a learner who benefits from a general formula and a worked route to unfamiliar magnitudes is better served by A or C. The ranking gives A a narrow edge for its complete derivation and transfer examples, with C nearly tied; B's additional practice does not fully offset the missing general derivation.
