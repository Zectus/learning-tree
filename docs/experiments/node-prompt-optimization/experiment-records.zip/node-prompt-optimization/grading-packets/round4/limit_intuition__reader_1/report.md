# Evaluación de las tres lecciones

## Puntuaciones

| Criterio (peso) | A | B | C |
|---|---:|---:|---:|
| Claridad conceptual y motivación (20%) | 9.3 | 9.5 | 9.5 |
| Andamiaje, ritmo y carga cognitiva (20%) | 9.2 | 9.2 | 9.5 |
| Razonamiento desarrollado y transferencia (20%) | 9.3 | 9.8 | 9.2 |
| Preguntas activas y oportunidades de retroalimentación (20%) | 9.4 | 9.5 | 9.4 |
| Corrección y precisión matemática (20%) | 10.0 | 10.0 | 10.0 |
| **Total (promedio simple)** | **9.44** | **9.60** | **9.52** |

**Ranking:** B > C > A. **Confianza:** media-alta. Las tres son lecciones sólidas y correctas; las diferencias son de énfasis didáctico, no de defectos graves.

## Evaluación

**B** ocupa el primer lugar porque convierte la idea informal en una herramienta para razonar sobre precisión, sin abandonar el ejemplo accesible. Después de derivar (f(x)=x+1), explica que |f(x)-2| coincide con |x-1|, y usa esa relación para justificar cómo obtener una diferencia menor que (0.01), incluidos los extremos excluidos y el ejemplo (x=1.004). La práctica del sensor vuelve a pedir que se distinga el límite (10) de la salida (10.008) y se calcule la diferencia (0.008). Es la transferencia más desarrollada de las tres: ayuda al lector a usar un límite para controlar una aproximación, no solo a reconocerlo.

Su principal coste es que este detalle cuantitativo hace la secuencia algo más densa que las otras, y la sección de precisión exige seguir varios números y distancias. El avance está bien preparado por la igualdad algebraica, por lo que no supone un problema sustancial para el lector previsto. Las preguntas cubren tendencias, independencia del valor puntual, cálculo de error y qué información justificaría un límite. Las dos preguntas de práctica adicional amplían de forma útil la evidencia de tablas y comparan tasas de acercamiento. No observé errores matemáticos.

**C** es una alternativa muy cercana y tiene el flujo más gradual. La igualdad (f(x)-2=x-1) aparece justo después de simplificar, enlazando el cálculo algebraico con la interpretación de distancia. Explica con claridad que una tabla sugiere pero no demuestra un límite, y su pregunta sobre (r) (sin fórmula ni información adicional) comprueba directamente esa distinción. También aborda el caso de un valor puntual distinto del límite y el de resultados vecinos que nunca son exactamente el límite. Su debilidad comparativa es que desarrolla menos la transferencia cuantitativa: el lector ve un ejemplo de distancias iguales, pero no practica cómo elegir entradas para conseguir una precisión dada. Las preguntas son pertinentes y alcanzables, aunque la práctica adicional principalmente consolida los conceptos ya tratados. La matemática es correcta en todo momento.

**A** enseña de modo claro y eficaz con el ejemplo ( (x^2-4)/(x-2)), incluida la explicación de por qué la cancelación solo vale para (x\ne2). Es especialmente fuerte al mostrar que muestras finitas no garantizan el comportamiento en todas las entradas cercanas: la pregunta 3 pide analizar una función que coincide con los datos dados pero cambia dentro de una vecindad aún más pequeña. Esto convierte una cautela abstracta en un contraejemplo concreto y útil. Además, separa expresamente el valor calculado (3{,}99), su uso como aproximación y el límite (4).

Su principal debilidad es que la presentación del gráfico y el hueco tiene que corregir varias veces una limitación visual del formato: aunque la recta aparezca continua, falta un único punto. La explicación es correcta y necesaria, pero la reiteración añade algo de carga. Además, la transferencia se concentra en reconocer y explicar la idea; no desarrolla una aplicación de precisión tan clara como B. Sus preguntas sí son diversas y razonables, y no encontré inexactitudes matemáticas.

La elección podría cambiar según la preferencia del lector: quien quiera aprender a traducir un límite en una precisión numérica concreta probablemente preferirá B; quien valore una introducción más gradual y una pregunta muy explícita sobre los límites de una tabla podría preferir C; A puede resultar especialmente convincente para quien aprende con contraejemplos. Las diferencias no justifican afirmar que alguna lección sea deficiente.
