# Evaluation

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding, pacing, and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 9.3 | 9.1 | 9.2 | 10.0 | 9.40 |
| B | 9.3 | 9.5 | 9.3 | 9.4 | 10.0 | 9.50 |
| C | 9.5 | 9.0 | 9.7 | 9.5 | 10.0 | 9.54 |

**Ranking:** C > B > A. **Confidence:** moderate; all three are strong, and the differences are narrow.

## Evidence and tradeoffs

**C** has the strongest transfer from a specific interference demonstration to a general method. It derives (P_0=1/2+rq\cos\phi) and (P_1=1/2-rq\cos\phi), then uses the (3/5,4/5) example to show how unequal magnitudes bound the possible redistribution. Its later question asks the reader to optimize an output probability while distinguishing relative phase from a global control, and the bonus asks them to invert the formula to find compatible phases. These are useful applications of the derivation. Its main weakness is pacing: it opens with the device and interference before establishing global phase, then places the broader phase explanation and unit-circle graph in Section 2. That ordering is coherent, but the second section is conceptually dense and may make a first-time reader hold several distinctions at once.

**B** has the smoothest step-by-step progression. It defines the measurement procedure carefully, works the opening sign example, adds an unequal-magnitude numerical example, and then derives the phase-dependent probabilities. Its fourth question usefully checks the subtle point that different relative phases can yield the same distribution for this device. The main weakness is that it never generalizes the interference formula to arbitrary input magnitudes; the worked unequal example illustrates reinforcement, but the lesson leaves the reader with less reusable quantitative guidance than C. The bonus questions add worthwhile transfer, especially applying (R) twice.

**A** builds the key distinction particularly cleanly: it introduces global phase and a common-factor test before showing why a relative sign matters after recombination, then carries that through a continuously adjustable phase and a careful discussion of what detection can establish. The global-phase invariance calculation for a general linear recombination is a strong conceptual anchor. Its weakness is a lighter treatment of unequal magnitudes and transfer beyond the equal-magnitude phase family; the bonus does ask for a maximum with unequal magnitudes, but that optimization receives no preceding general formula or worked setup. The reader can infer it, though the support is thinner than in B or C.

All three lessons are mathematically accurate in the supplied scope, correctly apply the Born rule after recombination, and avoid inferring a trajectory. C leads on quantitative generalization and transfer; B is the most gradual; A offers an especially clear early account of global phase. A learner who prefers to establish the global-versus-relative distinction before meeting interference may prefer A, while a learner who benefits from a gentler sequence may prefer B. No material correctness problem changes the ranking.
