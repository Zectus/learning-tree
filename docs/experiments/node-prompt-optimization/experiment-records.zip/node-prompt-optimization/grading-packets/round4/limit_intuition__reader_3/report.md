# Evaluación de las lecciones

| Lección | Claridad conceptual | Andamiaje y ritmo | Razonamiento y transferencia | Aprendizaje activo | Corrección | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.1 | 9.0 | 9.1 | 9.0 | 10.0 | 9.24 |
| B | 9.3 | 9.2 | 9.4 | 9.3 | 10.0 | 9.44 |
| C | 9.6 | 9.3 | 9.6 | 9.5 | 10.0 | 9.60 |

**Ranking:** C > B > A. **Confianza:** alta.

Las tres lecciones son matemáticamente correctas y enseñan bien la distinción central entre el comportamiento cercano y el valor en el punto. La diferencia está en cuánto ayudan a un lector a justificar y reutilizar esa distinción. C ofrece la explicación más completa; B le sigue de cerca porque convierte los límites de una tabla en una idea explícita; A tiene buen ritmo y ejemplos claros, con algo menos de desarrollo de esa cautela.

**C** destaca por conectar la factorización con una relación precisa entre distancias: \(|f(x)-2|=|x-1|\). La frase que interpreta el valor absoluto como distancia y el ejemplo \(|1{,}9-2|=0{,}1\) hacen utilizable esa relación, en vez de dejarla como manipulación simbólica. Después la reaplica para elegir una entrada con precisión menor que \(0{,}01\). También amplía bien la idea de “cerca”: explica intervalos alrededor de 1 y muestra que cambiar el valor en 20 no afecta el límite en 2. Sus preguntas practican cálculo del límite, independencia del valor puntual y por qué cuatro muestras no prueban una tendencia; la pregunta 3 ofrece un contraejemplo concreto compatible con los datos. La pequeña carga adicional de valor absoluto e intervalos se introduce con explicación y ejemplos, así que no resulta un problema sustancial para este lector.

**B** tiene como fortaleza más distintiva su tratamiento de la evidencia: afirma que una tabla y una gráfica finitas no determinan lo que pasa arbitrariamente cerca, y la pregunta 3 pide identificar una regla que contradice la conclusión a partir de cuatro mediciones. La cancelación algebraica y la descripción de salidas a la misma distancia que las entradas sustentan el ejemplo inicial. La pregunta 2 practica con claridad el par límite/valor. Su punto más débil es que desarrolla menos la conversión de la idea informal en una herramienta de precisión que C: la aproximación se explica mediante el caso 3,99 y una diferencia de una centésima, pero no se reutiliza para escoger una entrada con una tolerancia solicitada. Es una oportunidad de transferencia menos desarrollada, no un error.

**A** ofrece un recorrido muy accesible y bien pautado: tabla, gráfica, factorización, notación del límite, valor puntual y aproximación concreta. Su explicación de que cada distancia de entrada a 1 se conserva como distancia de salida a 2 conduce de manera limpia al ejemplo de precisión 0,01. La comparación de las funciones \(u\) y \(v\) en el bonus también da una transferencia útil sobre tasas de acercamiento. La debilidad relativa es que la limitación de las tablas queda más concentrada en una sola frase (“sugiere, pero no demuestra”) y en el bonus; no hay una actividad principal que pida construir o reconocer un comportamiento cercano que contradiga un conjunto de muestras. Además, la pregunta 1 parte de una tabla sugerente sin enfatizar tanto como B y C qué otras reglas podrían ajustarse a ella. El texto sí advierte que las filas no prueban el patrón, por lo que esto es una diferencia de énfasis, no una afirmación incorrecta.

Un lector que prefiera una ruta más compacta y menos notación podría elegir A: conserva el núcleo y guía con soltura la interpretación básica. Para un lector que quiera una justificación explícita y práctica de precisión, C es la mejor opción; B será especialmente atractiva si le interesa evaluar qué se puede concluir de datos finitos.
