# Evaluación de las lecciones: límite informal

## Puntuaciones

| Criterio | A | B | C |
|---|---:|---:|---:|
| Claridad conceptual y motivación | 9.1 | 9.5 | 9.0 |
| Andamiaje, ritmo y carga cognitiva | 9.2 | 8.9 | 9.2 |
| Razonamiento trabajado y transferencia | 9.0 | 9.6 | 8.9 |
| Preguntas y oportunidades de retroalimentación | 9.1 | 9.4 | 8.9 |
| Corrección y precisión matemática | 10.0 | 10.0 | 10.0 |
| **Promedio** | **9.28** | **9.48** | **9.20** |

**Ranking:** B > A > C. **Confianza:** media-alta; las diferencias entre A y C son pequeñas.

## Discusión

**B** enseña con mayor precisión cómo el patrón observado se extiende a entradas cercanas. Tras simplificar la expresión, establece \(|f(x)-2|=|x-1|\), explica el valor absoluto como distancia y usa esa igualdad para responder a una meta concreta: obtener una salida a menos de \(0{,}01\) de 2. Es el vínculo más fuerte entre intuición, cálculo exacto y una acción transferible. Sus preguntas también hacen trabajar distinciones útiles: cambiar el valor puntual y una asignación distante (Pregunta 2), y construir una regla que concuerda con muestras finitas pero tiene otro límite (Pregunta 3). Su principal debilidad es la densidad: la notación de valor absoluto, los intervalos y varias precisiones conceptuales aparecen en una primera lección. La explicación local ayuda a que esa demanda sea manejable, aunque un lector que prefiera una entrada más liviana podría preferir A.

**A** ofrece el recorrido más fluido: tabla, gráfica, simplificación algebraica, notación del límite y después la separación entre límite, valor puntual y evidencia finita. La sustitución \(x=2+h\) para obtener una salida \(4+h\) es una explicación compacta e intuitiva de por qué la distancia se conserva. La advertencia de que una tabla finita solo propone una conjetura está bien conectada con la regla algebraica que sí cubre todas las entradas permitidas. Sus preguntas prueban tanto el cálculo como esa interpretación. Su límite comparativo es que no desarrolla la relación de distancias tan explícitamente como B; por eso da menos apoyo para elegir entradas con una precisión de salida deseada. Es una diferencia de profundidad, no un error.

**C** también presenta correctamente tabla, hueco, regla algebraica y valor en el punto. Destaca la explicación de que el acercamiento compara cuánto se apartan la entrada y la salida, y su Pregunta 3 proporciona un contraejemplo eficaz: una función puede coincidir con las cuatro mediciones y cambiar a 6 en todas las entradas a menos de \(0{,}001\) de 1, por lo que las muestras no determinan el límite. La sección sobre modificar el valor puntual es clara. Frente a A y B, ofrece menos práctica independiente: tiene tres preguntas principales y un ejercicio de práctica adicional, y su primera pregunta pide leer lo que una tabla sugiere, pero no aprovecha tanto la ocasión para hacer que el lector traduzca una regla dada a un límite. La explicación de la distancia también queda menos formalizada que en B. Estas son limitaciones moderadas de transferencia y práctica; no hay un problema matemático sustantivo.

Los tres conjuntos de cálculos y respuestas son correctos. En particular, B calcula bien que con \(x=4{,}001\) la salida queda a \(0{,}003\) de 10, y las preguntas de contraejemplo en B y C sí respetan las muestras indicadas.

La elección podría variar por preferencia: quien valore la justificación cuantitativa y la precisión de B probablemente aprenderá más de ella; quien quiera una explicación más ligera y continua puede preferir A. C puede atraer a quien responda bien a contraejemplos concretos, aunque su práctica es algo menos amplia.
