# Lesson evaluation

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding, pacing, and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.7 | 9.5 | 9.8 | 9.4 | 10.0 | **9.68** |
| B | 9.6 | 9.6 | 9.6 | 9.7 | 10.0 | **9.70** |
| C | 9.5 | 9.5 | 9.2 | 9.6 | 10.0 | **9.56** |

**Ranking:** B > A > C. **Confidence:** moderate; the differences are small, and all three lessons teach the node very well.

## Evidence and tradeoffs

All three lessons accurately distinguish amplitudes from probabilities, show why a common phase cancels from measured probabilities, and explain how a relative phase can change recombination results. Their calculations, normalization, probability ranges, and answer keys are correct. Each also appropriately limits the model to final outcome statistics and avoids claiming a trajectory between preparation and measurement.

**Lesson B ranks first by a narrow margin.** Its strongest feature is the sequence from the supplied matrix and the two opening cases, through global versus relative phase, to balanced and unequal inputs. In Section 3 it works the balanced probability from Euler's formula, then derives the unequal-magnitude rule and applies it numerically. The questions extend that path: the lower-component phase change in Question 3 tests use of the rule, while Question 4 asks readers to distinguish equal statistics from global-phase equivalence. That creates the most sustained active practice and feedback opportunity of the three. Its main weakness is that the relative-phase definition and earlier global-phase reasoning arrive together in Section 2, which makes that section somewhat denser. The equations and examples keep that load manageable.

**Lesson A is a close second.** Its strongest feature is transfer: after deriving the general unequal-magnitude output probabilities, it uses them both to predict an unequal-amplitude case at phase \(\pi\) and to solve backward for phase settings that give probability one half. It explicitly explains that distinct phases can produce the same statistics in this particular measurement, without implying equivalence. This is excellent, connected reasoning. Its main weakness is that the core section offers fewer required checks along the way than B; the questions are useful, but there is less practice on the transition from the balanced family to the unequal-magnitude rule and its limits. The bonus questions help address this. The concise presentation itself is not a problem for an engaged reader.

**Lesson C is also strong.** Its strongest feature is its careful distinction between what a probability prediction says and what it cannot establish: the worked discussion and Question 4 make clear that matching output distributions do not prove two states differ only by a global phase. It also derives the equal-magnitude formula carefully and gives an unequal-magnitude question. Its main weakness is that the unequal case receives less worked development than in A and B. The example with \((1,3i)/\sqrt{10}\) shows equal output probabilities, but does not derive the general unequal-magnitude expression or demonstrate a phase-dependent unequal case before Question 3 asks the learner to use that expression. A reader can solve it from the matrix, but the transfer path is less explicit.

The B–A gap is small: readers who value the general formula, inverse reasoning, and the explicit unequal-amplitude worked prediction may prefer A. Readers who benefit from more frequent checkpoints and questions about interpreting evidence may prefer B. C is a sound choice for a reader who particularly values the careful discussion of limits on inference, despite its lighter scaffolding for unequal inputs.
