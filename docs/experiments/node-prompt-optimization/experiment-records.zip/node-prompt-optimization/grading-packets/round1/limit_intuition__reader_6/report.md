# Independent lesson evaluation

## Scores

Each criterion is scored from 0 to 10 and weighted equally.

| Lesson | Conceptual clarity and motivation | Scaffolding and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 9.3 | 9.5 | 9.4 | 10.0 | 9.52 |
| B | 9.5 | 9.5 | 9.6 | 9.5 | 10.0 | 9.62 |
| C | 9.5 | 9.4 | 9.5 | 9.4 | 10.0 | 9.56 |

**Ranking:** B, C, A. **Confidence:** Moderate; the differences are modest, and all three are strong lessons for this reader.

## Discussion

**Lesson B — strongest overall.** Its strongest feature is how it repeatedly distinguishes evidence from conclusion while still showing why the example works. The factorization is restricted correctly to (x
e1), and (f(x)-2=x-1) connects input and output distances for every permitted input. The later distinction between an exact table entry, an approximate comparison ((approx)), and an exact limit statement is especially useful. Question 3 then asks the reader to apply that distinction to exact but finite data, and Bonus 2 transfers the idea to two functions whose deviations from 5 have different scales. The main weakness is minor: the lesson’s initial table omits an explicit “not defined” row at (x=1), so that fact must be taken from the formula and graph description. It nevertheless states the exclusion clearly and avoids implying that cancellation defines the missing value.

**Lesson C — a close second.** Its strongest feature is its concise, well-connected reasoning: it explains the graph’s missing point, preserves the domain condition through cancellation, and explicitly says that a few favorable inputs do not establish the behavior of nearby inputs. The final bonus asks the learner to relate the exact evaluation (q(1{,}001)=4{,}998) to the limit 5 using the factor-of-two distance relation; this is an especially good transfer check. The central weakness is that Section 3’s numerical table discussion is somewhat compressed compared with B’s explicit treatment of exact values versus approximate values and rounded displays. This is a small teaching distinction, not a correctness problem.

**Lesson A — also strong.** Its strongest feature is the clear first example: the table includes the undefined input, and the equation (f(x)-4=x-2) directly justifies the claimed trend. Section 2 gives a concrete changed point value, then explains both that the limit can persist and that it can coincide with the function value; the questions cover these distinctions well. Its most important weakness is a small precision gap in its general description: it says to take inputs sufficiently close to (a), distinct from (a), but does not explicitly say “within the domain” as B and C do. The surrounding example and explanation make the intended meaning recoverable, so this is not a substantive scope error. Its additional section and practice are useful, though they do not add quite as much new reasoning as B’s comparison of differently scaled deviations or C’s final numerical evaluation.

All three have accurate algebra, careful treatment of the excluded point, and achievable questions with supplied answer feedback. I found no substantive mathematical or scope error. A learner who prefers a more compact progression and a worked numerical transfer check might prefer C; a learner who wants the distinction between exact data, approximation, and a limit emphasized would likely prefer B. Those preferences could change an individual choice without materially changing the close ranking.
