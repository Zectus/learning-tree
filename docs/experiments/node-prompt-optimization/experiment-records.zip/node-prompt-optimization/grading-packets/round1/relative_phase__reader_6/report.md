# Evaluation: Global Phase, Relative Phase, and Interference

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding, pacing, and cognitive load | Worked reasoning and transfer | Active learning | Mathematical correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.7 | 9.4 | 9.5 | 9.6 | 10.0 | 9.64 |
| B | 9.5 | 9.7 | 9.6 | 9.5 | 10.0 | 9.66 |
| C | 9.5 | 9.2 | 9.5 | 9.4 | 10.0 | 9.52 |

**Ranking:** B, A, C. B leads A by a very small margin; confidence is **moderate**. All three lessons teach the central mathematics accurately. The differences are mainly about how examples and interpretive points are staged.

## Evidence and tradeoffs

**Lesson B** has the clearest progression from the same direct probabilities, through the supplied recombiner, to phase-dependent predictions. Its unequal-magnitude slider makes a useful transfer point concrete: varying the magnitude changes the range of (P_0), and the text explains why the range is limited. The worked φ = π/3 case and the unequal-magnitude formula give readers both a numerical anchor and a method they can reuse. Questions test calculation and conceptual distinctions, including Q3's comparison of two different states with the same output distribution. The main limitation is that it says less than A about what one output distribution can and cannot establish about the input; this is a small coverage difference, not a defect in its core account.

**Lesson A** is exceptionally clear about interpretation. Its first example explicitly distinguishes a direct-measurement experiment from a recombination experiment, and Section 4 carefully explains why equal statistics in this one measurement do not establish equal physical states. Q4 turns that limitation into an achievable reasoning task. The unequal-magnitude derivation and the φ = 2π/3 calculation also support transfer. Its main weakness relative to B is that the graph only displays the equal-magnitude case, while B's additional slider graph helps an engaged reader explore how imbalance limits interference. A is otherwise accurate and well scaffolded. A reader especially interested in inference limits might reasonably prefer A.

**Lesson C** gives a strong account of the distinction between global and relative phase, correctly derives both equal-magnitude probabilities, and includes a helpful unequal-amplitude worked example. It also explicitly cautions that the graph represents different preparations rather than a trajectory. Its most notable limitation is sequencing: it introduces global phase before the recombination operation shows why relative phase matters, which may delay the motivation for some readers. Its Bonus 1 key is correct: with (b=-a), the first output amplitude (a+b) is zero, and for normalized |a| = (1/\sqrt2), output 1 occurs with certainty. Readers who prefer definitions before examples may find C's ordering useful.

No lesson has a substantial error in its central probability derivations or answer keys. The decisive tradeoff is B's slightly stronger scaffolding for active exploration versus A's more explicit treatment of what interference statistics establish. Different learner preferences could swap B and A; C is also a strong option for readers who prefer the phase concepts introduced before the recombination example.
