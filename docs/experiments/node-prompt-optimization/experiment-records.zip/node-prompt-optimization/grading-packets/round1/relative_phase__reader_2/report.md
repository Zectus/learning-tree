# Lesson evaluation

| Lesson | Conceptual clarity | Scaffolding | Worked reasoning and transfer | Active learning | Correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.2 | 9.0 | 8.8 | 9.0 | 10.0 | 9.20 |
| B | 9.4 | 9.1 | 9.5 | 9.2 | 10.0 | 9.44 |
| C | 9.2 | 9.3 | 9.1 | 9.1 | 10.0 | 9.34 |

Ranking: **B > C > A**. Confidence: **moderate**. All three are strong, accurate lessons; the gaps are small and reflect differences in how much supported transfer they provide. No substantive mathematical or scope errors stood out.

**B** is the strongest overall for this reader. It establishes the meanings of amplitudes, phase, and global phase, then explains the supplied recombination matrix and derives its output probabilities before moving to the continuously variable phase case. Its worked unequal-magnitude extension, (P_0=1/2+rs\cos\phi), makes the central result usable beyond the equal-magnitude example; the accompanying explanation of why unequal contributions cannot cancel completely is especially helpful. The bonus maximum-probability problem gives practice using that extension. The main weakness is density: Section 1 introduces Euler's formula, phase factoring, ratios, and zero-component qualifications before the recombination device has made their purpose concrete. For a careful reader this is manageable, but it asks for more abstract setup up front.

**C** is a close second and has the best visual introduction to phase. Its unit-circle graph connects the angle to a complex number's real and imaginary parts, and the text explains what the slider and marker represent. The global-versus-relative-phase explanation then uses that picture well, and the worked φ=π/3 prediction turns the derived formula into a direct example. Its questions probe meaningful distinctions, including that π/4 and 7π/4 yield the same distributions in this device. Its most important limitation is that the transfer beyond equal magnitudes appears mainly in the bonus question rather than being derived in the lesson body, so the core teaching gives slightly less guided practice with arbitrary inputs than B.

**A** is clear and well paced. It starts with the physically relevant distinction between two preparations that direct measurement cannot tell apart, gives a concrete unequal-amplitude calculation, and later states carefully that an interference distribution does not determine a unique input or reveal a trajectory. Its questions are well aligned with those ideas. Its main weakness is thinner transfer scaffolding: the equal-magnitude phase family is derived explicitly, but the general two-nonzero-component case is mostly described through phase factoring, rather than worked through to a general output-probability expression. The learner gets fewer bridges from the central derivation to new amplitude and phase combinations than in B.

Each lesson's answer keys appear correct. B's bonus calculation correctly uses the largest value of (1/2+rs\cos\phi); C's phase-choice and unequal-magnitude questions follow from its stated formulas; and A's phase and recombination calculations are consistent. The graph descriptions in C and the probability graphs in A and B support the text; none depends on unsupported graph behavior. The app's filled point markers do not create a learning issue here.

A learner who prefers a visual, geometric account of complex phase may prefer C. A reader who wants a brisker route from the motivating example to the main interference result may prefer A. For the stated actively engaged first-time reader, B's extra derivation and transfer practice make it the best choice, with a modest cost in early density.
