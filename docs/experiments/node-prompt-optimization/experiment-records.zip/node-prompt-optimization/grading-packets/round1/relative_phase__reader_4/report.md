# Evaluation

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding, pacing, and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.3 | 9.1 | 9.2 | 9.2 | 10.0 | 9.36 |
| B | 9.5 | 9.3 | 9.5 | 9.5 | 10.0 | 9.56 |
| C | 9.4 | 9.3 | 9.3 | 9.4 | 10.0 | 9.48 |

**Ranking:** B > C > A. **Confidence: moderate.** The lessons are all strong, and their differences are mostly in how much guided practice and interpretation they provide.

## Evidence and tradeoffs

**Lesson B** ranks first by a small margin. It builds a clear chain from equal direct probabilities, through the supplied recombination matrix, to interference and phase-dependent output probabilities. It explicitly distinguishes a direct measurement from the later recombination experiment, and its worked φ = 2π/3 example shows the complex amplitude and its squared magnitude numerically. The later section explains the limits of inference from an output distribution, then asks the reader to identify both compatible phases; this is useful transfer beyond formula substitution. Its strongest feature is this combination of worked calculation and interpretation. Its main weakness is density: the global-phase section reaches the general claim about every measurement, and the final interpretation section adds identifiability, so a first-time learner has several new distinctions to hold alongside the main calculation. This is a pacing cost, not a correctness problem.

**Lesson C** is a close second. Its unit-circle graph gives Euler's formula a concrete geometric interpretation, and it carefully states that the graphic represents complex numbers rather than a particle path. The derivations for balanced and unequal inputs are sound, and the question about opposite phase angles tests whether the reader understands that matching output statistics do not imply global-phase equivalence. Its strongest feature is connecting the phase factor's constant magnitude to a visual model, then returning to phase differences in the experiment. Its main weakness is that the unequal-magnitude result is illustrated by a single numeric setting rather than a graph or a worked range example; readers get less support for seeing how the product (rs) controls the full variation. This is a modest transfer gap, not a substantial teaching problem.

**Lesson A** gives a particularly direct introduction and a useful unequal-magnitude slider graph. The progression from the ± sign example to the balanced formula and then to unequal magnitudes is easy to follow. Its strongest feature is the interactive graph showing how changing one magnitude changes the size of the probability oscillation. Its main weakness is that its worked balanced example (φ = π/3) largely substitutes into the already-derived formula, while the more numerically explicit complex-amplitude example appears only in the question set. It also offers less discussion of what can and cannot be inferred from observed output statistics than B and C. Neither issue blocks the central understanding.

All three lessons are mathematically accurate in their stated scope, and their embedded answer keys match the calculations. None makes a substantive scope error: each treats the recombination matrix as supplied, avoids inferring a trajectory, and describes probabilities as predictions for repeated preparations. The small score gaps reflect teaching support and interpretation, not mathematical defects.

A learner who prefers visual exploration over extended verbal explanation might choose A for its unequal-magnitude slider, or C for its unit-circle picture. A learner who benefits from worked numerical steps and explicit discussion of ambiguous inference is more likely to prefer B.
