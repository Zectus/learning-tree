# Evaluación de las lecciones

## Puntuaciones

| Lección | Claridad conceptual | Andamiaje y ritmo | Razonamiento y transferencia | Preguntas y oportunidades de feedback | Corrección y precisión | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.5 | 9.3 | 9.4 | 9.2 | 10.0 | 9.48 |
| B | 9.0 | 9.0 | 9.3 | 9.2 | 10.0 | 9.30 |
| C | 9.6 | 9.4 | 9.5 | 9.4 | 10.0 | 9.58 |

**Clasificación:** C, A, B. **Confianza:** media-alta; las tres enseñan bien el nodo y la diferencia entre ellas es pequeña.

## Evidencia y tradeoffs

**C** queda primera por hacer visible la cadena entre tabla, simplificación algebraica y significado del límite. En el ejemplo, (f(x)-4=x-2) muestra directamente cómo se relacionan ambas distancias para cualquier entrada permitida; después se explica que la tabla solo propone un candidato. La cuestión sobre salidas redondeadas a (10{,}00) refuerza con un caso realista que la evidencia numérica finita no demuestra el límite. La distinción entre (g(2)=9) y el límite (4), junto con la práctica de cambiar solo el valor puntual, añade transferencia útil. Su mayor fortaleza es esa explicación conectada y reutilizable; su debilidad más importante es que requiere mantener varias representaciones y expresiones por casos en una lección relativamente densa. La gráfica no marca puntos, aunque el texto explica con precisión esta limitación y sitúa el punto añadido fuera de la ventana.

**A** queda muy cerca. Su mayor fortaleza es la progresión limpia desde la tabla al hueco y luego a una igualdad de distancias muy concreta: en el ejemplo, |f(x)-2|=|x-1|, incluso con el ejemplo de estar a menos de (0{,}01). Las tres preguntas principales comprueban comprensión, distinción entre límite y valor, y cautela ante datos finitos; el bonus de la función constante cerca del punto amplía bien la idea. Su principal limitación relativa es que la tercera sección es algo breve: advierte por qué una tabla no garantiza el comportamiento, pero no explora un contraejemplo tan tangible como el de B, donde una función coincide en las mediciones y cambia en una vecindad aún más pequeña. La explicación del gráfico y del punto excluido es especialmente cuidadosa.

**B** también construye una secuencia sólida: factorización válida solo para (x\ne2), lectura del hueco y comparación entre valor puntual y comportamiento cercano. Su mejor recurso de transferencia es la pregunta 3: una función puede coincidir con las cuatro mediciones y cambiar dentro de una distancia de (0{,}001), de modo que el supuesto límite no queda asegurado. La cuestión tabular inicial sirve para practicar la lectura del candidato y la práctica adicional cubre ambos sentidos de la asignación del valor puntual. Su punto más débil es pedagógico, no matemático: esa primera pregunta pide concluir un valor sugerido a partir de datos finitos, pero su redacción no recuerda allí que es una conjetura; la sección posterior hace esa distinción. Además, presenta menos ejemplos explícitos de cómo controlar la distancia entre salida y límite que A y C. No encuentro errores sustantivos de cálculo o de alcance.

Las diferencias no justifican un salto grande: C supera a A por una explicación algo más transferible y por la pregunta sobre redondeo; A supera a B por su presentación más directa de la relación entre distancias. Un lector que prefiera una demostración algebraica compacta y ejemplos numéricos sencillos podría preferir A; quien aprenda mejor mediante contraejemplos de datos insuficientes podría preferir B. C también tiene una breve explicación verbal de la flecha y práctica adicional, por lo que ofrece el paquete más completo para el lector promedio activo.
