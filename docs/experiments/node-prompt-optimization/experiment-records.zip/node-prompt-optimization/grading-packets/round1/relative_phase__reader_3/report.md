# Lesson evaluation

| Lesson | Conceptual clarity and motivation | Scaffolding, pacing, and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.0 | 9.1 | 8.7 | 8.6 | 10.0 | 9.08 |
| B | 9.2 | 8.8 | 9.4 | 9.2 | 10.0 | 9.32 |
| C | 9.3 | 9.0 | 9.4 | 9.2 | 10.0 | 9.38 |

Ranking: **C > B > A**. Confidence: **moderate**; the three lessons are all strong, and the gaps are modest.

## Lesson C

C is the strongest overall for an actively engaged first-time reader. It establishes the central puzzle and immediately demonstrates it with the supplied recombination matrix: the two states with identical direct probabilities produce opposite certain outputs. It then explains global and relative phase, derives both balanced and unequal-magnitude predictions, and adds a concrete phase example at (2\pi/3). This sequence supports understanding and transfer without requiring optics knowledge. Its questions move from a complex-amplitude calculation through global-versus-relative phase to interpreting ambiguity in a measured distribution; the bonus questions also extend the method.

Its strongest feature is the progression from a vivid interference result to reusable calculation and interpretation. The main weakness is minor pacing: the section on what an interference result tells you and the fifth bonus section add further distinctions after the central derivation is already complete. They are relevant, and the bonus label helps signal their different role, so this is not a substantive teaching problem.

## Lesson B

B is a close second. It starts with the same concrete contrast, spells out the operation before introducing phase terminology, and then builds from the balanced family to an unequal-magnitude formula. The worked unequal-magnitude example and questions on selectively changing one component and on phase ambiguity make the calculations usable beyond the initial example. Its strongest feature is that breadth of transfer practice, while keeping all calculations tied to the supplied device.

The main weakness is a somewhat denser middle-to-late progression: after deriving the general unequal-magnitude rule, it adds phase inference and non-uniqueness, then asks the reader to retain those distinctions in further questions. These additions are accurate and useful, but the cumulative load is slightly higher than C's. This is a pacing tradeoff, not a correctness or scope problem.

## Lesson A

A has a clear, motivated path from equal direct probabilities to the importance of phase. Its opening phase-factor graph and explicit explanation that a minus sign corresponds to a phase difference of π help ground the notation before recombination. It also carefully explains the matrix operation, why input probabilities cannot simply be added, and why the result is a distribution rather than a trajectory. Its strongest feature is this accessible conceptual setup.

The main weakness is less transfer beyond the balanced family. It derives the phase-dependent balanced probabilities and provides a useful prediction at φ=π/3, but it does not develop the unequal-magnitude case as B and C do. Its questions still check meaningful complex arithmetic and interpretation, though there are fewer core opportunities to practice the broader method. This is a material but limited teaching gap relative to the other two, not a flaw in its balanced-family treatment.

All three lessons are mathematically correct on the stated model, including their displayed answer keys and formulas. C edges B through its slightly smoother integration of explanation, examples, and interpretation; B's extra explicit transfer work nearly closes that gap. A remains clear and effective for its narrower worked scope. A learner who prefers a shorter, more gradual introduction focused on intuition might choose A; a reader seeking more calculation practice with unequal amplitudes may prefer B, while C offers the best balance for the stated learner.
