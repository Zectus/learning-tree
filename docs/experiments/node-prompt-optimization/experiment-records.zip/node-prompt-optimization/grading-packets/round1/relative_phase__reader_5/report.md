# Evaluation

| Lesson | Clarity and motivation | Scaffolding and pacing | Worked reasoning and transfer | Active learning | Correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.2 | 8.8 | 9.2 | 9.3 | 10.0 | 9.30 |
| B | 8.9 | 9.1 | 8.9 | 9.2 | 10.0 | 9.22 |
| C | 9.5 | 9.2 | 9.5 | 8.8 | 10.0 | 9.40 |

Ranking: **C > A > B**. Confidence: **moderate**; all three are strong and the overall gaps are small.

**C** has the strongest learning arc. It first demonstrates the effect of recombination with the two sign states, then explains global and relative phase, and finally derives the continuous-phase prediction. The worked φ=π/3 case gives a usable check between the extremes, while the unequal-magnitude derivation, numerical range example, and slider graph show how to transfer the same rule to other inputs. Its questions test calculation, global-phase comparison, equal output distributions despite distinct states, and phase inversion. The main weakness is that its three main questions leave less opportunity to practice than A or B, and its later sections pack several derivations and ideas together. The supported slider graph makes the unequal-magnitude discussion useful, but the reader has to attend to a substantial amount of material.

**A** is particularly good at connecting predictions to what an experiment can establish. It explicitly distinguishes a run's outcome from a repeated-run distribution, proves that a common phase survives recombination harmlessly, and cautions that matching cosine-based distributions do not establish global-phase equivalence. Question 4 directly tests that distinction, and the bonuses extend to optimizing probability and applying R twice. Its main weakness is pacing: the final section revisits identifiability, single-run limits, and trajectories after a long set of derivations, so the lesson can feel more expansive than needed. The question set is rich and the explanations are accurate.

**B** is the most compactly staged: it introduces the device and its operational sequence early, includes a clear unequal real-amplitude worked example, and then derives the phase-dependent probabilities. The graph's marked equal-output point is a helpful visual cue, and its questions test calculations as well as limits on inference. Its main weakness is that the reader first encounters the formal meaning of relative phase and the factoring of component phases in Section 4, after the continuous-phase formula in Section 3. Earlier language explains that one component can change phase relative to the other, so the calculation remains followable, but the central terms and general state representation arrive later than ideal.

All three lessons are mathematically sound within the stated scope. Their probability formulas, matrix applications, worked examples, and keyed answers are consistent. C is the best fit for a learner who benefits from visual exploration and an explicit bridge to unequal magnitudes. A may suit a learner who values careful interpretation of what measured outcomes can and cannot establish; B may suit someone who prefers a shorter, more direct route.
