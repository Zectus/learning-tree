# Evaluación de las tres lecciones

## Puntuaciones

| Criterio (peso igual) | A | B | C |
|---|---:|---:|---:|
| Claridad conceptual y motivación | 9.5 | 9.7 | 9.4 |
| Andamiaje, ritmo y carga cognitiva | 9.4 | 9.6 | 9.3 |
| Razonamiento trabajado y transferencia | 9.5 | 9.7 | 9.5 |
| Preguntas activas y oportunidades de feedback | 9.5 | 9.5 | 9.4 |
| Corrección y precisión matemática | 9.8 | 9.8 | 9.8 |
| **Promedio** | **9.54** | **9.66** | **9.48** |

**Ranking:** B, A, C. **Confianza:** moderada; las diferencias son pequeñas y las tres enseñan bien el nodo.

## Evaluación

**B ocupa el primer lugar por un margen pequeño.** Su secuencia hace explícito el paso de observación a explicación: la tabla y la gráfica proponen 4; la factorización da (f(x)=x+2) para (x\ne2); y la comparación (f(x)-4=x-2) justifica que el comportamiento se mantiene para entradas permitidas. La frase que distingue “algunas entradas favorables” del comportamiento de las entradas cercanas ayuda a interpretar el significado general sin convertirlo en una definición formal. La sección 3 vuelve a aplicar esa distinción a datos finitos. Las preguntas principales practican interpretación, separación de límite y valor puntual, y los límites de una tabla; el bonus de (q(1{,}001)) además exige transferir la relación de distancias con un factor 2.

Su característica más fuerte es esa progresión clara desde una conjetura visual hasta una razón que cubre el caso general. La debilidad más importante es menor: no explora de forma explícita una función cuyas salidas sí alcanzan el límite en entradas cercanas (por ejemplo, una función constante), de modo que la idea de que “acercarse” no prohíbe alcanzar el valor queda menos visible que en A. No hay error matemático sustancial.

**A queda muy cerca de B.** Su tratamiento del ejemplo es sólido y concreto: empareja tabla y gráfica, explica que el hueco es un solo punto y deriva (f(x)-4=x-2), con la interpretación de distancias en palabras. Destaca al hacer explícitos los tres casos de valor puntual (inexistente, distinto del límite o coincidente) y, sobre todo, al aclarar que una salida puede alcanzar el límite: el ejemplo de una función constantemente igual a 7 corrige una posible lectura demasiado literal de “acercarse”. La pregunta sobre tabla finita mide bien si el lector distingue evidencia sugerente de justificación.

Su rasgo más fuerte es la cobertura conceptual de valor puntual frente a límite, incluida la posibilidad de igualdad. Su principal debilidad comparativa es que esa sección añade varias distinciones juntas —cambiar el valor central y alcanzar el límite— antes de la práctica posterior, lo que hace el avance apenas menos compacto. El bonus de A refuerza casos ya tratados más que ampliar mucho la transferencia. Es una diferencia de ritmo y selección, no un problema de corrección ni una carencia seria.

**C queda tercera por una diferencia igualmente modesta.** Explica bien la cancelación válida solo cuando (x\ne1), relaciona las distancias de entrada y salida y es cuidadosa al explicar que el formato no dibuja un círculo abierto. La sección de aproximación añade una observación útil sobre el redondeo de pantalla, y el bonus con (5+x) y (5+100x) muestra que ambas funciones pueden tener el mismo límite aunque sus salidas se separen del objetivo a distinta escala. Las cuestiones principales son alcanzables y relevantes.

Su fortaleza más clara es la precisión al conectar la fórmula con el hueco y al explicar los límites de tablas y representaciones. La debilidad principal es de distribución: el contraste entre valor puntual y límite aparece en la primera sección antes de que la sección 2 sistematice la idea; además, la pregunta 1 verifica sobre todo qué entradas escoger, con menos razonamiento que las preguntas equivalentes de A y B. Es un ajuste pedagógico pequeño. La matemática es correcta.

Un lector que prefiera una explicación más compacta y secuencial probablemente elegirá B; quien valore especialmente que se despeje explícitamente la idea de alcanzar o no el límite puede preferir A. C puede atraer a quien aprecie el ejemplo de distintos ritmos de aproximación. Ninguna preferencia cambia la conclusión de que las tres lecciones ofrecen una enseñanza fuerte y usable.
