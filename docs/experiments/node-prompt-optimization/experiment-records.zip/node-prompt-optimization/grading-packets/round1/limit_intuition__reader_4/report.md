# Evaluación de las lecciones

## Puntuaciones

| Lección | Claridad conceptual | Andamiaje y ritmo | Razonamiento y transferencia | Preguntas y oportunidades de aprendizaje | Corrección y precisión | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.5 | 9.3 | 9.4 | 9.4 | 9.4 | 9.40 |
| B | 9.6 | 9.5 | 9.7 | 9.6 | 9.6 | 9.60 |
| C | 9.4 | 9.1 | 9.2 | 9.4 | 9.4 | 9.30 |

**Orden:** B, A, C. **Confianza:** moderadamente alta.

## Evidencia y diferencias decisivas

Las tres lecciones enseñan correctamente la idea central: el límite describe valores en entradas cercanas distintas del centro, y no determina el valor de la función allí. En los ejemplos algebraicos, la cancelación se limita explícitamente a las entradas permitidas. Ninguna confunde una tabla finita con una demostración ni introduce herramientas fuera del alcance previsto.

**B** queda primero por el recorrido más completo y gradual. Tras establecer el límite de la recta con hueco, la Sección 2 cambia el valor central a 9 y calcula por separado el límite y `g(2)`; además aclara que el valor central también podría coincidir con el límite y que una función puede incluso alcanzar ese valor en entradas cercanas. La Sección 3 vuelve sobre la limitación de las tablas y añade el efecto del redondeo. Sus preguntas practican interpretación, separación entre valor y límite, y evaluación de evidencia. Su punto más fuerte es hacer explícitas las distinciones que suelen confundirse. La pequeña desventaja es que el tratamiento es más extenso y reiterativo que el de A, aunque cada vuelta añade una precisión útil; no encuentro un defecto sustancial.

**A** ofrece una explicación especialmente eficiente del vínculo entre entradas y salidas: `f(x)-2=x-1` muestra que ambas distancias coinciden, y la extensión que asigna `F(1)=8` convierte esa idea en un caso claro de límite distinto del valor puntual. La segunda sección contrasta bien una igualdad calculada con una aproximación y explica por qué una tabla finita no basta. Sus preguntas cubren la notación, un valor central redefinido y la insuficiencia de datos. Su rasgo más fuerte es esa línea algebraica directa y fácil de reutilizar. Su principal limitación frente a B es que desarrolla menos casos para consolidar la distinción entre límite y valor en el punto; la explicación sigue siendo sólida y no presenta errores.

**C** tiene una buena progresión y una pregunta de transferencia particularmente valiosa: en la Pregunta 3, el lector debe elegir una función que coincide con mediciones alejadas del centro pero cambia en un entorno más estrecho, mostrando por qué esas mediciones no garantizan el límite propuesto. También distingue correctamente el valor `g(2)=6` del límite 4 y explica la limitación visual de los círculos abiertos. Su punto más fuerte es pedir un contraejemplo concreto, no solo reconocer una conclusión verbal. Su debilidad principal es que dedica menos explicación que A y B a separar el valor puntual de la tendencia y a practicar las limitaciones de las aproximaciones; la explicación aparece, pero el recorrido ofrece menos repetición guiada. La gráfica de la función redefinida puede requerir que el lector conecte la regla por casos con la línea y el punto marcado, tarea abordable con el texto que la acompaña.

Un lector que prefiera un trayecto más compacto podría elegir A. Quien aprenda mejor al construir contraejemplos puede preferir C, cuya tercera pregunta exige esa transferencia. Para el lector promedio descrito, B ofrece la cobertura y el ritmo más completos.
