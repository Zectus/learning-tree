# Evaluación comparativa

## Puntuaciones

| Lección | Claridad y motivación | Andamiaje y ritmo | Razonamiento y transferencia | Preguntas y oportunidades de aprendizaje | Corrección y precisión | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.2 | 9.1 | 9.2 | 9.5 | 9.8 | 9.36 |
| B | 9.4 | 9.4 | 9.5 | 9.2 | 9.8 | 9.46 |
| C | 9.5 | 9.2 | 9.6 | 9.4 | 9.8 | 9.50 |

**Ranking:** C > B > A. **Confianza:** media-alta; las tres enseñan bien el núcleo y la diferencia entre ellas es pequeña.

## Evidencia y tradeoffs

**C** ofrece la transferencia más amplia. Tras factorizar, muestra explícitamente $f(x)-4=x-2$ y conecta las distancias de entrada y salida; después aclara que el límite no requiere que la salida evite el valor límite, con el ejemplo de una función constantemente igual a 7. La sección 2 también explica de manera concreta que el punto añadido $(2,9)$ queda fuera de la ventana y que el hueco $(2,4)$ persiste. La pregunta 2 hace calcular un caso nuevo, y los bonos practican que cambiar el valor en el punto no cambia el límite. Su mayor virtud es esa red de conexiones y casos transferibles. Su debilidad más importante es la carga acumulada: incluye cuatro secciones y dos bonos, y la precisión adicional puede ser más de la necesaria para una primera introducción. No obstante, las ideas se presentan en secuencia y el material adicional está etiquetado como práctica.

**B** es casi igual de sólido y tiene el desarrollo de distancia más explícito: deriva $|f(x)-2|=|x-1|$ y luego da una cota concreta de $0{,}01$. La mención de entradas «del dominio» evita sugerir que toda función está definida en cada punto cercano. Sus preguntas comprueban interpretación, separación entre límite y valor, y los límites de una tabla; el segundo bono aplica la idea a una función constante salvo en un punto. El punto fuerte es el andamiaje matemático muy claro desde el ejemplo hasta la idea general. Como debilidad relativa, sus preguntas principales son mayormente reconocimiento de una conclusión ya explicada; ofrecen menos ocasión que A para construir un contraejemplo que muestre por qué una tabla no demuestra un límite. Es una diferencia de profundidad de práctica, no un defecto importante.

**A** tiene una progresión limpia y accesible. La explicación de la cancelación deja claro por qué es válida solo para $x\ne2$, y la sección 2 separa con sencillez evaluar en el punto de observar valores cercanos. Su mejor oportunidad de razonamiento está en la pregunta 3: elegir una función que vale 6 en una vecindad aún más estrecha refuta de verdad la inferencia basada en cuatro mediciones. La pregunta y el bono hacen que el lector use la idea, no solo repita una definición. Su debilidad principal es que la definición general y el razonamiento de acercamiento son menos explícitos sobre cómo controlar la distancia que en B y C; la frase «se pueden mantener tan cerca» queda más como descripción que como mecanismo trabajado. Además, el gráfico inicial y la tabla omiten el valor central de forma distinta, sin que esto cause un error. El contenido es correcto y manejable, pero deja menos puente hacia nuevos casos.

No encuentro errores matemáticos sustantivos en ninguna lección. La limitación gráfica está explicada de forma adecuada en las tres. Las diferencias son didácticas y menores, no fallas de alcance o corrección. Un lector que prefiera una introducción corta y una pregunta de refutación concreta podría preferir A; quien valore una cota de distancia muy visible podría escoger B. Para un lector activo que quiera conectar la idea con más casos, C ofrece la mejor experiencia global.
