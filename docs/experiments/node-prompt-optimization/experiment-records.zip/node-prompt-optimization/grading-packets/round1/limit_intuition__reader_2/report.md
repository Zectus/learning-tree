# Evaluación de las tres lecciones

## Puntuaciones

| Lección | Claridad y motivación | Andamiaje y ritmo | Razonamiento y transferencia | Aprendizaje activo | Corrección y precisión | Total |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 9.4 | 9.5 | 9.3 | 10.0 | 9.52 |
| B | 9.6 | 9.5 | 9.6 | 9.5 | 10.0 | 9.64 |
| C | 9.5 | 9.5 | 9.5 | 9.4 | 10.0 | 9.58 |

**Orden:** B, C, A. **Confianza:** media-alta; las tres enseñan bien y las diferencias son pequeñas.

## Evaluación

**B ocupa el primer lugar.** Su rasgo más fuerte es la explicación completa de qué afirma un límite y qué no: parte de la tabla y el hueco, justifica el patrón mediante la cancelación válida para (x\ne2), y conecta explícitamente las distancias con la idea informal. La sección 2 añade una distinción especialmente útil: al asignar (g(2)=9), el límite sigue siendo 4; además aclara que una salida sí puede alcanzar el límite, con el ejemplo de una función constante. Esto evita la posible confusión de que “acercarse” exige que los valores nunca lleguen al destino. La sección 3 separa con cuidado la evaluación exacta (f(1{,}99)=3{,}99) de la estimación y del límite, y practica que una tabla finita no prueba el patrón. Las preguntas cubren interpretación, valor puntual, evidencia insuficiente y transferencia. La debilidad más clara es menor: cuatro secciones y explicaciones reiteradas hacen el recorrido algo más largo; la práctica sigue apoyando el objetivo y no crea una carga importante.

**C queda en segundo lugar, muy cerca de B.** Su mejor recurso es hacer tangible la diferencia entre límite y valor puntual: conserva los valores de la función cerca de 1, asigna (g(1)=4), y muestra ese punto aislado en una segunda gráfica. También explica la limitación gráfica y respalda el acercamiento con la igualdad de distancias, incluido un ejemplo con tolerancia (0{,}01). La pregunta final principal y el bonus de la función constante en un intervalo comprueban bien que un valor excepcional no cambia el límite. La principal debilidad comparativa es que su apartado sobre tablas finitas queda más comprimido que el de B: plantea la limitación y la aplica, pero ofrece menos desarrollo para interpretar la diferencia entre proponer y justificar un límite. No hay error matemático; es una diferencia pequeña de profundidad explicativa.

**A queda en tercer lugar, también con una enseñanza sólida.** Su secuencia motivadora es directa: tabla a ambos lados, hueco, simplificación, relación entre distancias y notación. Es particularmente acertado que explique que el trazo puede parecer continuo y que el dominio, no el grosor de la línea, determina la exclusión. La pregunta 3 distingue con precisión los datos observados de una conclusión justificada, y los ejercicios permiten practicar tanto el valor puntual como el límite. Su debilidad más importante es que el desarrollo conceptual dedica menos espacio a matices de interpretación que B: por ejemplo, no incluye el útil contraste de B entre una función que no alcanza el límite y una función constante que sí lo alcanza. En conjunto la exposición sigue siendo clara y exacta; la diferencia no es un problema sustancial.

Las tres lecciones son matemáticamente correctas en los ejemplos y en la interpretación informal del límite; ninguna presenta tablas como demostraciones ni exige evaluar en el punto. Las tres usan tareas breves con respuestas determinadas y oportunidades de práctica suficientes para el objetivo. Las diferencias responden sobre todo al énfasis pedagógico, no a fallos de contenido.

Un lector que aprenda mejor con una representación visual explícita del valor excepcional podría preferir C. Quien valore un recorrido más compacto podría preferir A. Para un lector que se beneficia de una explicación verbal más completa de los matices y de la evidencia, B es la mejor elección general.
