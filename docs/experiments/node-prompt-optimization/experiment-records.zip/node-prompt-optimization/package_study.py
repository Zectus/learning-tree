from pathlib import Path
import json, hashlib, shutil, zipfile

b = Path('/workspace/node-prompt-optimization')
docs = Path('/workspace/learning-tree/docs/experiments/node-prompt-optimization')
docs.mkdir(parents=True, exist_ok=True)
assert Path('/workspace/learning-tree/js/learn/node-prompt.js').read_bytes() == (b/'best-performing-prompt.js').read_bytes()

validation = {'app': {'command':'npm test','tests':117,'passed':117,'failed':0},
              'companion': {'command':'npm run test:companion','tests':16,'passed':16,'failed':0},
              'source_matches_exact_tested_candidate':True,
              'initial_app_failure':'An existing single-node assertion banned ordinary teaching uses of Continue. It now rejects the actual batch continuation commands; the prompt was not changed to satisfy that assertion.'}
for log, expected in [('app-tests.log',117),('companion-tests.log',16)]:
    text=(b/log).read_text()
    assert f'ℹ pass {expected}\n' in text and 'ℹ fail 0\n' in text
(b/'app-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
(b/'RESUME.md').write_text('''# Study completed\n\nLatest user request was to finish the current experiment and document all findings and the best prompt. This is complete: four grading rounds, 44 unique saved lessons, 60 fresh blind Luna graders, six nodes, 243 checked keys. See FINDINGS.md and study-results.json.\n\nRound 4 grading and aggregate were saved before the usage limit; root read all reports and completed its manager notes. Round 3 independent content-audit.md was also fully saved before its agent hit the usage limit; all 24 files and 138 keys are covered. No new lessons or grades were fabricated during finalization. The four-node Round 5 never launched an author; original and amended unrun plans are preserved.\n\nThe selected exact variant is coherent, SHA f629442764c4a507f6a0dab6b1ea5551982ad1b9c52076d34746af9f21765ea8. It has been copied byte-for-byte into the app node-prompt.js. Best text/source/exact calculus input and all findings are exported. Application checks: 117/117; companion: 16/16. No runtime fallback added. Documentation is mirrored under learning-tree/docs/experiments/node-prompt-optimization.\n\nRound 1 factual correction was made by the same grader and is preserved alongside originals. Round 3 same-grader adjudication did not happen before session interruption; keep its raw scores unchanged. Its verified false penalty is documented with an explicit upper-bound sensitivity calculation, which does not change the selected broad winner. Round 4 has another verified formula-absence oversight, also retained without rescoring.\n\nDo not restart generation or grading merely because old manager status said failed: the saved current experiment is complete. Further experiments require a new active user instruction. All writer models in this study were explicitly GPT 6.1 Sol low; no outdated Sol substitution.\n''')
with (b/'research-ledger.md').open('a') as f:
    f.write('\nFINALIZED: four completed grading rounds, 44 unique outputs, 60 fresh blind panels, six nodes and 243 checked keys. Round 4 aggregation survived the limit; root completed notes and exports. Round 3 audit report fully saved despite later agent error. Round 5 has zero authors/lessons/grades and remains unrun. Exact coherent source selected and applied byte-for-byte to app; six-node direct comparison 9.5044 vs 9.4122, preferences 27–8 with one tie. Human-learning perfection was not established. App 117/117 and companion 16/16 checks pass; one overly broad Continue-word test was narrowed to actual batch commands.\n')

archive=b/'experiment-records.zip'
files=[p for p in sorted(b.rglob('*')) if p.is_file() and p.suffix!='.zip' and '__pycache__' not in p.parts and p.name!='archive.sha256']
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:z.write(p, 'node-prompt-optimization/'+str(p.relative_to(b)))
    for name in ['round1','round2','round3','round4']:
        m=json.loads((b/name/'manifest.json').read_text());n=Path(m['neutral_root'])
        for p in sorted(n.rglob('*')):
            if p.is_file():z.write(p,'node-prompt-optimization/grading-packets/'+name+'/'+str(p.relative_to(n)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name in ['round1','round2','round3','round4']:
        m=json.loads((b/name/'manifest.json').read_text())
        for reader in m['orders']:
            payload=z.read('node-prompt-optimization/grading-packets/'+name+'/'+reader+'/packet.txt')
            assert hashlib.sha256(payload).hexdigest()==m['packet_sha256'][reader]
checksum=hashlib.sha256(archive.read_bytes()).hexdigest()
(b/'archive.sha256').write_text(checksum+'  experiment-records.zip\n')
names=['best-performing-prompt.js','best-performing-prompt.txt','best-performing-prompt-limit-example.txt',
       'best-performing-prompt.diff','best-prompt-manifest.json','study-results.json','completion-checks.json',
       'app-validation.json','experiment-records.zip','archive.sha256']
for name in names:shutil.copyfile(b/name,docs/name)
shutil.copyfile(b/'FINDINGS.md',docs/'README.md')
(docs/'round3').mkdir(exist_ok=True)
shutil.copyfile(b/'round3/adjudication-sensitivity.json',docs/'round3/adjudication-sensitivity.json')
print(json.dumps({'documentation':str(docs),'archive_bytes':archive.stat().st_size,'archive_sha256':checksum,'archived_packets_valid':60,'all_validation_passed':True},indent=2))
