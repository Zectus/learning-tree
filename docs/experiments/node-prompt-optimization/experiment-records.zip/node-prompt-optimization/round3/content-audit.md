# Round 3 independent mathematical/content audit

This is a content audit, not a teaching-quality grade. The auditor read the four reader briefs at `input/*/context.txt` and the complete assigned lesson texts. Author prompts, candidate templates, author/condition maps, grades, and other experiment reports were not consulted. No lessons, app files, or grades were changed.

Status: **all 24 files audited completely; 138 main/bonus keys checked (90 main, 48 bonus). No verified substantive defects, wrong keys, unsupported central premises/operations, or faulty rate/basis arguments.** Option uniqueness is checked below, including one optional wording refinement for the general symbolic reading of `task_17` Q2. Calculations were checked independently; nontrivial matrix arithmetic, derivatives, and parameter equations were also checked with SymPy. Visual checks concern the supplied graph expressions, coordinates, and accompanying mathematical claims; no runtime screenshots were inspected.

| Topic / files | Files | Main keys | Bonus keys | Total keys | Verified substantive issues |
| --- | --- | --- | --- | --- | --- |
| One-sided limits, tasks 01–06 | 6 | 18 | 12 | 30 | 0 |
| Chain rule, tasks 07–12 | 6 | 22 | 12 | 34 | 0 |
| Bra-ket notation, tasks 13–18 | 6 | 23 | 12 | 35 | 0 |
| Partial trace, tasks 19–24 | 6 | 27 | 12 | 39 | 0 |
| Total | 24 | 90 | 48 | 138 | 0 |

## `writers/task_05/lesson.txt` — one-sided limits

Read all 139 lines. **Outcome: no verified mathematical, scope, or answer-key defect.**

- The worked jump has left limit 2 and right limit 4 at 1, while `f(1)=4` (lines 7–35); the two-sided limit therefore does not exist. The finite two-sided criterion and its two directions are valid under the stated assumption of a domain on both sides (lines 37, 56–64).
- The cancellation `(x²−1)/(x−1)=x+1` is explicitly restricted to `x≠1`, so the hole has both one-sided limits 2 without acquiring a value at 1 (lines 81–104).
- Visual source: the two separate traces encode `x+1` for `x<1` and `x+3` for `x≥1`; the filled point is `(1,4)`. The omitted open endpoint `(1,2)` is explained (lines 11–23). The second graph is explicitly the full auxiliary line, with the missing function point explained separately (lines 90–100). These are mathematically consistent.
- Scope: uses finite limits, piecewise notation, algebra, and supplied absolute-value rules. It does not assume or teach infinite limits or a formal epsilon-delta definition.

| Item | Independent result | Key | Uniqueness |
| --- | --- | --- | --- |
| Q1, lines 39–48 | Left `3−2=1`; right `2·2+1=5` | B | Only `(1,5)` |
| Q2, lines 68–77 | `−2≠6`; no bilateral limit, regardless of `h(3)=2` | D | Only correct evaluation |
| Q3, lines 106–115 | `u=x+3` off 3; `v` has left 6 and right 6; both limits 6 | C | Only correct comparison |
| Bonus 1, lines 119–128 | `4+b=2²−1=3`, hence `b=−1`; point value 9 irrelevant | A | Unique parameter |
| Bonus 2, lines 130–139 | `|x|/x=−1` on the left and 1 on the right; assigning `s(0)=0` changes neither | E | Only correct effect |

No optional mathematical correction identified.

## `writers/task_15/lesson.txt` — bras, kets, and outer products

Read all 188 lines. **Outcome: no verified mathematical, scope, or answer-key defect.**

- Conjugate-transpose notation, conjugate symmetry, and scalar conjugation are correct (lines 5–29). With `u=(1,i)ᵀ` and `v=(2,3)ᵀ`, the inner products are `2−3i` and `2+3i`.
- The outer product is `[[2,3],[2i,3i]]`; on `(1,−1)ᵀ` it produces `(-1,−i)ᵀ=−u`. The general coordinate formula correctly conjugates the vector supplying the bra. Nonzero outer factors produce rank one (lines 44–67).
- The projection coefficient follows from orthogonality. For normalized `n=(1,i)ᵀ/√2`, `P=(1/2)[[1,−i],[i,1]]`; `P(2,0)ᵀ=(1,i)ᵀ`; the remainder `(1,−i)ᵀ` has inner product zero with `n` because `1+(−i)(−i)=0` (lines 92–118).
- `P²=P`, preservation of the retained direction, annihilation of orthogonal vectors, and the normalization correction `|a⟩⟨a|/⟨a|a⟩` all follow correctly (lines 139–153).
- Visual source: the real example has projection `(1,2)ᵀ`, remainder `(2,−1)ᵀ`, and their sum is `(3,1)ᵀ`. The trace `(t,2t)`, markers, and remainder segment encode those actual coordinates. The orthogonality claim is supported by `(1,2)·(2,−1)=0`. The text correctly limits this real-plane illustration rather than treating a general complex vector as a real-plane arrow (lines 120–137).
- Scope: explicitly introduces all bra-ket symbols, outer products, rank one, and projector identities. It uses the permitted inner-product, normalization, and eigenvector background. No change-of-basis or measurement-postulate claim is introduced.

| Item | Independent result | Key | Uniqueness |
| --- | --- | --- | --- |
| Q1, lines 31–40 | Bra `(1−i,2)`; `(1−i)i+2=3+i` | B | Only correct bra/result pair |
| Q2, lines 79–88 | Target matrix `[[2,i],[−2i,1]]` = `(1,−i)ᵀ(2,i)` | D | All five option matrices checked; only D equals target |
| Q3, lines 155–164 | `Pq=(1/5)[[4,−2i],[2i,1]]`; output `(4−2i,1+2i)ᵀ/5` | C | Only matching column |
| Bonus 1, lines 168–177 | `⟨a|a⟩=1+4=5`, hence projector `R/5` | E | Other nonzero scalings fail preservation/idempotence |
| Bonus 2, lines 179–188 | `T²=|p⟩⟨q|p⟩⟨q|=(−i/2)T` | B | `T` is nonzero and the listed multipliers are distinct |

No optional mathematical correction identified.

## `writers/task_03/lesson.txt` — one-sided limits

Read all 151 lines. **Outcome: no verified mathematical, scope, or answer-key defect.**

- The worked jump has one-sided limits 2 and 4 at 1 and point value 4 (lines 5–41); no single bilateral limit or average of the two values is valid (lines 56–58).
- The finite bilateral criterion is valid with the explicitly stated presence of domain inputs arbitrarily close on both sides (lines 60–68).
- The hole example cancels `x−1` only for nonzero denominator, gives both one-sided limits 2, and distinguishes the auxiliary line from a value assigned to the missing point (lines 70–97).
- Visual source: the piecewise trace and `(1,4)` marker agree with the jump formulas and prose (lines 14–25). The second graph is explicitly a reference line; the absent `(1,2)` and lack of native open circles are explained (lines 80–90). No graph-source/content contradiction is present. Runtime handling of a discontinuity in a single trace was not inspected.
- Scope: all claims concern finite limits and polynomial/rational branches; the supplied absolute-value rules suffice for the bonus. No later limit theory or formal epsilon-delta machinery is assumed.

| Item | Independent result | Key | Uniqueness |
| --- | --- | --- | --- |
| Q1, lines 43–52 | Left `2(−2)+1=−3`; right `−2−4=−6` | B | Only `(−3,−6)` |
| Q2, lines 99–108 | Off 3, `(x²−9)/(x−3)=x+3`; both limits are 6 | D | Only correct evaluation |
| Q3, lines 118–127 | `2m+2=4−m`, so `m=2/3` and limit `10/3` | C | Unique solution/result pair |
| Bonus 1, lines 131–140 | Left `−1`, right 1; no bilateral limit | A | Only correct pair and conclusion |
| Bonus 2, lines 142–151 | Original bilateral limit is 2. Options A–D change one side to 3 or 5; E changes only the point value | E | Only option preserving the limit 2 |

No optional mathematical correction identified.

## `writers/task_19/lesson.txt` — partial trace and reduced density operators

Read all 256 lines. **Outcome: no verified mathematical, scope, or answer-key defect.** There are no graph blocks or visual claims requiring a graph check.

- The opening state is normalized. Contracting against the local state `a=α|0⟩+β|1⟩` gives amplitudes `√3 α*/2` and `β*/2`; the environment alternatives are orthogonal, so the probabilities add to `3|α|²/4+|β|²/4`. The arbitrary local ket, rather than only the computational basis, establishes the candidate reduced matrix (lines 5–21).
- The pure-state construction is derived from amplitudes before use: `vj=Σi cij|i⟩`, `ρA=Σj |vj⟩⟨vj|`, and `(ρA)ik=Σj cij ckj*` (lines 23–39). This correctly retains coherences with equal environment labels.
- The row/column convention is explicit: `ρij,kℓ=⟨i,j|ρAB|k,ℓ⟩`. The elementary-operator rule gives `δjℓ|i⟩⟨k|`, so the discarded index is summed as `(ρA)ik=Σj ρij,kj`. The displayed two-qubit entries and block-trace explanation use that same order; summing whole blocks would instead retain B (lines 54–80). There is no index reversal or missing conjugation.
- The worked mixed preparation produces the stated joint matrix and reduced matrix `[[3,1],[1,1]]/4`. It includes a specific off-diagonal entry calculation and all-block-trace result. Trace preservation, Hermiticity, and positivity are justified, rather than renormalization being assumed (lines 82–104).
- The central local-probability proof uses the correct trace multiplication order: `Tr[ρAB(P⊗IB)]=Σij,kℓ ρij,kℓ Pki δℓj=Σik(Σjρij,kj)Pki=Tr(ρAP)`. It covers arbitrary local projectors, including subspace projectors, and the same algebra holds for any local operator. The worked `|+⟩` probability is `3/4` by both the reduced matrix and ensemble calculation (lines 123–141). An independent check using the complex `|y⟩` projector and Q2 joint matrix gave `2/3` from both sides.
- Basis change is algebraically correct with columns `|br⟩=Σj ujr|j⟩`: the bra supplies `ujr*`, and summing `Σr ujr* uℓr=δjℓ` collapses the expansion to the original contraction sum (lines 156–174). The placement of both conjugates in the proof and the phase-sensitive Q4 is correct. An independent exact test with complex unitary `U=[[1,i],[i,1]]/√2` and the Q2 joint matrix produced exactly the original partial trace. The real `±` worked contractions are `(√3,±1)ᵀ/(2√2)` and sum to `diag(3/4,1/4)` (lines 176–184).
- The Bell reduction and purities are correct: `ρA=I/2`, local purity `1/2`, joint purity 1. The classical mixture has the same marginals but probability `1/2` for the Bell projector, versus 1 in the Bell state (lines 199–219). The text explicitly rejects interpreting partial trace as a physical measurement, outcome selection, or collapse.
- Scope/central-step check: finite product bases, density matrices, trace probabilities, and Bell amplitudes are the stated prerequisites. The new reduction is constructed from an arbitrary local amplitude, extended to mixed states through elementary operator terms, and verified by a full index identity. Basis independence is explicitly expanded rather than assumed as an unexplained invariance. Purity and ensemble nonuniqueness are available from the density-operator prerequisite. No quantitative entanglement measure, Bell inequality, or decoherence theory is required.

| Item | Independent result | Key | Uniqueness |
| --- | --- | --- | --- |
| Q1, lines 41–50 | Coefficient matrix `[[1,0],[1,1]]/√3`; `CC†=[[1,1],[1,2]]/3` | C | Only matching matrix |
| Q2, lines 106–119 | Block traces give `[[3,1−i],[1+i,3]]/6` | B | Only correct conjugation and entries; the supplied joint matrix is positive and trace one |
| Q3, lines 143–152 | `(1,−i)[[4,−i],[i,1]](1,i)ᵀ/10=7/10` | D | Only numerical match; environment dimension does not add a factor |
| Q4, lines 186–195 | `w+=(1,2e^(−iθ))ᵀ/√10`; its `(0,1)` contribution is `e^(iθ)/5`, canceled by the minus summand | A | `0<θ<π/2` makes the phase distractor distinct and the proposed nonzero totals false |
| Q5, lines 221–230 | Both marginals `I/2`; `⟨+,−|Ψ+⟩=0`, while each mixture component contributes to total probability `1/4` | E | Only correct order of probabilities and interpretation |
| Bonus 1, lines 232–245 | Coefficient matrix `[[1,0,1],[0,1,i]]/2`; reduced matrix `[[2,−i],[i,2]]/4`, purity `5/8` | B | Only matching matrix/purity pair |
| Bonus 2, lines 247–256 | With `z=⟨u|v⟩`, purity is `1/2+2|z|²`; it equals 1 iff `|z|=1/2` | C | Necessary and sufficient; the real/imaginary-only conditions are insufficient |

No optional mathematical correction identified.

## `writers/task_17/lesson.txt` — bras, kets, and outer products

Read all 190 lines. **Outcome: no verified substantive mathematical, scope, or answer-key defect.** Q2 has a minor optional precision point recorded separately below.

- The dagger, conjugate-linearity of ket-to-bra conversion, inner product `−i`, conjugate symmetry, and norm convention are correct (lines 5–32).
- The complex outer product is `[[2,i],[2i,−1]]`; applying it to `(1,2)ᵀ` yields `(2+2i,−2+2i)ᵀ`, agreeing with the overlap-first calculation (lines 47–74). The rank-one claim is explicitly restricted to nonzero defining vectors.
- The projector `|u⟩⟨u|`, real example `[[1,2],[2,4]]/5`, remainder orthogonality proof, idempotence, and complex example `[[1,−i],[i,1]]/2` are correct (lines 98–155).
- Visual source: the line `y=2x`, input `(3,1)`, projection `(1,2)`, and connecting segment agree with the real calculation. The removed displacement is orthogonal to `(1,2)` because either orientation has dot product zero. The text explicitly distinguishes the complex-vector case from this real-coordinate plane (lines 105–155). Actual rendering of the supplied `aspect: equal` property was not inspected.
- Scope: notation is introduced explicitly, the assumed complex inner-product background suffices, and the projector properties follow from shown algebra. The unnormalized-vector bonus is accessible by normalizing the ket (normalization is an allowed prerequisite). No basis change or physical measurement rule is invoked.

| Item | Independent result | Key | Uniqueness |
| --- | --- | --- | --- |
| Q1, lines 34–43 | Bra `(1,i)` and overlap `2i+3i=5i` | C | Only correct pair |
| Q2, lines 85–94 | Required general map is `|b⟩⟨a|` | B | Only expression guaranteed for arbitrary specified nonzero a,b; see precision note |
| Q3, lines 157–166 | Overlap `i/√5`; output `(2i,−1)ᵀ/5` | D | Only matching column |
| Bonus 1, lines 170–179 | Normalize r by 3; outer product scales by `1/9` | B | Other scalings do not leave r unchanged |
| Bonus 2, lines 181–190 | `T|b⟩=|a⟩` and `T²=⟨b|a⟩T=0` | E | Only correct pair of identities; T is nonzero |

**Optional wording precision, not a verified substantive defect:** Q2 is a general symbolic map-construction question, under which B is the uniquely valid general answer. It could explicitly ask which expression works *for every choice* of the specified nonzero a,b. This would remove a special-case reading: when `a=b`, reversed outer product C happens to coincide with B. No numerical or formula error follows from the usual general-identity reading of the item.

## `writers/task_18/lesson.txt` — bras, kets, and outer products

Read all 198 lines. **Outcome: no verified mathematical, scope, or answer-key defect.**

- Conjugation, the inner-product example `−i`, coefficient conjugation, and outer-product coordinates are correct (lines 5–62). The worked map `[[2,1],[2i,i]]` sends `(1,−1)ᵀ` to `(1,i)ᵀ`.
- The eigenvector example `[[0,−i],[i,0]](1,i)ᵀ=(1,i)ᵀ` is valid. Sandwich expressions return scalars with the stated ordering (lines 77–89).
- The normalized-direction projection is derived by solving `⟨u|x⟩=c` and verifying the remainder. With `u=(3,4)ᵀ/5`, the projector is `[[9,12],[12,16]]/25`; on `(2,1)ᵀ` its output is `(6/5,8/5)ᵀ` and remainder `(4/5,−3/5)ᵀ` (lines 104–135). Idempotence, eigenvalues, and division by the squared norm for unnormalized vectors are correct (lines 153–163).
- Visual source: the trace `(3t/5,4t/5)`, unit-vector marker `(0.6,0.8)`, projection `(1.2,1.6)`, input `(2,1)`, and remainder segment match those calculations. Their perpendicularity is mathematically valid since `3·(4/5)+4·(−3/5)=0`. No runtime display/aspect-ratio claim was tested. Complex vectors are explicitly excluded from the literal real-plane illustration.
- Scope: familiar linear algebra is translated into newly explained notation. No change of coordinates or measurement-postulate rule is assumed or taught.

| Item | Independent result | Key | Uniqueness |
| --- | --- | --- | --- |
| Q1, lines 29–38 | Bra `(1,i)`; overlap `5i` | B | Only correct pair |
| Q2, lines 64–73 | `T|x⟩=(1−i)|p⟩` | D | Only correct vector and coefficient; linear independence rules out a coincident q-output |
| Q3, lines 91–100 | `A|r⟩=(0,−i)ᵀ=−|r⟩`; sandwich is `−i` | C | Only correct pair |
| Q4, lines 165–174 | Norm squared 5; projector `[[1,−2i],[2i,4]]/5`, output `(1,2i)ᵀ/5` | A | Only correct matrix/output pair |
| Bonus 1, lines 178–187 | `R²=|w⟩⟨w|w⟩⟨w|=3R` | C | R is nonzero; listed multipliers distinct |
| Bonus 2, lines 189–198 | `Q=(i)(−i)P=P` | B | Only correct coefficient/conjugation statement |

No optional mathematical correction identified.

## `writers/task_06/lesson.txt` — one-sided limits

Read all 146 lines. **Outcome: no verified mathematical, scope, or answer-key defect.**

- The branch evaluations `f(0.9)=1.9`, `f(1.1)=4.1`, `f(1)=4`, and one-sided limits 2 and 4 are correct. The two directions of the finite bilateral-limit criterion are explained with a common sufficiently close neighborhood (lines 3–68).
- The hole example correctly restricts cancellation to `x≠2`, obtains `x+2`, and concludes both one-sided limits and the bilateral limit are 4 without assigning `h(2)` (lines 83–111).
- Visual source: the jump trace and filled `(1,4)` point agree with the formulas. The text explicitly excludes the left endpoint and any vertical function segment between the branches (lines 12–23). The rational-function trace is the line `y=x+2` off 2; the missing `(2,4)` and lack of an open-circle marker are explained (lines 92–103). Runtime treatment of a discontinuity in a single trace was not inspected.
- Scope: finite limits, piecewise rules, polynomial/rational algebra, and explicitly supplied absolute-value rules suffice. No infinite-limit theory or formal epsilon-delta definition is introduced.

| Item | Independent result | Key | Uniqueness |
| --- | --- | --- | --- |
| Q1, lines 43–52 | Left `2(−2)+1=−3`; right `7−(−2)=9` | B | Only `(−3,9)` |
| Q2, lines 70–79 | Left 4, right `−1`; no point value c can make them equal | D | Only correct conclusion |
| Q3, lines 113–122 | u follows `x+3` off 3; v has side limits `2·3=6` and `3+3=6` | C | Only correct comparison |
| Bonus 1, lines 126–135 | `2k+1=4−k`, hence k=1 and limit 3 | A | Unique parameter/result pair |
| Bonus 2, lines 137–146 | Left `−1`, right 1; no bilateral limit | E | Only correct ordered pair and conclusion |

No optional mathematical correction identified.

## `writers/task_01/lesson.txt` — one-sided limits

Read all 144 lines. **Outcome: no verified mathematical, scope, or key defect.**

The jump is `x+1` to the left of 1 and `x+3` to the right, with point value 4; the displayed table is numerically correct. The finite bilateral criterion is justified in both directions and explicitly assumes domain inputs arbitrarily close on both sides. The hole `(x²−4)/(x−2)=x+2` is simplified only for `x≠2`. Source visuals correctly use separate jump traces and a point `(1,4)`, and explain the missing open endpoint and hole `(2,4)`. No infinite-limit or formal epsilon-delta background is required.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | At −2, left `2(−2)−1=−5`, right `−2+6=4` | D; only matching pair |
| Q2 | Only p has equal finite side limits (both −1); q has 2 versus 5, r lacks a finite left limit | B; only correct set |
| Q3 | Left limit 2, right `k+1`; equality iff k=1, regardless of b | C; only complete condition; E incorrectly requires b=2 |
| Bonus 1 | Left −1, right 1 for `|x|/x` | A; only correct pair and conclusion |
| Bonus 2 | Left rational branch tends to 6; right to 3m, so m=2; distinct point value requires c≠6 | E; only pair satisfying both demands |

## `writers/task_02/lesson.txt` — one-sided limits

Read all 141 lines. **Outcome: no verified mathematical, scope, or key defect.**

The left and right differences from the claimed jump limits are each `x−1`. Both directions of the finite-limit criterion are correct. For the hole, cancellation is restricted to `x≠2`; the difference from 4 is `x−2`. The jump graph deliberately shows complete auxiliary lines and explicitly restricts which portions belong to f. The hole graph is also explicitly auxiliary, so its complete line does not falsely assign the missing value. All required ideas stay within the brief.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | Left −4 and right 3 at −2 | D; only matching pair |
| Q2 | Changing only p(3) cannot reconcile side limits −1 and 5 | B; only effective conclusion |
| Q3 | u has side limits 4,4; v has 4,6 | C; only correct comparison |
| Bonus 1 | `3·2−1=2k+1` gives k=2 | A; unique parameter |
| Bonus 2 | At 1: left `x+1→2`, right `2x→2`; at 2: left 4, right 10 | E; only 1 has a bilateral limit |

## `writers/task_04/lesson.txt` — one-sided limits

Read all 138 lines. **Outcome: no verified mathematical, scope, or key defect.**

The worked jump, finite bilateral criterion, and hole reduction to `x+2` are all correct. The criterion assumes arbitrarily close domain inputs on each side. Source visuals match the formulas and explicitly exclude a vertical function segment, the left jump endpoint, and the hole `(2,4)`; the hole's complete line is called a reference line. Scope remains finite limits, piecewise rules, and available algebra.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | At −1, left `2(−1)+3=1`, right `4−(−1)=5` | B; only matching pair |
| Q2 | Both side limits are 4; point value 9 does not change the limit | D; only correct evaluation |
| Q3 | Left `3−2=1`, right `2k+1`; k=0, limit 1 | C; unique pair |
| Bonus 1 | Left limit 3 alone does not decide; finite bilateral limit occurs iff right limit is also 3 | E; only justified conclusion |
| Bonus 2 | `|x|/x` has side limits −1,1; `|x|` has side limits 0,0 | B; only correct comparison |

## `writers/task_07/lesson.txt` — chain rule

Read all 169 lines. **Outcome: no verified mathematical, scope, or key defect.**

The opening square has side 3 at t=1, exterior rate 6 cm²/cm, interior rate 2 cm/min, and area rate 12 cm²/min. Its plotted area `(1+2t)²` and `(1,9)` marker match the claim of increasing slope. The general argument tracks errors small relative to their own input increments and uses bounded `Δu/h`; it explicitly treats `Δu=0` without division. This is a valid informal justification, including when the interior derivative vanishes. The polynomial-power example, evaluation at the interior output, positive-integer power formula, and n=1 qualification are correct. No product rule, noninteger-power rule, or implicit differentiation is needed.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | Interior `4x³−2x+7`, exterior u⁵ | C; only prescribed decomposition |
| Q2 | Temperature rate −3 times sensor sensitivity 0.4 gives −1.2 V/min | D; only signed rate |
| Q3 | `6(2x³−5x+1)⁵(6x²−5)` | B; only identical derivative function |
| Q4 | `p'(q(1))q'(1)=6(−2)=−12`; `q'(p(1))p'(1)=5·4=20` | E; only pair |
| Bonus 1 | `J'=16(x−2)[(x−2)²+3]⁷`, so only x=2 | C; unique zero set |
| Bonus 2 | `24x(x²+1)²[(x²+1)³+2]³` | A; only complete three-layer derivative |

## `writers/task_08/lesson.txt` — chain rule

Read all 184 lines. **Outcome: no verified mathematical, scope, or key defect.**

The opening area rate is 12 cm²/s and the tangent `9+12(t−1)` correctly passes through `(1,9)`. The general proof writes exact derivative-error forms and explicitly extends the exterior error to `η(0)=0`; substituting and dividing only by nonzero h gives the chain rule even for zero intermediate changes. The polynomial example has derivative `4(2x³+x+1)³(6x²+1)` and value 4 at zero. The sum example and positive-integer power cases use only allowed prior rules; no later calculus operation is assumed.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | Interior `3x²−1`, exterior u⁵ | C; only stated order |
| Q2 | `f'(5)g'(2)=2(−3)=−6` | D; only rate |
| Q3 | `7(x³−4x+2)⁶(3x²−4)` | B; only identical derivative function |
| Q4 | `U'(1)=(5p(1)⁴+1)p'(1)=2` | A; only value |
| Bonus 1 | `24x[(x²+1)³+2]³(x²+1)²` | E; only full nested derivative |
| Bonus 2 | J' zeros {−1,0,1}; K' zeros {0}; common zero only 0 | C; only common zero set |

## `writers/task_09/lesson.txt` — chain rule

Read all 163 lines independently despite the parent's separate check. **Outcome: no verified mathematical, scope, or key defect.**

The opening exact increment is `ΔA=12h+4h²`, so its rate is 12; the area curve, tangent `9+12(t−1)`, and contact point agree. The exact error-factor argument defines an error zero at `Δu=0`, substitutes, and divides only by h; it is valid when either derivative vanishes. The worked fourth power and evaluation example are correct. The zero-derivative discussion distinguishes an instantaneous rate from constancy and assumes only polynomial powers and linearity.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | `4 m/s ·0.3 kg/m=1.2 kg/s` | C; only rate |
| Q2 | `5(4x²−3x+2)⁴(8x−3)` | B; only identical derivative function |
| Q3 | `f'(5)g'(2)=(−2)(−3)=6` | D; only value |
| Q4 | `K(2+h)=(3+h²)⁶>3⁶` for every nonzero real h, while K'(2)=0 | A; only correct statement |
| Bonus 1 | `24x[1+(x²+1)³]³(x²+1)²` | E; only full derivative |
| Bonus 2 | `U'(0)=4·2³(−3)=−96`; `V'(0)=g'(0)·0=0` | C; only ordered pair |

## `writers/task_10/lesson.txt` — chain rule

Read all 213 lines. **Outcome: no verified mathematical, scope, or key defect.**

The square-area example, tangent, and exact increment `12h+4h²` are consistent. The propagation proof bounds the interior change by a multiple of |h| and treats zero intermediate changes directly; no invalid increment cancellation occurs. The fifth-power and sum examples are correct. For `V=(x²+2)³`, `V'=6x(x²+2)²` and `V(h)−8=12h²+6h⁴+h⁶`, so the horizontal tangent `y=8` and rising values away from zero are correct. Both graph blocks agree with these formulas. Scope uses allowed polynomial derivatives, composition, and linearity only.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | `f'(4)g'(1)=(−2)3=−6` | D; only value |
| Q2 | `6(2x³−x+4)⁵(6x²−1)` | B; only identical derivative function |
| Q3 | Correct derivative is `10(x²−3x)⁴(2x−3)+3x²`; only the first summand needs the factor | C; only correction valid for all x |
| Q4 | H'(0)=`f'(2)·0=0`; K'(0)=`g'(1)·3=−6` | E; only ordered pair |
| Bonus 1 | `24x[(x²+1)³+2]³(x²+1)²` | A; only complete derivative |
| Bonus 2 | `W'=16(x−2)[(x−2)²+3]⁷`; only x=2 | D; only correct zero set |

## `writers/task_11/lesson.txt` — chain rule

Read all 156 lines. **Outcome: no verified mathematical, scope, or key defect.**

At side 5, the exterior rate 10 and interior rate 3 give 30 cm²/s. The exact area increment `30Δt+9(Δt)²`, tangent `25+30(t−1)`, and `(1,25)` point all agree. The general rate proof correctly controls propagated errors and does not divide by `Δu`. The fifth-power example, local-data evaluation, and distinction between a zero base and zero interior derivative are correct. The lesson uses only the stated derivative rules and composition; no extra calculus rule is silently needed.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | `7(2x³−x+4)⁶(6x²−1)` | C; only identical derivative function |
| Q2 | `f'(3)g'(1)=7(−2)=−14` | D; only value |
| Q3 | `J'=8(x−2)[(x−2)²+2]³`, hence J'(2)=0 despite positive base | B; only correct evaluation |
| Bonus 1 | `S'(1)=12·2⁵−15·2⁴=384−240=144` | A; only value |
| Bonus 2 | U=(x²+2)³ gives U'(1)=54; V=x⁶+2 gives V'(1)=6 | E; only pair |

## `writers/task_12/lesson.txt` — chain rule

Read all 155 lines. **Outcome: no verified mathematical, scope, or key defect.**

For side `1+t²`, the area at t=1 is 4, the rates are 4 cm²/cm and 2 cm/s, and the area rate is 8 cm²/s. The tangent `4+8(t−1)` and `(1,4)` marker are correct; the text distinguishes local approximation from finite-interval change. The general derivation explicitly uses differentiability to bound `|Δu|` by a multiple of |h| and handles `Δu=0` without division. The fourth-power example, sum example, and evaluation-order claims all follow from permitted polynomial derivatives and linearity.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | `6(2x³−5x+1)⁵(6x²−5)` | C; only identical derivative function |
| Q2 | `f'(5)g'(2)=4(−3)=−12` | D; only value |
| Q3 | `J'=7(4−x²)⁶(−2x)+3x²`; missing factor applies only to the first summand | B; only valid correction |
| Bonus 1 | `Q'=16(x−2)[(x−2)²+2]⁷`; only x=2 | E; only zero set |
| Bonus 2 | U'(1)=`3·2²·2=24`; V'(1)=`2·2·3=12` | A; only pair |

No optional mathematical corrections identified in these nine files.

## `writers/task_13/lesson.txt` — bras, kets, and outer products

Read all 194 lines. **Outcome: no verified mathematical, scope, or key defect.**

The bra/ket conversion, inner-product example −5i, conjugate symmetry, and conjugated coefficients are correct. The worked outer product is `[[2,i],[2i,−1]]`, whose action on `(1,1)ᵀ` is `(2+i,−1+2i)ᵀ`. The projector is derived by demanding an orthogonal residual; idempotence and the unnormalized-vector denominator follow correctly. In the real example, `u=(3,4)ᵀ/5`, input `(5,0)ᵀ`, output `(9/5,12/5)ᵀ`, and residual `(16/5,−12/5)ᵀ` are consistent, and the residual's inner product is zero. The graph's line, points, and segments encode exactly those real coordinates; it is explicitly not a general complex-plane representation. Familiar inner products, normalization, and eigenvectors suffice. There is no measurement-postulate or change-of-basis assumption.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | Bra `(1,−i)` and overlap `2i−i=i` | B; only correct pair |
| Q2 | `T|p⟩=0`; `T|q⟩=⟨q|q⟩|p⟩` | D; nonzero orthogonal p,q exclude the alternative outputs |
| Q3 | `Ps(1,1)ᵀ=(1−i,1+i)ᵀ/2` | A; only matching column |
| Q4 | Projector R/9 preserves r under one or two applications | C; only projector/output pair |
| Bonus 1 | TS=`|a⟩⟨a|`; ST=`|b⟩⟨b|` | E; only ordered pair |
| Bonus 2 | Outer product of `(2−i)u` is 5P; squared norm is 5, so its direction projector is P | B; only correct projector |

## `writers/task_14/lesson.txt` — bras, kets, and outer products

Read all 212 lines. **Outcome: no verified mathematical, scope, or key defect.**

All bra, inner-product, and coefficient-conjugation identities are correct. The worked outer product `[[2,1],[2i,i]]` has the stated action. The arbitrary sandwich factorization `⟨y|B|x⟩=⟨y|p⟩⟨q|x⟩` respects order and conjugation. The projection coefficient is solved from orthogonality; its matrix, idempotence, and unnormalized-vector correction are correct. The real graph uses the same input, projection, and residual as task_13; the line `(3t,4t)` is the same retained direction and the dot product is zero. The scope is newly introduced notation and linear maps, using permitted complex arithmetic, normalization, and eigenvectors. The phase bonus applies scalar conjugation; no physical phase/measurement claim is required.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | Bra `(−i,2)`; overlap `−i+2i=i` | B; only correct pair |
| Q2 | Outer product `[[−i,2],[−1,−2i]]` | D; only matching matrix |
| Q3 | `i(2−i)=1+2i` | C; only matching scalar |
| Q4 | Norm squared 2; projector `[[1,−i],[i,1]]/2` sends `(2,0)ᵀ` to `(1,i)ᵀ` | A; only matrix/output pair |
| Bonus 1 | T is nonzero; T²=`⟨b|a⟩T=0` | E; all other action/idempotence claims false |
| Bonus 2 | `e^(iθ)e^(−iθ)P=P` for real θ | B; only general identity |

## `writers/task_16/lesson.txt` — bras, kets, and outer products

Read all 222 lines. **Outcome: no verified mathematical, scope, or key defect.**

Conjugation and the worked inner products are correct. The worked outer product is `[[2,1+i],[2i,−1+i]]`; on `(1,1)ᵀ` it yields `(3+i,−1+3i)ᵀ`. The projector proposal is checked by retained-vector action, annihilation of perpendicular vectors, orthogonality of the residual, and idempotence; rank one is explained. The real example gives `[[1,1],[1,1]]/2`, output `(1,1)ᵀ`, and discarded vector `(1,−1)ᵀ`, agreeing with the graph's line and segments. The nonnormalized formula is derived by normalization and Q²=`⟨v|v⟩Q`. All operations stay within the brief; complex vectors are not treated as literal points in the real-plane graph, and physical measurement rules are not assumed.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | Bra `(−i,2)` and overlap i | C; only correct pair |
| Q2 | `|p⟩⟨q|=[[−i,1],[2,2i]]` | B; only matching matrix |
| Q3 | Linearity gives `T(2p−q)=(2i−2)r` | D; only correct general action formula |
| Q4 | Projector `[[1,−i],[i,1]]/2`; output `(1−i,1+i)ᵀ/2` | A; only matrix/output pair |
| Q5 | Divide Q by squared norm 4 | E; only correction preserving v and idempotence |
| Bonus 1 | PT=`|u⟩⟨u|z⟩⟨u|=0`; TP=`|z⟩⟨u|u⟩⟨u|=T` | B; only ordered pair |
| Bonus 2 | Unit-modulus scalar cancels with its conjugate in the outer product | D; only general identity |

## `writers/task_20/lesson.txt` — partial trace and reduced density operators

Read all 258 lines. **Outcome: no verified mathematical, scope, or key defect.** No graph blocks.

The arbitrary-local-outcome amplitude expansion derives `ρA,ik=Σj cij ckj*`, rather than assuming the central new construction. Its off-diagonal example `χ=(00+10+11)/√3` yields `[[1,1],[1,2]]/3`. The operator expansion and ordinary trace of `|j⟩⟨ℓ|` correctly extend the construction linearly to mixed states. The two-qubit block entries, displayed χ joint matrix, and formula for retaining B all preserve the specified index ordering. The contraction maps are explained before the basis proof; with basis columns U, the coefficient sum `Σm Ujm* Uℓm=δjℓ` has the correct conjugation. The worked ± contractions `(1,2)ᵀ/√6` and `(1,0)ᵀ/√6` add to the same matrix without losing weights.

The full probability proof correctly expands `Tr[(P⊗I)ρ]` as `Σijk Pik ρkj,ij`, giving `Tr(PρA)` for arbitrary projectors and the same identity for observables. The direct χ plus-outcome amplitudes give `5/6`, agreeing with the reduced calculation. Trace one, Hermiticity, positivity, Bell local purity 1/2 versus joint purity 1, and product-state reduction are all valid. Reduction is explicitly separated from actual measurement, outcome selection, and collapse. The new finite-dimensional central steps are shown using the stated density/entanglement prerequisites; no later entanglement or decoherence theory is assumed.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | First two terms survive as `2|0⟩⟨1|+3|0⟩⟨0|`; third has mismatched environment labels and vanishes | C; only correct operator |
| Q2 | Tracing A retains B's coherence between 1 and 2: `ρB=[[1,0,0],[0,1,−i],[0,i,1]]/3` | B; only correctly sized and conjugated matrix |
| Q3 | `3|0⟩⟨0|/4+|+⟩⟨+|/4=[[7,1],[1,1]]/8` | D; only matching matrix |
| Q4 | `⟨y+|ρA|y+⟩=3/10` | A; only probability |
| Q5 | Both A marginals I/2; computational equal-outcome probability is 0 for singlet versus 1/2 for I/4 | C; only local/joint comparison |
| Bonus 1 | `ρA=[[1,s],[s,1]]/2`, purity `(1+s²)/2` | B; only general formula |
| Bonus 2 | `p(−)=1/2·1/2+1/2·0=1/4` | E; only probability |

## `writers/task_21/lesson.txt` — partial trace and reduced density operators

Read all 232 lines. **Outcome: no verified mathematical, scope, or key defect.** No graph blocks.

The opening arbitrary local outcome gives the stated diagonal 3/4,1/4 matrix without treating it as a collapse. The general construction is derived from `Tr[ρ(P⊗I)]` with the correct row/column placement `ρab,a'b P a'a`, leaving `(ρA)aa'=Σbρab,a'b`. Contraction maps, elementary outer products, and pure-state coefficient conjugation are explained and agree. The χ worked entries, four-block formula, and formula retaining B are correct. The arbitrary-projector argument establishes all projective local probabilities; the direct plus probability is 5/6. The positivity, Hermiticity, and trace-one arguments are valid.

The basis proof expands new basis columns U using `Ubβ* Ucβ`; its complete orthonormal sum is δbc. The concrete ± transformation cancels cross terms while keeping unnormalized weights. The pure joint state's local purity is 5/8, and the product-state reduction and mixedness/entanglement qualification are correct. Finite basis changes and contraction algebra are introduced as part of this node's scope, rather than requiring reduced states from a later node. No unsupported central operation or physical-collapse step is used.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | Coefficient rows `(1,i)` and `(0,1)` give `[[2,i],[−i,1]]/3` | C; only matching matrix |
| Q2 | `⟨y+|[[2,−i],[i,2]]/4|y+⟩=3/4` | D; only probability |
| Q3 | Contractions use `e^(−iθ)` from the basis bras; summing both outer products cancels cross terms | B; only generally valid prescription |
| Q4 | Singlet and incoherent mixture have local purity 1/2; ++ probabilities 0 and 1/4 | A; only comparison |
| Bonus 1 | Coefficient rows `(1,0,1)/2`, `(0,1,1)/2` give `[[1/2,1/4],[1/4,1/2]]`, purity 5/8 | E; only matrix/purity pair |
| Bonus 2 | Mixture reduces to `diag(p,1−p)`; plus probability 1/2 independent of environment overlap | C; only general formula |

## `writers/task_22/lesson.txt` — partial trace and reduced density operators

Read all 247 lines. **Outcome: no verified mathematical, scope, or key defect.** No graph blocks.

The opening density matrix follows from an arbitrary local amplitude, then the general pure-state squared-amplitude expansion exposes the retained entry `Σb cab ca'b*`. The extension to mixed states, contraction map, elementary outer-product action, and grouped χ calculation are correct and explicitly explained. The block-entry recipe and formula retaining B match the chosen ordering. The full local trace identity includes the correct factor `⟨a'|P|a⟩⟨b'|b⟩`, collapses the environment labels, and gives `Tr(ρAP)` for arbitrary local projectors. Its direct χ probability 5/6 and density-validity checks are correct.

The concrete ± contractions and the general new-basis entry expansion both yield the original matrix. The written identity `Σk Ubk* Ub'k=δbb'` is the conjugate of the usual component form of UU†=I and is equally valid because the delta is real; it is not a conjugation error. Completeness is explicitly required, making the missing-third-basis-vector question valid. The local purity 5/8, product-state contrast, and surviving joint coherences `√3/4` are correct. Central construction/probability/basis steps are developed within scope; no collapse or later entanglement machinery is assumed.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | Coefficient rows `(1,i)` and `(1,0)` give `[[2,1],[1,1]]/3` | B; only matrix |
| Q2 | `⟨y|[[1,−i],[i,2]]/3|y⟩=5/6` | D; only probability |
| Q3 | The two ± vectors span only {|0⟩,|1⟩}; adding |2⟩ completes the orthonormal basis, with unnormalized contributions | C; only repair guaranteed for every joint state |
| Q4 | Φ+ and Φ− both reduce to I/2; ++ probabilities are 1/2 and 0 | A; only local/joint comparison |
| Bonus 1 | Coefficient rows `(1,1,0)/√6`, `(1,−1,√2)/√6` give `diag(1/3,2/3)`, purity 5/9 | E; only purity |
| Bonus 2 | Environment overlap is 1/√2 for α and 0 for β; plus probabilities `(1+1/√2)/2`, 1/2 | B; only pair |

## `writers/task_23/lesson.txt` — partial trace and reduced density operators

Read all 268 lines. **Outcome: no verified mathematical, scope, or key defect.** No graph blocks.

The initial pure-state probability and its general amplitude expansion derive `ρA,ij=Σμ ciμ cjμ*` correctly. The mixed-state definition, contraction examples, elementary tensor-outer-product action, and rule retaining B use the correct subsystem indices. The worked joint matrix is positive and trace one; its block traces give `[[3,1],[1,5]]/8` and plus probability 5/8. Hermiticity, trace preservation, and positivity follow from the shown sums. The general local-projector trace identity uses `ρiμ,jμ Pji` and is correct for every projector and local observable.

The basis proof uses new-basis columns U and `Σα Uμα* Uνα=δμν`, with correct conjugation; the ± worked outer products sum to `diag(3/4,1/4)`. The general proof and an independent exact complex-unitary check on the worked mixed matrix give identical reduced matrices. A separate trace calculation gives the same arbitrary complex local outcome probability before and after reduction. Joint purity 1, local purity 5/8, pure-product reduction, and the no-collapse discussion are correct. New central steps are explicitly constructed and verified using the allowed finite-dimensional density and entanglement background.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | Coefficient rows `(1,0)` and `(i,1)` give `[[1,−i],[i,2]]/3` | C; only matrix |
| Q2 | Coherence 00↔11 vanishes from both reductions: `ρA=I/2`, `ρB=diag(4,6)/10` | D; only pair; supplied joint matrix also checked positive |
| Q3 | Imaginary coherence sign gives pR(y+)=1/4, while pS(y+)=1/2 | B; only pair |
| Q4 | Both rotation cross terms cancel and cos²θ+sin²θ=1; result `diag(2/3,1/3)` | E; only general matrix |
| Q5 | Both marginals I/2; Φ− has ++ probability 0, mixture 1/4 | A; only comparison |
| Bonus 1 | Reduction `[[1/2,1/4],[1/4,1/2]]` has purity 5/8 and minus probability 1/4 | D; only pair |
| Bonus 2 | Reduction `[[1,r],[r,1]]/2` gives plus probability `(1+r)/2` | B; only general formula |

## `writers/task_24/lesson.txt` — partial trace and reduced density operators

Read all 239 lines. **Outcome: no verified mathematical, scope, or key defect.** No graph blocks.

The opening amplitudes √(2/3),√(1/3) give the stated arbitrary-local-outcome probability and reduced diagonal matrix. The general pure-state expansion correctly derives `ρA,ij=Σb cib cjb*`. The mixed extension explains joint row/column pairs and matching discarded labels. The worked matrix is indeed an equal mixture of |+0⟩ and |01⟩; its reduction is `[[3,1],[1,1]]/4` and its minus probability is 1/4. Density validity is established by trace, conjugation, and positive quadratic forms. The full local trace argument correctly sums `ρib,jb Pji` for arbitrary projectors, and also applies to observables.

New-basis contraction expands using `Ubk* Uck`; completeness yields δbc with no conjugation error. The ± example sums unnormalized outer products to `diag(2/3,1/3)`. An independent exact complex-unitary check of the Q2 mixed matrix preserves its reduced matrix, and its complex local probability agrees with the joint trace. The opening local purity is 5/9, joint purity 1, and its retained joint coherences have coefficient √2/3. Product-state reduction and the distinction between mixedness of a reduction and entanglement of an unspecified mixed whole are correct. The lesson develops the central finite-dimensional steps and does not treat reduction as collapse or require later theory.

| Item | Independent result | Key / uniqueness |
| --- | --- | --- |
| Q1 | Coefficient rows `(1,1)` and `(0,1)` give `[[2,1],[1,1]]/3` | C; only matrix |
| Q2 | Block traces give `[[3,−1],[−1,5]]/8`; plus probability `(3+5−2)/16=3/8` | B; only probability; joint positivity also checked |
| Q3 | Rotation preserves the sum of outer products, giving `diag(3/4,1/4)` for every real θ | D; only general matrix |
| Q4 | Φ− and mixture have same A marginal; both-plus probabilities 0,1/4 | A; only comparison |
| Bonus 1 | Reduction `[[1,−i],[i,2]]/3`; off-diagonal −i/3 and purity `(1+4+2)/9=7/9` | E; only pair |
| Bonus 2 | Off-diagonal entries are s*/2 and s/2; plus probability `(1+Re s)/2` | C; only general formula |

## Final reconciliation

All 24 assigned complete texts were read without truncation. A final count of question/bonus/answer tags confirms 90 main questions and 48 bonus questions, one key per item. All 138 keys agree with the independent calculations and general-identity readings recorded above. No substantive defect is verified. The sole optional wording precision is `task_17` Q2, explicitly distinguished from an erroneous key. Actual runtime graph rendering remains outside this source-level audit; no renderer-dependent defect has been alleged without evidence. The seven initial audits remain preserved above.
