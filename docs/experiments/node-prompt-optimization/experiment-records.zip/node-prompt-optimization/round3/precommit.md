# Round 3 frozen transfer test

Before seeing Round 2 results, compare the unchanged baseline, coherent, and synthesis variants on the four hold-out nodes declared before Round 1: one_sided_limits, chain_rule, bra_ket_notation, partial_trace. Generate two fresh first outputs per node/condition, all GPT 6.1 Sol low. This is 24 fresh author outputs, each evaluated by three fresh blind Luna graders, one at each position, across six complete orders per node. Do not reuse or select outputs, alter node scopes/background, alter the rubric, or tune any variant on these outcomes during this round. Repeated reviewer judgments of one output are not independent author samples.

Primary decision uses per-node mean and within-panel preference, together with separate correctness/scope audit. A higher overall mean with a material loss on a node is not a universal improvement. Small differences near the ceiling warrant caution. The initial rubric target of repeated 9.5+ does not establish measured human learning. If these nodes later guide revision, call them development nodes and reserve additional unseen nodes for the next check.

This test is committed before the resumed Round 2 grading concludes, so candidate inclusion is not selected from those scores. These are the same exact variants as the preceding pilot, not fresh rewrites.
