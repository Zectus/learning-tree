from pathlib import Path
from collections import Counter
import hashlib,json,shutil,zipfile,itertools
r=Path(__file__).parent;s=Path('/workspace/node-qm-effort-pilot');m=json.loads((r/'manifest.json').read_text());old=json.loads((s/'manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for c,q in m['authors'].items():assert sha(r/'writers'/c/'lesson.txt')==sha(s/'writers'/c/'lesson.txt')==q['lesson_sha256']
for f in ['reader-context.txt','grading-instructions.txt']:assert (r/f).read_bytes()==(s/f).read_bytes()
for reader,order in m['orders'].items():
 d=Path(m['neutral_root'])/reader;src=m['source_packets'][reader]
 assert sha(d/'packet.txt')==m['packet_sha256'][reader]==old['packet_sha256'][src]
 expected=(r/'reader-context.txt').read_text()
 for label,c in zip('ABCD',order):expected+='\n\nLESSON '+label+'\n\n'+(r/'writers'/c/'lesson.txt').read_text()
 assert (d/'packet.txt').read_text()==expected
 for f in ['report.md','scores.json']:assert (d/f).read_bytes()==(r/'blind'/reader/f).read_bytes()
for c in m['conditions']:assert Counter(o.index(c) for o in m['orders'].values())=={0:1,1:1,2:1,3:1}
for a,b in itertools.combinations(m['conditions'],2):assert sum(o.index(a)<o.index(b) for o in m['orders'].values())==2
log=json.loads((r/'launch-log.json').read_text());assert len(log['graders'])==4 and all(q['status']=='completed' for q in log['graders'])
for q in log['graders']:
 a=q['spawn_arguments'];assert a['model']=='gpt-6.1-sol' and a['reasoning_effort']=='low' and a['fork_turns']=='none'
assert sha(Path('/workspace/learning-tree/js/learn/node-prompt.js'))=='f629442764c4a507f6a0dab6b1ea5551982ad1b9c52076d34746af9f21765ea8'
(r/'completion-checks.json').write_text(json.dumps({'new_lessons_generated':0,'all_four_lessons_byte_identical':True,'rubric_and_brief_byte_identical':True,'exact_prior_packets_reused':[1,3,5,7],'four_fresh_sol_6_1_low_graders_completed':True,'each_version_once_each_position':True,'pairwise_relative_orders_two_each':True,'raw_reports_preserved':True,'all_packet_and_output_hashes_valid':True,'math_and_structure_checks_reused_via_unchanged_hashes':True,'production_prompt_unchanged':True},indent=2)+'\n')
out=r/'experiment-records.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(r.rglob('*')):
  if f.is_file() and f.suffix!='.zip' and f.name!='archive.sha256':z.write(f,'node-qm-sol-readers/'+str(f.relative_to(r)))
 for f in sorted(Path(m['neutral_root']).rglob('*')):
  if f.is_file():z.write(f,'node-qm-sol-readers/grading-packets/'+str(f.relative_to(m['neutral_root'])))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
(r/'archive.sha256').write_text(sha(out)+'  experiment-records.zip\n')
d=Path('/workspace/learning-tree/docs/experiments/node-qm-sol-readers');d.mkdir(parents=True,exist_ok=True)
for f in ['README.md','protocol.md','aggregate.json','content-audit.md','completion-checks.json','experiment-records.zip','archive.sha256']:shutil.copyfile(r/f,d/f)
print(d)
