from pathlib import Path
from collections import Counter
import json,hashlib,shutil,uuid,itertools
r=Path('/workspace/node-qm-sol-readers');r.mkdir();s=Path('/workspace/node-qm-effort-pilot');old=json.loads((s/'manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for f in ['reader-context.txt','grading-instructions.txt','original-prompt.txt','content-audit.md','math-audit.json','structural-audit.json']:
 shutil.copyfile(s/f,r/('previous-'+f if f=='content-audit.md' else f))
m={'node':old['node'],'conditions':old['conditions'],'authors':old['authors'],'orders':{},'packet_sha256':{},'source_packets':{},'grader_model':'gpt-6.1-sol','grader_effort':'low','source_study':str(s)}
n=Path('/workspace')/('lesson-eval-'+uuid.uuid4().hex[:10]);n.mkdir();m['neutral_root']=str(n)
for c,q in m['authors'].items():
 d=r/'writers'/c;d.mkdir(parents=True);p=s/'writers'/c/'lesson.txt';assert sha(p)==q['lesson_sha256'];shutil.copyfile(p,d/'lesson.txt')
for i,k in enumerate([1,3,5,7],1):
 reader=f'reader_{i}';source=f'reader_{k}';m['orders'][reader]=old['orders'][source];m['source_packets'][reader]=source
 d=n/reader;d.mkdir();src=Path(old['neutral_root'])/source
 for f in ['packet.txt','instructions.txt']:shutil.copyfile(src/f,d/f)
 assert sha(d/'packet.txt')==old['packet_sha256'][source];m['packet_sha256'][reader]=sha(d/'packet.txt')
 assert (d/'instructions.txt').read_bytes()==(r/'grading-instructions.txt').read_bytes()
for c in m['conditions']:assert Counter(order.index(c) for order in m['orders'].values())=={0:1,1:1,2:1,3:1}
for a,b in itertools.combinations(m['conditions'],2):assert sum(o.index(a)<o.index(b) for o in m['orders'].values())==2
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
a=(s/'aggregate.py').read_text().replace('len(ss)==8','len(ss)==4').replace('{0:2,1:2,2:2,3:2}','{0:1,1:1,2:1,3:1}');(r/'aggregate.py').write_text(a)
(r/'protocol.md').write_text('''# Four Sol 6.1 readers, unchanged lesson comparison\n\nReuse all four exact lessons from node-qm-effort-pilot: low original, low self-review, xhigh original, xhigh self-review. No generation, revision or critique calls. Grade with four fresh gpt-6.1-sol low agents, fork none, no children. Low effort is an explicit assumption stated before launch; user specified the model but not grader effort.\n\nReuse the exact previous packets 1,3,5,7 and unchanged instructions. This subset gives each condition once in each label position and each pair in each relative order twice. Agents see only anonymous packets and the unchanged five-criterion engaged-human-reader rubric, no prompts, conditions, original model settings, prior scores or other reports. Blinding is procedural on a shared filesystem. Preserve all raw grades, compute equal criterion means, use formal JSON ranks/ties, audit attribution errors without selective reruns or rescoring. All lesson math/structure checks are reused through verified byte-identical hashes.\n\nReader model and panel count differ from the previous eight-Luna study. Cross-study absolute scores are not a calibrated common scale. Four graders still share the same single original/revision pair per effort. Sol judges Sol outputs, so same-family preference is not controlled. No human outcomes or cost measurements; no production changes.\n''')
shutil.copyfile(__file__,r/'build.py');print(n)
