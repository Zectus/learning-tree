# Independent lesson evaluation

Ranking: **D > C > A > B**. Confidence is moderate-high in the advantage of C/D over A/B, and moderate in the small differences within each pair. All four are strong, accurate lessons that meet the central scope for an actively engaged beginner. Scores are equally weighted; length and question counts receive no independent credit.

| Lesson | Conceptual clarity | Scaffolding | Worked reasoning / transfer | Active learning | Correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 8.9 | 9.0 | 8.8 | 10.0 | **9.22** |
| B | 9.4 | 8.7 | 8.8 | 8.8 | 10.0 | **9.14** |
| C | 9.6 | 9.1 | 9.6 | 8.7 | 10.0 | **9.40** |
| D | 9.6 | 9.3 | 9.6 | 8.7 | 10.0 | **9.44** |

## Lesson A

Its strongest feature is the connection between the computational rule and the physical purpose. The opening derives the probability for arbitrary local ket u, rather than identifying a diagonal matrix from one measurement alone. Section 2 derives the entry sum from the joint measurement projector, then explicitly explains that off-diagonal local terms survive when their environment labels match. The example yielding [[1,1],[1,2]]/3 and the two independent calculations of p(+)=5/6 make that connection usable.

A improves the decoding of notation with the explicit action (I tensor <b|)|ac> = <b|c>|a> and the expanded off-diagonal expression c00 c10* + c01 c11*. Those are small but valuable bridges for a first encounter. Its general product-state calculation and warning that mixed reductions of mixed joint states do not establish entanglement are particularly precise.

The most important weakness is compression at difficult transitions: the first trace expansion already has the discarded row and column indices identified, and the basis-independence proof moves quickly into a three-index unitary sum. These are derivable, but ask a beginner to reconstruct more intermediate reasoning than C/D. The anti-collapse distinction is stated well, yet its concrete joint-probability demonstration is left to Question 4 rather than worked through. This is a meaningful support gap, not a mathematical defect.

The questions are well targeted: Question 1 tests complex conjugation, Question 2 local sufficiency, Question 3 phase-dependent basis change and preservation of weights, and Question 4 local versus joint predictions. The qutrit-environment bonus adds genuine transfer, and the mixed-product bonus distinguishes incoherent mixing from interference. The phase-dependent Question 3 is stronger reasoning practice than a simple restatement of basis independence.

## Lesson B

Its strongest feature is the same coherent probability-first structure: arbitrary local outcomes motivate reduction, the entry formula explains which labels are summed, and the 5/6 local/joint comparison shows why local coherence matters. The purity calculation 5/8 versus joint purity one and the explicit caveat about mixed global states prevent common interpretive errors. Its question set offers the same substantive strengths as A.

Its most important weakness is slightly less support for translating unfamiliar notation into operations. The sandwich formula is described as acting on the environment but lacks A's explicit action on a product ket; the worked off-diagonal entry is simply 1/3+0 rather than tied directly to the coefficient products. The reader can recover both from the surrounding formulas, so the difference is modest. Together with the compressed trace and unitary-index derivations, it increases the amount of independent reconstruction needed for this stated first-time learner. B is not worse because it is shorter; it is slightly worse because these particular omitted steps clarify new operations.

## Lesson C

Its strongest feature is its explicit, transferable chain of reasoning. Section 2 displays the four-index trace with the Kronecker delta, then separately writes tr(RP)=sum R_ik P_ki before matching coefficients. That makes the formula follow from the local measurement requirement. The complex joint matrix and reduced matrix [[1,-i],[i,2]]/3 teach conjugation and basis ordering in a worked case; the block-trace observation gives another practical route. The y-plus comparison verifies 5/6 by both methods.

The completeness proof of basis independence uses a previously explained tensor-term rule and a concrete plus/minus cancellation with unnormalized local vectors. Section 5 goes beyond warning against collapse: it exhibits the joint coherence terms absent from an actual mixture and calculates a joint projector probability of 1 versus 5/8. This is a particularly effective demonstration of what reduction preserves and what it omits.

The most important weakness is that learners who choose a plausible wrong answer receive no written explanation of the mistake in the supplied lesson. There are good worked models, but no question-specific worked solutions. Also, the basis-independence section carries the additional burden of first introducing the partial-inner-product maps and tensor-term rule; its fairly long sequence requires sustained attention. Both are manageable for an engaged reader, but meaningful opportunities for improvement remain.

The exercises support useful extension: a three-level environment, a rank-two local projector on a three-level system, a state with overlapping environment kets, and reversal of the discarded subsystem. Question 3 checks that unnormalized contributions must sum to the same operator, but subtraction alone solves it; it probes the mechanism of basis change less deeply than A/B's phase-dependent question. The unitary-on-B bonus is a worthwhile further inference from basis invariance.

## Lesson D

Its strongest feature is the same comprehensive explanation as C, with slightly better placement of tools. The partial-inner-product examples and tensor-term rule appear at the beginning of computation, before the complex matrix example. Thus the statement that local off-diagonals survive is explained before it is demonstrated numerically. The later basis-independence section can focus on completeness and cancellation without simultaneously introducing the operation's notation. This is a small sequencing advantage, not a large content advantage.

The explicit delta derivation, complex 5/6 verification, general density-operator checks, numerical basis-change cancellation, and 1-versus-5/8 joint measurement comparison together give an engaged reader a strong path from motivation to calculation to interpretation. Question 4's purity 3/4 requires transferring the rule to nonorthogonal environment states; Question 5 tests equal local states with disjoint joint computational outcomes. These require achievable reasoning rather than recall.

Its most important weakness, shared with C, is the lack of written question-specific reasoning or corrective feedback. Question 3 in particular can be solved by matrix subtraction without demonstrating why the new-basis contributions have the required form. The lesson already explains that mechanism well, so this limits diagnosis of understanding rather than making the concept inaccessible. D also offers no fully worked reduction of a genuinely mixed joint matrix, although its general derivation applies to one. This is an additional transfer opportunity, not a scope or correctness failure.

## Correctness and decisive tradeoffs

I found no substantive mathematical or scope errors in any lesson. The phase signs in A/B Question 1, C/D's complex worked matrix and reverse-subsystem bonus, the rank-two probability 7/10, and the nonorthogonal-environment purity 3/4 are consistent with the entry rule. All basis-independence arguments are valid, and none treats the partial trace as a physical collapse. The available prerequisites support the trace and amplitude manipulations used. The lessons' projector formulations cover the intended measurement framework; the displayed linear identity also supports local observables.

The decisive advantage of C/D is explanatory support at points where a beginner might otherwise memorize the rule: the full index matching, complex matrix computation, numerical unnormalized basis contributions, and explicit joint-state comparison. A/B have a compensating advantage in symbolic basis-change practice and the explicit mixed-state entanglement caveat. D's lead over C and A's over B are modest scaffolding judgments. A reader comfortable reconstructing algebra who prefers a compact account and a more symbolic basis-change challenge could reasonably prefer A; a reader who prefers computing entries before learning the sandwich notation could reasonably choose C over D. These preferences could reverse the close within-pair ordering without changing the quality of the mathematics.
