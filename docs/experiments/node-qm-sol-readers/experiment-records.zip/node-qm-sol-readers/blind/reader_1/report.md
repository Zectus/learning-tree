# Independent evaluation

Ranking: **D > C > B > A**. Confidence is high that C/D provide the stronger overall teaching experience, but moderate for D versus C and B versus A: those adjacent differences are small refinements, not different levels of mathematical quality.

Each criterion carries 20%; overall scores are arithmetic means.

| Lesson | Conceptual clarity | Scaffolding | Worked reasoning / transfer | Active learning | Correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.5 | 8.8 | 9.0 | 8.8 | 10.0 | 9.22 |
| B | 9.5 | 9.0 | 9.2 | 8.8 | 10.0 | 9.30 |
| C | 9.7 | 9.2 | 9.5 | 8.9 | 10.0 | 9.46 |
| D | 9.7 | 9.4 | 9.5 | 8.9 | 10.0 | 9.50 |

## Lesson A

Its strongest feature is the coherent connection between the operational goal and the index rule. The opening derives the probability for an arbitrary local ket, rather than inferring a density matrix from computational-basis probabilities alone. Section 2 then obtains `(rho_A)_{aa'} = sum_b rho_{ab,a'b}` from a local projector and explains that the discarded labels, rather than the retained labels, determine which coherences survive. The three-amplitude example and the direct/reduced calculations of `p(+) = 5/6` make that explanation usable.

The most important weakness is compression at the transitions into abstract notation. The trace expansion immediately removes the second environment index, and the sandwich notation receives only “sandwiches only the environment part” before being used. Both are valid, but a first-time learner must reconstruct more intermediate reasoning than in C/D. Its worked amplitudes are real; Question 1 reasonably tests complex conjugation, but without a worked complex example or explanatory solution, diagnosing a reversed imaginary sign is harder.

The questions nevertheless offer substantial engagement: Question 3 transfers basis invariance to a phase-dependent basis, Question 4 distinguishes a singlet from its incoherent mixture through a joint outcome, and the bonuses cover a three-level environment and a genuinely mixed joint state. The explicit warning that local mixedness does not establish entanglement for a general mixed joint state is particularly valuable. These are teaching strengths, not just extra question counts.

## Lesson B

B preserves A's strong motivation, derivation, local-probability check, and conceptual safeguards. Its strongest improvement is making the partial inner product readable: `(I_A tensor <b|)|ac> = <b|c>|a>` explains what the new map actually does. Writing the off-diagonal example explicitly as `c_00 c_10* + c_01 c_11*` also connects the rule to an individual calculation, improving transfer modestly.

Its main remaining weakness is the same fairly compressed trace derivation and the absence of a worked complex-coherence calculation before the complex question. The unitary-coefficient proof of basis invariance is correct and followed by a useful cancellation example, but demands more simultaneous index tracking than C/D's term-by-term completeness argument. The small advantage over A is consequently in scaffolding and worked execution; their conceptual and active-learning quality is essentially equal.

## Lesson C

C's strongest feature is the extensive bridge from general reasoning to concrete calculation. It explicitly displays `P_ki delta_lj`, retains all four indices before summing, and compares the result with `tr_A(RP)`. This explains why the formula must have its particular matching indices. The worked complex state then supplies a full joint matrix, the selected entries, a reduced matrix with imaginary coherence, and a superposition-outcome check giving `5/6` by both routes. The block-trace alternative is correctly tied to the stated basis ordering.

Its treatment of “no collapse” is especially effective: the pure joint state and statistical mixture share a reduction, yet the joint projector gives probabilities `1` and `5/8`. That is a worked consequence of the distinction, supplementing the verbal warning. The completeness proof and explicit plus/minus-basis outer products also establish basis independence at both general and numerical levels.

The main weakness is a manageable pacing issue: Section 3 introduces partial-inner-product maps and a tensor-term rule before reaching the promised matrix computation, after an already substantial formal Section 2. The machinery is useful, but temporarily competes with the learner's immediate computational goal. Question 3 also checks basis invariance mostly through matrix subtraction; A/B's phase-basis question probes the cancellation mechanism more deeply. C compensates with strong transfer to a rank-two qutrit projector, nonorthogonal environment states, reversing the retained subsystem, and a local unitary bonus.

## Lesson D

D's strongest feature is the same rigorous, concrete conceptual development as C with slightly better placement of new tools. Section 3 moves directly from the derived index rule into the complex matrix example and practice. The partial-inner-product and tensor-term machinery appears in Section 4 when it is needed for the basis-independence proof. This gives a first-time learner a successful calculation before introducing another representation, while preserving the full explanation.

Its most important remaining limitation is feedback rather than missing core content. Like the other lessons, it supplies keyed multiple-choice opportunities but no written reasoning for their answers. In particular, Question 4's nonorthogonal-environment example and Bonus 2's environment unitary require worthwhile synthesis; brief solution reasoning would help a learner distinguish a conceptual error from an arithmetic one. This is a refinement to an otherwise complete teaching sequence. The basis-invariance question itself also remains a relatively direct subtraction exercise. No substantial mathematical or scope error was found.

## Decisive tradeoffs and learner preferences

All four lessons correctly derive the finite partial trace, preserve local projective probabilities, demonstrate pure-joint/mixed-local behavior, and avoid treating reduction as physical collapse. The displayed calculations and keyed answers are consistent: for example, C/D's rank-two probability is `1/2 + 1/5 = 7/10`, and their nonorthogonal-environment example has joint purity `1` and reduced purity `3/4`. I found no substantive correctness defect in any lesson.

The principal advantage of C/D is their explicit intermediate index reasoning, worked complex coherence, and worked joint-measurement demonstration of information omitted by reduction. D's advantage over C is only sequencing. A learner who prefers algebraic representations before numerical work might prefer C; a reader comfortable filling intermediate steps and favoring the compact real-amplitude example could prefer B. A/B also provide a stronger phase-dependent basis-change exercise and an explicit mixed-joint-state bonus. These preferences could change a close personal choice, but C/D offer more reliable support for the stated average first-time engaged learner.
