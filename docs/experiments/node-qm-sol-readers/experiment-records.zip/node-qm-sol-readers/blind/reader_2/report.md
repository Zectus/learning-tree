# Independent lesson evaluation

Ranking: **B > A > D > C**. Confidence: **moderate** in this exact ordering, high that all four are strong, mathematically sound lessons. The gaps are small. Overall scores are arithmetic means of the five equally weighted criteria.

| Lesson | Conceptual clarity | Scaffolding | Worked reasoning / transfer | Active learning | Correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.6 | 9.2 | 9.6 | 8.7 | 10.0 | **9.42** |
| B | 9.6 | 9.4 | 9.6 | 8.7 | 10.0 | **9.46** |
| C | 9.3 | 9.0 | 9.0 | 8.6 | 10.0 | **9.18** |
| D | 9.3 | 9.3 | 9.3 | 8.6 | 10.0 | **9.30** |

## Shared strengths and limitations

All four motivate reduction by asking for a matrix that predicts every local measurement, rather than just matching computational-basis populations. All derive the retained entries from the joint trace with an arbitrary local projector, distinguish a partial trace from a scalar trace, justify positivity and normalization, prove discarded-basis independence, and explicitly reject interpreting the calculation as a physical collapse. These are substantial successes for the stated first-time learner. No later entanglement machinery is required. None contains a substantive mathematical or scope error that I found; the keyed answers and numerical examples are consistent.

The main shared teaching limitation is feedback after independent work. The packet provides hidden answer keys and useful distractors, but no worked solutions or explanations of why a mistaken option is wrong. I credit the questions as supported answer-selection opportunities, without assuming an unmentioned explanatory-feedback feature. An engaged learner who gets a conjugation sign wrong or normalizes the environment contributions incorrectly has to diagnose the mistake from the earlier exposition. This is a meaningful remaining improvement, not a reason to regard the lessons as unsuccessful. The absence of graphs is not a weakness for these finite matrix calculations.

## Lesson B

**Strongest feature:** the progression from a fully indexed rule to a genuinely complex worked calculation and then to basis independence. Section 2 explicitly displays the Kronecker delta in the joint event matrix element and compares the resulting sum with `tr(RP)`. This makes the equal discarded indices a consequence of the local measurement rule, rather than a recipe to memorize. Section 3 then builds the full joint matrix of `( |00> + i|10> + |11> )/sqrt(3)`, obtains the surviving imaginary coherence, and checks the `y+` probability both locally and jointly as `5/6`. These are complementary checks of the same idea.

B introduces the partial-bra maps and tensor-outer-product rule in Section 4, when the reader needs them for a new computational task. Relative to A, this gives the reader a concrete matrix calculation before a second abstract representation. The difference is small, but helps manage the first encounter with the notation. The completeness proof and the explicit two-matrix cancellation then reinforce each other.

Section 5 is especially effective: it compares joint purity one with local purity `5/8`, distinguishes local ensemble equivalence from the actual source, and computes a joint projector probability of one versus `5/8` for the corresponding statistical mixture. It demonstrates exactly what a replacement of the joint state would lose. Question 4 transfers to nonorthogonal environment vectors; Question 5 tests operational local versus joint distinguishability. The rank-two qutrit projector in Question 2 and the environment-unitary bonus broaden use beyond the opening example.

**Most important weakness:** independent exercises have no explanatory solutions, especially costly for the nonorthogonal-vector purity and environment-unitary transfer tasks. A smaller limitation is that Question 3 can be answered by matrix subtraction without understanding why the second basis gives the same sum. These do not undermine the excellent worked foundation.

## Lesson A

**Strongest feature:** the same careful general derivation and complex example as B, with exceptionally concrete links between equivalent ways of taking the trace. Before the matrix example, Section 3 explains the partial-bra map through its actions on `|1,0>` and `|1,1>`, and contrasts a disappearing `|00><11|` term with a surviving `|00><10|` term. This directly prevents the misconception that tracing out an environment deletes every local off-diagonal entry. The explicit full matrix and block-trace explanation make the method usable on supplied joint matrices as well as amplitude lists.

Its basis-independence section carefully fixes the retained basis, proves the result using completeness, and shows the cancellation numerically. Its warning against separately normalizing contributions is operationally useful. The local/joint comparison and question coverage have the same strengths as B, including higher-dimensional reduction and purity with overlapping environment states.

**Most important weakness:** the missing worked exercise feedback remains the main improvement. Relative to B, Section 3 introduces maps, a sandwich expression, a tensor-term rule, an amplitude formula, a full matrix and block traces before its first question. Each is relevant and explained, but this concentration of representations makes initial consolidation slightly harder. This is a modest pacing issue, not an objection to length or rigor. A learner who benefits from seeing the tensor-term meaning before manipulating a matrix could reasonably prefer A to B.

## Lesson D

**Strongest feature:** a coherent, accessible progression that reuses the real-amplitude state `( |00> + |10> + |11> )/sqrt(3)` to connect surviving coherence, a local `+` probability of `5/6`, and cancellation in a changed environment basis. The explicit action `(I tensor <b|)|ac> = <b|c>|a>` makes the new partial-bra operation readable. Writing the off-diagonal entry as `c00 c10* + c01 c11*` supplies an important bridge from the general formula to the numbers. These are small additions with real explanatory value over C.

The arbitrary-projector identity and validity checks are sound. The phase-dependent basis question asks for a meaningful extension of the worked plus/minus cancellation, while the singlet-versus-mixture question requires the reader to distinguish identical local states from different joint probabilities. The mixed product calculation and final mixed-state bonus correctly prevent treating local mixedness as an entanglement test for arbitrary joint states.

**Most important weakness:** compared with A/B, some demanding transfer is left to questions rather than worked reasoning. The first independently computed reduction contains complex phases even though the worked reduction is real, and the central warning against replacing the joint state is tested through the singlet example without a worked joint-probability contrast in the exposition. Both tasks are achievable with the prerequisites, but absent explained answers they provide less secure consolidation than A/B's worked complex example and explicit mixture comparison. A full numerical joint matrix is also not worked, although the displayed entry template does provide a usable procedure.

## Lesson C

**Strongest feature:** the compact connection between the local-probability purpose and a general computational rule. It does not merely assert basis independence: it expands the unitary coefficients and then gives a concrete cancellation using the same worked state. The questions test conjugation, local probabilities, phase-dependent changes of discarded basis, and the failure of replacing the singlet by a mixture. The qutrit-environment bonus and explicit statistical-mixture bonus offer useful extensions rather than repetition.

**Most important weakness:** a few bridges are too compressed for an average first encounter. The sandwich notation is described as acting only on the environment, but its action on a product ket is not demonstrated. In the worked reduction, the off-diagonal result is simply `1/3 + 0`, without displaying the two coefficient products. A careful learner can reconstruct both steps, but those are precisely the new operations the lesson is trying to establish. D repairs these points without materially increasing the burden. C also shares D's reliance on independent exercises for the first complex reduction and the explicit joint-measurement contrast, and the general lack of explained answers.

## Decisive tradeoff and learner preferences

B and A earn their slight advantage through explicit index-level reasoning, a worked complex coherence, direct local-versus-joint verification, and a calculated joint-state-versus-mixture comparison. D and C offer a gentler real-amplitude running example and a stronger main question about phase-dependent basis changes, but leave more of the complex and interpretive transfer for unsupported exercises. B's placement of the additional operator representation after the first worked matrix is my narrow reason for preferring it to A; D's two concrete notation bridges are my reason for preferring it to C.

A learner who likes a shorter running example and is comfortable filling algebraic gaps could prefer D, while one who wants operator notation explained before computation could prefer A. These preferences could change the top choice; they do not reveal a correctness problem in any lesson. None receives an overall score above 9.5 because explanatory feedback and consolidation after independent work remain meaningful improvements.
