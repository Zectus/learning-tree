# Independent lesson evaluation

**Ranking: A > B > C > D.** All four are strong, mathematically accurate lessons for the stated actively engaged first-time learner. The differences are instructional, with no substantive correctness or scope error found. Confidence is high in that broad judgment and moderate in the fine ranking; A and B are especially close.

Scores are out of 10. Each criterion contributes 20%; the overall is its arithmetic mean.

| Lesson | Conceptual clarity | Scaffolding | Worked reasoning / transfer | Active learning | Correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.8 | 9.4 | 9.7 | 9.2 | 10.0 | **9.62** |
| B | 9.8 | 9.3 | 9.7 | 9.2 | 10.0 | **9.60** |
| C | 9.7 | 9.2 | 9.3 | 9.0 | 10.0 | **9.44** |
| D | 9.7 | 9.0 | 9.1 | 9.0 | 10.0 | **9.36** |

## Shared strengths and limits

Every lesson motivates reduction through predicting arbitrary local outcomes, rather than merely matching computational-basis populations. Each derives the repeated-environment-index rule from the joint trace with an identity on the environment, proves preservation of local projector probabilities, checks density-operator properties, proves discarded-basis independence, and contrasts joint purity one with local purity 5/8. These are substantial explanations of why the recipe works. Projectors of higher rank and observable expectations are explicitly included. The projective-measurement treatment is appropriate to the supplied background; the absence of later measurement formalism is not a scope failure.

The questions have achievable mathematical and conceptual demands and useful distractors: wrong phase signs, adding incompatible amplitudes, losing local coherence, treating reduction as measurement, and incorrectly normalizing individual basis contributions. Answer tags are hidden, so they are not explanations a reader can consult. The main shared improvement would be short worked rationales following attempts, particularly for basis changes and phase signs. This is a feedback limitation rather than a defect in the underlying explanations. No graph is needed to make these finite matrix calculations intelligible, and I assign no penalty for its absence.

## Lesson A

**Strongest feature:** its connected worked reasoning. Section 2 exposes the intermediate four-index sum and Kronecker delta before comparing it with `tr(RP)`. Section 3 then builds the full complex joint matrix for `( |00> + i|10> + |11> )/sqrt(3)`, extracts its entries explicitly, and checks the reduced prediction for `y+` against the joint calculation: both give 5/6. This sequence makes conjugation, surviving coherence, and practical usefulness concrete. The block-trace observation provides an additional usable computational route with its basis ordering stated.

The basis-independence proof develops completeness term by term and then shows actual off-diagonal cancellation in two 2-by-2 matrices. Section 5's comparison with the statistical mixture is particularly effective: the omitted joint coherence terms have zero partial trace but remain in the joint state, and the joint projector distinguishes probabilities 1 and 5/8. This supplies evidence for the no-collapse claim rather than only repeating it.

Questions extend the method to a three-dimensional environment, a rank-two local outcome (7/10), nonorthogonal environment states (local purity 3/4), indistinguishable local preparations, reversed subsystem roles, and an environment unitary. These are meaningful transfer opportunities, not just repeated substitutions.

**Most important weakness:** no written solution rationale accompanies those transfer questions; the environment-unitary bonus in particular asks the learner to connect basis independence with an active transformation unaided. The lesson supplies enough mathematics to do it, so this is a minor improvement opportunity. Its advantage over B is also small: it lets the learner complete a concrete computation before learning partial-inner-product maps.

## Lesson B

**Strongest feature:** it combines the same detailed derivation, complex worked matrix, broad question transfer, and quantitative no-collapse comparison as A with an earlier explanation of the tensor-term rule. Before the worked matrix, the examples `(I tensor <0|)|10> = |1>` and `(I tensor <0|)|11> = 0` explain what the new maps actually do. The contrast between `|00><11|` vanishing and `|00><10|` surviving makes the fate of local coherence understandable before the calculation.

Its mathematics and question answers check out, including the 5/6 local probability, 7/10 rank-two outcome, purity pair (1,3/4), and reversed-system complex reduction. It does not normalize the environment contributions separately or equate tracing with selecting an outcome.

**Most important weakness:** Section 3 introduces the sandwich map, tensor-operator rule, amplitude formula, full joint matrix, block method, reversed reduction, and measurement comparison before the next section. Each step is explained, but the first-time reader must hold more representations before reaching the first calculation than in A. This is a modest pacing cost, not a serious overload, and some learners will prefer having the operator rule first. The same lack of worked question rationales applies.

## Lesson C

**Strongest feature:** a clear route from the operational purpose to retaining local interference. The real-amplitude example gives the reduced matrix `(1/3)[[1,1],[1,2]]`, and the joint and reduced calculations both produce 5/6 for `+`. The added explanation `(I tensor <b|)|ac> = <b|c>|a>` makes unfamiliar sandwich notation readable, and the explicit expression `c00 c10* + c01 c11*` helps the learner see exactly which amplitudes produce the off-diagonal entry.

The unitary-coefficient proof of basis independence is valid, followed by a concrete cancellation using `w+` and `w-`. Question 3 then transfers that idea to a complex phase rather than asking only for numerical subtraction. Question 4 makes the no-collapse distinction operational through the singlet's zero probability for `++` versus 1/4 for the mixture. The product mixed-state discussion correctly warns that mixed local states alone do not establish entanglement, and bonus 2 usefully tests reduction of an actual mixed joint preparation.

**Most important weakness:** several important transfers receive less worked support than in A/B. The phase-sensitive calculation arrives as question 1 after a real worked example, the basis-change cancellation remains in vector symbols rather than explicit matrices, and the quantitative joint-state/mixture comparison is left to question 4. These remain achievable with the prerequisites, but an average first-time learner has less opportunity to check the intermediate reasoning. A/B's more explicit treatment earns their higher worked-reasoning score; this is not a reward for length itself.

## Lesson D

**Strongest feature:** the same strong operational motivation and accurate progression through arbitrary local probabilities, entry-wise reduction, local interference, basis invariance, and mixedness as C. Its statement that environment labels determine whether a term survives directly prevents the common mistake of deleting all local off-diagonal entries. Its question set tests complex conjugation, a probability independent of unreported correlations, phased basis changes, the false collapse replacement, a three-state environment, and an actual mixed joint state.

**Most important weakness:** compared with C, two small but useful bridges are absent: an explicit example of how the partial bra acts on a composite ket, and the amplitude products behind the worked off-diagonal entry. The text instead gives “sandwiches only the environment part” and the numerical sum 1/3 + 0. An engaged reader can reconstruct both from the surrounding formulas, but these are precisely new operations at this node, so the missing bridges increase the inferential burden. As in C, the most demanding conceptual comparison is an exercise without written reasoning feedback. None of these omissions makes the lesson incorrect or unusable.

## Decisive tradeoffs and learner preferences

A narrowly wins for an average first-time learner because the explicit computational success comes before another operator representation. B may be preferable to a learner who wants the tensor-term interpretation before manipulating matrices. C and D offer a more compact path with good conceptual exercises, and a learner comfortable reconstructing omitted intermediate algebra may prefer them. C's two additional explanatory bridges justify its small advantage over D. The scores reflect these modest differences in support and transfer; there is no large teaching failure in this packet.
