# Crítica de la lección

La lección ofrece una ruta clara para una primera interpretación informal del límite: empieza con una tabla y un hueco, justifica el patrón con una identidad algebraica, separa después el límite del valor puntual y finalmente explica por qué una tabla finita solo sugiere. La secuencia está bien ajustada al alcance indicado y no presupone herramientas posteriores. No encontré errores matemáticos en los ejemplos ni en las respuestas señaladas.

## Lo que funciona bien para el aprendizaje

- **La idea central se construye con evidencia concreta.** En la sección 1, las filas a ambos lados de (2) muestran valores que se acercan a (4); luego la factorización establece (f(x)=x+2) para (x\ne2). El texto enlaza esa igualdad con una razón de distancias: una entrada a distancia (0.001) de (2) da una salida a distancia (0.001) de (4). Así, el aprendiz ve por qué la tabla sugiere el resultado y qué información adicional lo sustenta.
- **La restricción de dominio se conserva durante el razonamiento.** La frase «La cancelación […] no asigna un valor en (2)» previene una confusión frecuente sin deshacer el trabajo algebraico. La distinción reaparece con (g(2)=7), cuyo límite sigue siendo (4), y con la posibilidad de asignar (4) en el punto. Esto comunica que límite y valor puntual pueden coincidir o no.
- **La sección 3 calibra bien el papel de las representaciones.** Aclara que la igualdad (f(1.999)=3.999) es exacta, que (3.999) aproxima a (4), y que ni una tabla finita ni una gráfica bastan para demostrar el comportamiento. La razón exacta (f(x)=x+2) devuelve al aprendiz a la evidencia que sí cubre todas las entradas permitidas del ejemplo.
- **Las preguntas cubren errores distintos y transferibles.** La pregunta 1 distingue cancelar de asignar un valor y evita inferir el límite solo del numerador. La pregunta 2 prueba si se puede sostener un límite distinto del valor puntual. La 3 evalúa el estatus de evidencia finita. Los bonos amplían a una recta con pendiente distinta y a una diferencia cuadrática positiva que puede hacerse pequeña. Las claves indicadas son correctas.

## Mejoras concretas

1. **Hacer más explícita la lectura de la gráfica que el texto promete.** Se dice que la coordenada horizontal es (x) y la vertical es (f(x)), pero el lector no recibe una instrucción concreta para conectar el trazo con los pares de la tabla o para localizar el hueco. Una frase breve como «En el trazo, al movernos por la recta hacia (x=2) desde cualquiera de los dos lados, la altura se acerca a (4)» haría que la gráfica aporte evidencia propia y no quede como ilustración principalmente advertida por su limitación. No hace falta añadir una explicación más extensa.

2. **Conservar la salvedad sobre el punto ausente junto a la gráfica.** El bloque renderizado no puede dibujar el círculo abierto, y la curva de la fórmula original puede parecer una recta continua. El párrafo ya explica esta limitación con claridad. Como el título dice «punto ((2,4)) excluido», conviene asegurarse de que esa aclaración aparezca inmediatamente antes o después del gráfico en la versión presentada, como ya está en el borrador. La lectura visual depende de esa proximidad.

3. **Aterrizar una vez la frase informal sobre “suficientemente próximas”.** La sección 2 ofrece una formulación útil: hacer las salidas tan cercanas a (L) como queramos usando entradas próximas a (a), distintas de (a). Para un principiante, “suficientemente próximas” podría seguir sonando como una distancia misteriosa. La sección 1 ya tiene la intuición de reducir distancias; una remisión explícita («como vimos al reducir la distancia a (2)») ayudaría a unir la formulación general con el ejemplo, sin introducir épsilon-delta.

4. **Dar una ocasión breve de producir la explicación, no solo seleccionarla.** Las preguntas son buenas para detectar concepciones erróneas, pero todas son de opción múltiple. En una lección para alguien que trabaja activamente, una invitación de una línea después de la sección 2 podría pedir explicar por qué (g(2)=7) no cambia el límite en una oración. Esto haría visible si el alumno puede expresar la idea de “cerca, excluyendo el punto”, que es el objetivo central. Es una mejora opcional; no hace falta añadir más ejercicios de cálculo.

## Revisión matemática

- ((x^2-4)/(x-2)=x+2) para (x\ne2); los seis valores de la tabla son correctos. Las salidas se acercan a (4), y la función original no toma el valor (4).
- Para (p(x)=(x^2-9)/(x-3)), la expresión equivale a (x+3) fuera de (3), así que su límite es (6) aunque (p(3)) no exista: C es correcta.
- Los datos de la pregunta 2 son compatibles: límite (5), valor (12). B es correcta.
- En la pregunta 3, los datos coinciden con (r(x)=1+x) en las cuatro entradas, pero no determinan el comportamiento en todas las demás entradas cercanas. D es la conclusión justificada.
- Para (q(x)=8-2x) fuera de (4), el límite es (0) y cambiar solo (q(4)) no lo altera: E es correcta.
- Para (s(x)=5+(x-1)^2), la diferencia respecto a (5) es ((x-1)^2), que tiende a cero al acercarse (x) a (1); A es correcta.

En conjunto, la lección es matemáticamente correcta y su ritmo resulta razonable: un ejemplo desarrollado, una distinción conceptual, una advertencia epistemológica y práctica breve. Las mejoras sugeridas se concentran en sacar más provecho de la gráfica y en comprobar que el alumno puede verbalizar el razonamiento, sin alargar el contenido por sí mismo.
