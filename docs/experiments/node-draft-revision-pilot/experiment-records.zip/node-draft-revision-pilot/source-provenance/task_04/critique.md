# Comentarios sobre el borrador

El recorrido central funciona bien para una primera lección: parte de una tabla y un hueco visible, pasa a una identidad algebraica que explica todas las entradas cercanas, y después separa el límite del valor en el punto y de una aproximación concreta. Las tres preguntas principales comprueban esas distinciones, y los dos ejercicios adicionales transfieren la idea a otros datos. No hace falta alargarlo por sistema.

## Ajustes recomendados

1. **Revisar la opción E de la pregunta 1.** «No hay ninguna entrada del dominio distinta de \(-1\) cerca de \(-1\)» introduce un caso límite sobre puntos de acumulación del dominio. Según cómo se formalice el límite cuando el dominio no tiene entradas cercanas, puede considerarse compatible de manera vacía; además, el curso aún no ha explicado esa convención. Esto puede hacer que una pregunta de respuesta única parezca ambigua. Conviene sustituir E por una afirmación inequívocamente incompatible (por ejemplo, que las salidas cercanas se acerquen a un número distinto de 6), o añadir a la pregunta que hay entradas del dominio arbitrariamente cercanas a \(-1\) por ambos lados.

2. **Aclarar la primera frase sobre el hueco.** «Una fórmula puede dejar de dar un valor justo en el lugar que nos interesa» puede leerse como que la fórmula no da valor para toda entrada en ese lugar, cuando el problema es la expresión concreta y su dominio. Se podría decir: «Una función puede no estar definida en el punto que nos interesa. ¿Podemos describir lo que ocurre cerca de él?». Eso prepara mejor la distinción entre expresión y función definida en el punto.

3. **Hacer explícito el paso de la cercanía informal a una regla para toda entrada.** La frase «Si la entrada está a una milésima de 2, la salida está a una milésima de 4» es exacta, pero puede servir de puente explicar en palabras que la igualdad de distancias viene de \(|f(x)-4|=|x-2|\), para todo \(x\ne2\). Así se evita que “una milésima” se lea como otro ejemplo numérico en vez de una relación que garantiza el comportamiento. La exposición ya presenta la identidad con signo; añadir los valores absolutos o verbalizar «la distancia a 4 es igual a la distancia a 2» bastaría.

4. **Revisar «punto aislado» en la sección 2.** El punto \((2,9)\) no es un punto aislado de toda la gráfica: la recta continúa acumulándose alrededor de él. La intención parece ser que es un punto adicional separado de la recta. «Un punto separado de la recta en \((2,9)\)» expresa la imagen con más precisión y evita enseñar inadvertidamente un uso matemático distinto de “aislado”.

## Lo que está especialmente logrado

- La nota sobre el visor explica por qué una curva aparentemente unida no invalida el hueco. Es una respuesta directa a una limitación real del gráfico descrito.
- La cancelación está acotada correctamente a \(x\ne2\), y el texto recalca que no evalúa la función en el hueco.
- La comparación entre \(f(1{,}99)=3{,}99\) y el límite exacto 4 distingue con claridad un valor calculado de aquello a lo que se aproximan las salidas.
- La sección 3 no presenta una tabla finita como prueba: la contrasta con la identidad válida para todas las entradas del dominio. La pregunta correspondiente evalúa esa misma idea sin exigir técnicas posteriores.
- Los ejercicios adicionales varían los datos y conservan el razonamiento central; la práctica es suficiente para una lección breve.
