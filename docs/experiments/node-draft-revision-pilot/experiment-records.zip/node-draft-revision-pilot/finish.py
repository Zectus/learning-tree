from pathlib import Path
from collections import Counter
import hashlib,json,shutil,statistics
r=Path(__file__).parent;m=json.loads((r/'manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
criteria=['conceptual_clarity','scaffolding','worked_reasoning_transfer','active_learning','correctness']
samples={a:[] for a in m['authors']};panels={};errors=[];wins=Counter({'draft_wins':0,'revision_wins':0,'ties':0})
for reader,order in m['orders'].items():
 d=Path(m['neutral_root'])/reader;assert sha(d/'packet.txt')==m['packet_sha256'][reader]
 data=json.loads((d/'scores.json').read_text());assert set(data['scores'])==set('AB');assert sorted(x for g in data['ranking'] for x in g)==list('AB')
 dest=r/'blind'/reader;dest.mkdir(parents=True,exist_ok=True)
 for f in ['report.md','scores.json']:shutil.copyfile(d/f,dest/f)
 scored={}
 for pos,(label,a) in enumerate(zip('AB',order)):
  q=data['scores'][label];assert all(isinstance(q[k],(int,float)) and 0<=q[k]<=10 for k in criteria)
  mean=statistics.mean(q[k] for k in criteria)
  if abs(mean-q['overall'])>1e-8:errors.append({'reader':reader,'label':label,'reported':q['overall'],'computed':mean})
  samples[a].append({'reader':reader,'position':pos,'reported_overall':q['overall'],**q,'overall':mean})
  scored[m['authors'][a]['condition']]=mean
 groups=[[m['authors'][order['AB'.index(label)]]['condition'] for label in g] for g in data['ranking']]
 wins['ties' if len(groups[0])==2 else groups[0][0]+'_wins']+=1
 panels[reader]={'pair':m['authors'][order[0]]['pair'],'order':order,'ranking':data['ranking'],'condition_ranking':groups,'scores':scored,'revision_minus_draft':scored['revision']-scored['draft'],'confidence':data['confidence'],'decisive_tradeoff':data['decisive_tradeoff']}
summary={}
for a,ratings in samples.items():
 meta=m['authors'][a];assert len(ratings)==2 and set(q['position'] for q in ratings)=={0,1}
 assert sha(r/'writers'/a/'lesson.txt')==meta['lesson_sha256']==sha(Path(meta['source_path']))
 summary[a]={'condition':meta['condition'],'pair':meta['pair'],'means':{k:statistics.mean(q[k] for q in ratings) for k in criteria+['overall']},'ratings':ratings}
means={c:{k:statistics.mean(q['means'][k] for q in summary.values() if q['condition']==c) for k in criteria+['overall']} for c in m['conditions']}
pairs={p:{'draft':summary['draft_'+p]['means']['overall'],'revision':summary['revision_'+p]['means']['overall'],'revision_minus_draft':summary['revision_'+p]['means']['overall']-summary['draft_'+p]['means']['overall']} for p in ['02','04']}
out={'condition_means':means,'revision_minus_draft':means['revision']['overall']-means['draft']['overall'],'pairwise_preferences':dict(wins),'per_author_pair':pairs,'samples':summary,'panels':panels,'arithmetic_discrepancies':errors,'audit_notes':[{'reader':'reader_3','issue':'The report credits revision A with the displayed identity f(x)-4=(x+2)-4=x-2, and says draft B omits it. Both files contain the identical displayed equation. Only its explicit distance interpretation was added. Raw scores and ranking preserved without rescore or exclusion.'}]}
(r/'aggregate.json').write_text(json.dumps(out,indent=2)+'\n')
launch=json.loads((r/'launch-log.json').read_text())
for q in launch['graders']:q['status']='completed'
(r/'launch-log.json').write_text(json.dumps(launch,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k in ['condition_means','revision_minus_draft','pairwise_preferences','per_author_pair','arithmetic_discrepancies']},indent=2))
