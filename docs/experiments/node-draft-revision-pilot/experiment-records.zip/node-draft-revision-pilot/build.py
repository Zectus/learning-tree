from pathlib import Path
import json,hashlib,shutil,uuid
r=Path('/workspace/node-draft-revision-pilot');r.mkdir(exist_ok=False)
s=Path('/workspace/node-critique-pilot')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for f in ['reader-context.txt','grading-instructions.txt']:
 shutil.copyfile(s/f,r/f)
m={'node':'limit_intuition','writer_model':'gpt-6.1-sol','writer_effort':'low','grader_model':'gpt-6-luna','grader_effort_override':None,'source_study':str(s),'conditions':['draft','revision'],'authors':{},'orders':{'reader_1':['draft_02','revision_02'],'reader_2':['revision_02','draft_02'],'reader_3':['revision_04','draft_04'],'reader_4':['draft_04','revision_04']},'packet_sha256':{}}
expected={'draft_02':'2e80be70cff02bdb142011c2ae4cdea23f78ca662285ce2a7d46483d4add10d4','revision_02':'c8749e7dc5dd59775bef2e0fecaa7bfde3a2058080aeda21a586d9c7dfd9ff49','draft_04':'1d8c153bbbed605fdbfb99cffcb5eb4fe6c5e0c91c37408a4d30f801aa89178b','revision_04':'a5637c7f2b8b54e6d457b47564cc20d11a6b65bb96a2c0a01e18b434ab465b76'}
for a,h in expected.items():
 condition,pair=a.split('_');src=s/'writers'/('task_'+pair)/('draft.txt' if condition=='draft' else 'lesson.txt')
 assert sha(src)==h
 dest=r/'writers'/a;dest.mkdir(parents=True);shutil.copyfile(src,dest/'lesson.txt')
 m['authors'][a]={'node':'limit_intuition','condition':condition,'replicate':int(pair)//2,'pair':pair,'source_path':str(src),'lesson_sha256':h}
neutral=Path('/workspace')/('lesson-eval-'+uuid.uuid4().hex[:10]);neutral.mkdir();m['neutral_root']=str(neutral)
for reader,order in m['orders'].items():
 d=neutral/reader;d.mkdir();packet=(r/'reader-context.txt').read_text()
 for label,a in zip('AB',order):packet+='\n\nLESSON '+label+'\n\n'+(r/'writers'/a/'lesson.txt').read_text()
 (d/'packet.txt').write_text(packet);shutil.copyfile(r/'grading-instructions.txt',d/'instructions.txt');m['packet_sha256'][reader]=sha(d/'packet.txt')
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
shutil.copyfile(Path(__file__),r/'build.py')
print(neutral)
