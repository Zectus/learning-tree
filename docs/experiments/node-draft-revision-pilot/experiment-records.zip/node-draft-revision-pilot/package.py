from pathlib import Path
import hashlib,json,re,shutil,zipfile
r=Path(__file__).parent;s=Path('/workspace/node-critique-pilot');app=Path('/workspace/learning-tree')
m=json.loads((r/'manifest.json').read_text());launch=json.loads((r/'launch-log.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_manifest=json.loads((s/'manifest.json').read_text());obs=json.loads((s/'stage-observations.json').read_text())['hashes_observed_by_root_while_critics_running']
assert sha(app/'js/learn/node-prompt.js')==source_manifest['source_sha256']
assert len(launch['graders'])==4 and all(q['status']=='completed' for q in launch['graders'])
for q in launch['graders']:
 args=q['spawn_arguments'];assert args['model']=='gpt-6-luna' and args['fork_turns']=='none' and 'reasoning_effort' not in args
for a,meta in m['authors'].items():
 assert sha(r/'writers'/a/'lesson.txt')==meta['lesson_sha256']==sha(Path(meta['source_path']))
 pair=meta['pair'];task='task_'+pair
 if meta['condition']=='draft':
  process=json.loads((s/'writers'/task/'process.json').read_text())
  assert meta['lesson_sha256']==obs[task]==process['pre_critique_draft_sha256']
 else:assert meta['lesson_sha256']==source_manifest['authors'][task]['lesson_sha256']
for reader,order in m['orders'].items():
 assert len({m['authors'][a]['pair'] for a in order})==1
 d=Path(m['neutral_root'])/reader;assert sha(d/'packet.txt')==m['packet_sha256'][reader]
 expected=(r/'reader-context.txt').read_text()
 for label,a in zip('AB',order):expected+='\n\nLESSON '+label+'\n\n'+(r/'writers'/a/'lesson.txt').read_text()
 assert (d/'packet.txt').read_text()==expected
 assert (d/'instructions.txt').read_bytes()==(r/'grading-instructions.txt').read_bytes()
 for f in ['report.md','scores.json']:assert (d/f).read_bytes()==(r/'blind'/reader/f).read_bytes()
for f in ['reader-context.txt','grading-instructions.txt']:assert (r/f).read_bytes()==(s/f).read_bytes()
struct=json.loads((r/'structural-audit.json').read_text());assert len(struct)==4 and all(q['complete'] and q['questionsValid'] and all(not g['errors'] for g in q['graphs']) for q in struct.values())
aggregate=json.loads((r/'aggregate.json').read_text());assert not aggregate['arithmetic_discrepancies'];assert aggregate['pairwise_preferences']=={'draft_wins':0,'revision_wins':4,'ties':0}
assert abs(aggregate['revision_minus_draft']-.105)<1e-8
keys=sum(len(re.findall(r'^\[(?:QUESTION|BONUS) \d+\]',(r/'writers'/a/'lesson.txt').read_text(),re.M)) for a in m['authors']);assert keys==20
checks={'new_lessons_generated':0,'reused_draft_revision_pairs':2,'fresh_blind_graders':4,'all_jobs_completed':True,'all_texts_match_original_stage_hashes':True,'draft_hashes_match_root_observations_during_critique':True,'every_text_twice_once_each_position':True,'packets_and_unchanged_rubric_validated':True,'all_structure_checks_pass':True,'underlying_questions_checked':10,'total_key_occurrences_checked':20,'grade_arithmetic_errors':0,'material_grader_attribution_error_preserved':True,'raw_scores_neither_changed_nor_excluded':True,'production_prompt_unchanged':True,'production_prompt_sha256':source_manifest['source_sha256']}
(r/'completion-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
p=r/'source-provenance';p.mkdir(exist_ok=True)
for name in ['manifest.json','launch-log.json','stage-observations.json','content-audit.md','base-prompt.txt','idea-2-prompt.txt','prompt-addition.txt']:shutil.copyfile(s/name,p/name)
for task in ['task_02','task_04']:
 d=p/task;d.mkdir(exist_ok=True)
 for name in ['critique.md','revision-notes.md','process.json','revision.diff']:shutil.copyfile(s/'writers'/task/name,d/name)
model_note={'available_relevant_model_identifiers':['gpt-6.1-sol','gpt-6.1-terra','gpt-6-sol','gpt-6-luna'],'gpt_6_1_luna_exposed':False,'actual_grader':'gpt-6-luna','basis':'collaboration.spawn_agent model metadata exposed in this session; no separate model catalog tool found','not_a_claim_about_global_model_availability':True}
(r/'model-availability.json').write_text(json.dumps(model_note,indent=2)+'\n')
out=r/'experiment-records.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(r.rglob('*')):
  if f.is_file() and f.suffix!='.zip' and f.name!='archive.sha256':z.write(f,'node-draft-revision-pilot/'+str(f.relative_to(r)))
 for f in sorted(Path(m['neutral_root']).rglob('*')):
  if f.is_file():z.write(f,'node-draft-revision-pilot/grading-packets/'+str(f.relative_to(m['neutral_root'])))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for reader in m['orders']:assert hashlib.sha256(z.read('node-draft-revision-pilot/grading-packets/'+reader+'/packet.txt')).hexdigest()==m['packet_sha256'][reader]
(r/'archive.sha256').write_text(sha(out)+'  experiment-records.zip\n')
docs=app/'docs/experiments/node-draft-revision-pilot';docs.mkdir(parents=True,exist_ok=True)
for name in ['README.md','aggregate.json','protocol.md','content-audit.md','completion-checks.json','model-availability.json','experiment-records.zip','archive.sha256']:shutil.copyfile(r/name,docs/name)
print(json.dumps({'report':str(docs/'README.md'),'archive_bytes':out.stat().st_size,'checks':checks},indent=2))
