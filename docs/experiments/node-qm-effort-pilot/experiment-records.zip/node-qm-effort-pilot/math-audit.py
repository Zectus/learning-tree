from pathlib import Path
import sympy as s,json
r=Path(__file__).parent
pure=lambda v:v*v.conjugate().T
ptr=lambda M,na,nb:s.Matrix(na,na,lambda a,ap:s.simplify(sum(M[a*nb+b,ap*nb+b] for b in range(nb))))
chi=s.Matrix([1,0,s.I,1])/s.sqrt(3);M=pure(chi);R=ptr(M,2,2);assert R==s.Matrix([[1,-s.I],[s.I,2]])/3
y=s.Matrix([1,s.I])/s.sqrt(2);assert (y.conjugate().T*R*y)[0]==s.Rational(5,6)
w=s.Matrix([1,0,1,0,1,1])/2;assert ptr(pure(w),2,3)==s.Matrix([[2,1],[1,2]])/4
R2=s.Matrix([[3,1,0],[1,5,0],[0,0,2]])/10;v=s.Matrix([1,1,0])/s.sqrt(2);z=s.Matrix([0,0,1]);assert s.trace(R2*(pure(v)+pure(z)))==s.Rational(7,10)
assert s.Matrix([[4,1],[1,2]])/6-s.Matrix([[1,1],[1,1]])/6==s.diag(s.Rational(1,2),s.Rational(1,6))
xi=s.Matrix([1/s.sqrt(2),0,s.Rational(1,2),s.Rational(1,2)]);rx=ptr(pure(xi),2,2);assert s.simplify(s.trace(rx*rx))==s.Rational(3,4) and s.simplify(s.trace(pure(xi)**2))==1
eta1=s.Matrix([1,0,0,2])/s.sqrt(5);eta2=s.Matrix([0,1,2,0])/s.sqrt(5);assert ptr(pure(eta1),2,2)==ptr(pure(eta2),2,2)==s.diag(s.Rational(1,5),s.Rational(4,5))
g=s.Matrix([1,s.I,0,1])/s.sqrt(3);rb=s.Matrix(2,2,lambda j,l:sum(pure(g)[a*2+j,a*2+l] for a in range(2)));assert rb==s.Matrix([[1,-s.I],[s.I,2]])/3
(r/'math-audit.json').write_text(json.dumps({'new_original_keys':['A','D','C','D','C','D','A'],'numeric_examples_and_keys_exactly_checked':True,'last_bonus_argument':'Cyclic environment contraction or use orthonormal basis V_B dagger |j>; completeness gives unchanged reduction for arbitrary joint state. This follows from established basis independence.','low_keys_previously_checked':['C','D','B','A','E','C'],'method':'SymPy exact matrix arithmetic plus root review of basis-independence proof, scope and distractors. Revision diff will be read separately.'},indent=2)+'\n')
print('Exact checks passed')
