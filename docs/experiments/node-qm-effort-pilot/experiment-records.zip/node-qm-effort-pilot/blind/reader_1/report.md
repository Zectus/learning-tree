# Independent lesson evaluation

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding and cognitive load | Worked reasoning and transfer | Active learning | Mathematical correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.2 | 9.4 | 9.4 | 9.2 | 10.0 | 9.44 |
| B | 9.3 | 9.4 | 9.5 | 9.2 | 10.0 | 9.48 |
| C | 9.5 | 9.5 | 9.6 | 9.4 | 10.0 | 9.60 |
| D | 9.6 | 9.5 | 9.7 | 9.4 | 10.0 | 9.64 |

**Ranking:** D > C > B > A. **Confidence:** medium-high. The top pair are close, as are A and B; the ordering reflects small teaching advantages rather than major quality gaps.

## Evidence and tradeoffs

**Lesson A** starts with a useful local-measurement question and quickly motivates why matching computational-basis probabilities is insufficient. Its strongest feature is the sequence from the probability argument to the index rule, then to preserved local predictions and basis independence. The worked χ example shows that local coherence can survive tracing out the environment, and the plus-basis calculation checks that result against a joint calculation. Its main weakness is that the worked off-diagonal entry is abbreviated as “1/3 + 0,” without identifying the amplitude products as explicitly as B does. The transition into dense index notation is also brisk for a first-time reader, though the surrounding explanations make it manageable. The four main questions offer useful calculation and conceptual checks; the bonus problems extend transfer.

**Lesson B** retains A’s strengths and improves one worked step: it spells out ρ_A’s off-diagonal entry as (c_{00}c_{10}^*+c_{01}c_{11}^*). That makes the shared-environment-index rule easier to apply to complex amplitudes. Its strongest feature is this direct connection between the general formula and a concrete calculation. Its most important weakness is the same brisk move into index-heavy derivation, and it does less than C and D to develop the basis-independence argument in a separate concrete representation. The difference from A is slight; B is a modestly clearer version of essentially the same lesson.

**Lesson C** has a strong derivation organized around the local probability being preserved. It explicitly compares the joint trace with \operatorname{tr}_A(RP), then derives the partial-trace entries; its sample density matrix and the (y_+) probability calculation provide useful practice with complex phases. Its strongest feature is the clear bridge from the probability rule to the general construction. Its basis-independence section proves the claim through completeness and rank-one terms, while D adds a more tangible account of the partial-inner-product operation and its role in forming the local vectors. That makes C’s basis argument more abstract than its other sections. The five main questions cover a good range, including rank-greater-than-one outcomes, basis contributions, purity, and local-versus-joint predictions.

**Lesson D** is the strongest overall. It keeps C’s probability-based derivation and adds explicit interpretation of the partial-inner-product maps: one example shows how an environment bra acts on a product ket, and the tensor-term rule then clarifies why environment labels decide which terms survive. Its plus/minus-basis calculation shows the cancellation in the actual opening state, including why the unnormalized vectors’ original weights must be retained. The later comparison with a genuine joint mixture also makes the “reduction is not collapse” distinction especially concrete by calculating a joint outcome that separates the two preparations. Its strongest feature is this layered explanation, connecting the abstract rule to both a calculation and its physical scope. Its main weakness is length and repetition: the basis section revisits material already established in the index and tensor-term derivations, so an engaged reader must integrate several forms of the same rule. The examples and sectioning keep that load reasonable, and the extra material gives especially strong transfer.

I found no substantive mathematical or scope errors in the four lessons. All correctly preserve local probabilities, retain local off-diagonal terms when environment labels match, show invariance under a change of discarded basis, and distinguish reduction from a physical change to the joint state. The score differences therefore reflect explanation and practice design, not correctness failures.

A learner who prefers a compact, index-first treatment may favor C over D, since C proves basis independence with less repetition. A learner who benefits from seeing maps applied to kets and a second concrete comparison will likely learn more from D. For the stated actively engaged first-time reader, D’s extra representations are worth the additional length.
