# Independent lesson evaluation

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding, pacing, and cognitive load | Worked reasoning and transfer | Active learning and feedback | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.5 | 9.2 | 9.4 | 8.7 | 9.8 | 9.3 |
| D | 9.5 | 9.2 | 9.4 | 8.7 | 9.8 | 9.3 |
| B | 9.5 | 9.3 | 9.1 | 8.7 | 9.8 | 9.3 |
| C | 9.5 | 9.3 | 9.1 | 8.7 | 9.8 | 9.3 |

**Ranking:** A = B = C = D (tie). **Confidence:** Moderate. The lessons are all strong and accurate, and the score differences are too small to justify a strict rank. A and D offer a more concrete matrix-level demonstration; B and C are somewhat lighter to follow. Those tradeoffs depend on the learner.

## Evidence and decisive tradeoffs

All four begin with the same useful motivation: a local density operator must predict measurements beyond the computational basis. They derive the answer from local outcome probabilities and then use the identity-on-B trace to obtain the component rule. Each explicitly explains that the same discarded-system index is summed, distinguishes a partial trace from a full trace, and establishes that the resulting operator preserves all local projector probabilities. The lessons also meet the central conceptual goals: invariance under a change of discarded basis, mixed local state within a pure joint state, and no physical collapse or deletion of the joint state.

A and D have the strongest worked transfer example. In Section 3 they construct the full 4×4 density matrix for a state with a relative phase, trace matching B indices, and retain a nonzero local off-diagonal entry. They then verify a y+ outcome probability both from the reduced operator and from the joint state. A introduces the partial-inner-product maps before the basis-independence proof; D places that explanation in Section 4, where it directly supports the proof. Both sequences are sound. Their most important weakness is density: the detailed component proof, matrix expansion, map notation, positivity check, and several adjacent examples ask the reader to hold many indices and representations in mind. This is a pacing concern, not a mathematical error.

B and C have the smoothest reading flow. Their Section 2 walks from the outcome probability to the component rule, then explains the bra-ket sandwich and pure-state amplitude shortcut. The example (|00>+|10>+|11>)/√3 makes local coherence visible: the coherence between |00> and |10> survives because the environment label agrees. The later plus-basis measurement cross-check makes the local probability identity concrete. The basis-change proof uses unitarity and is followed by a cancellation example. The most important weakness relative to A and D is that the worked calculation does not explicitly build and reduce the full joint density matrix, so a learner who needs practice moving from a general matrix to its reduced matrix gets less direct support. This is a limited transfer opportunity, not a scope or correctness problem.

Every lesson has meaningful practice: questions ask learners to calculate reductions, evaluate probabilities, track basis changes, compare local and joint purity, and distinguish a pure entangled state from a mixture with the same local state. For instance, the questions about a joint plus-plus outcome test whether the reader has mistaken reduction for replacement of the joint state. The main weakness shared by all four is that the questions are multiple choice without visible worked feedback in the lesson text. A learner can check an answer, but a wrong choice does not itself explain the misconception. This limits the feedback score; the questions themselves are relevant and achievable.

I found no substantive mathematical or scope error. The displayed reductions, probabilities, purity values, and basis-invariance arguments are consistent. Minor polish could reduce the amount of index notation near the derivation and add short explanations for common wrong answers. These are refinements to already effective instruction, not defects that undermine the learning goal.

A learner who values detailed matrix practice may prefer A or D. A learner who benefits from a lighter sequence may prefer B or C. Since the core explanations and exercises are closely matched, that preference does not create a meaningful overall winner.
