# Independent evaluation

## Scores

| Lesson | Conceptual clarity | Scaffolding | Worked reasoning and transfer | Active learning | Correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 9.1 | 9.2 | 9.2 | 10.0 | 9.38 |
| B | 9.4 | 9.3 | 9.5 | 9.5 | 10.0 | 9.54 |
| C | 9.4 | 9.5 | 9.4 | 9.5 | 10.0 | 9.56 |
| D | 9.4 | 9.4 | 9.5 | 9.2 | 10.0 | 9.50 |

Ranking: **C > B > D > A**. Confidence: **moderate**; the lessons are close, and several share most of their material.

## Evidence and tradeoffs

**C** ranks first by a small margin. Its strongest feature is the order in which it builds the calculation: Section 2 derives the index rule from local outcome probabilities, then Section 3 explains the partial-inner-product maps and applies the rule to both a pure-state amplitude calculation and a complex-valued worked example. That sequence gives an engaged beginner a route from purpose to mechanics to use. The five main questions include a higher-rank local projector and a comparison of local versus joint predictions, so practice reaches beyond entry-by-entry computation. The most important weakness is that the index derivation and invariance proof are algebraically dense; a reader may need to pause and work through the sums. No substantive error found.

**B** is a close second. Its strongest feature is the fully worked complex example: it writes the joint density matrix, identifies the entries summed for each reduced entry, and checks a local probability by both the reduced and joint calculations. Section 4 also makes the basis-invariance claim concrete by showing the two unnormalized vectors and their outer products. Its five main questions provide good transfer, including a higher-rank projector. Its main weakness is sequencing: it gives the pure-state amplitude shortcut and full matrix example before explaining the tensor-term/partial-inner-product rule in Section 3, which can make the mechanics feel like a second explanation arriving late. The mathematics is correct.

**D** edges A because it makes the operator action more readable. Its strongest feature is the explicit line showing how (I_A\otimes\langle b|\) acts on product kets, followed by the worked off-diagonal entry (c_{00}c_{10}^*+c_{01}c_{11}^*); these details help prevent common index and conjugation mistakes. It also includes a concrete change-of-basis calculation. Its main weakness is a somewhat long, symbol-heavy middle section, and it offers four main questions compared with B and C's five. No substantive correctness issue found.

**A** shares D's clear opening and the derivation from local probabilities. Its strongest feature is the direct link between the partial trace and preserving every local probability, followed by a concrete (\lvert+\rangle) verification. Its most important weakness, relative to D, is that some operational notation receives less unpacking: the tensor sandwich is stated without D's explicit action-on-a-ket example, and the worked coherence entry is abbreviated as (1/3+0). That leaves slightly more interpretive work for a first-time learner. Its section on basis independence is nevertheless especially explicit, using the unitary coefficients. No substantive error found.

All four lessons correctly distinguish a reduced description from a physical measurement or collapse, show how a pure joint state can have a mixed reduction, and preserve the distinction between local predictions and joint correlations. I found no substantive mathematical or scope error. Their weaknesses are teaching choices of degree and sequencing, not failures to teach a required idea.

A learner who prefers a compact worked matrix calculation may choose B; one who benefits from seeing each operator's action before applying the formula may prefer C or D. A learner who values a particularly explicit unitary-index proof may prefer A. Those preferences could outweigh the small score gaps.
