# Evaluation: Partial Trace and Reduced Density Operators

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding and pacing | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.5 | 9.2 | 9.4 | 9.3 | 10.0 | 9.48 |
| B | 9.5 | 9.2 | 9.4 | 9.3 | 10.0 | 9.48 |
| C | 9.4 | 9.0 | 9.4 | 9.3 | 10.0 | 9.42 |
| D | 9.4 | 9.0 | 9.4 | 9.3 | 10.0 | 9.42 |

**Ranking:** A = B > C = D. **Confidence:** moderately high. The score gaps are small: all four lessons teach the central operation correctly and address the required scope.

## Evidence and tradeoffs

**A and B — strongest feature:** They build a clear bridge from local predictions to the partial-trace rule. The opening state first motivates a reduced description using an arbitrary local outcome, and Section 2 derives the index formula by expanding the probability for (P\otimes I_B). The “chi” example then shows why a local off-diagonal entry survives when the environment labels match; Section 3 checks the prediction in a superposition basis by both the reduced-matrix and joint-state calculations. The later unitary-basis argument, purity comparison, and singlet-versus-mixture question reinforce that reduction preserves local predictions without collapsing or replacing the joint state. The questions are varied and generally require applying the rule, phase handling, basis invariance, or local-versus-joint reasoning.

Their main weakness is pacing: Section 2 introduces the general trace expansion, sandwich expression, tensor-term rule, pure-state formula, and a worked example in one long stretch, followed by a positivity proof. A careful learner can follow it, but the symbolic load is substantial before the first embedded question. This is a manageable teaching cost rather than a correctness or scope problem. A and B are materially the same lesson in this packet, so they receive the same scores.

**C and D — strongest feature:** They make the index bookkeeping and transfer especially explicit. The derivation defines all four indices and shows how the identity on (B) forces the environment labels to match; Section 3 then works a complex-amplitude example from the full (4\times4) joint matrix and verifies a (y_+) probability two ways. The alternate-basis calculation and later comparison of a pure entangled preparation with a mixture make the lost joint information concrete. The questions include higher-dimensional environments, non-rank-one projectors, basis-dependent contributions, and indistinguishable local states, giving good practice beyond the opening qubit case.

Their main weakness is the heavier concentration of formal material. The full joint matrix, index derivation, block-trace observation, probability check, and separate basis-invariance proof demand sustained attention; Section 4 revisits some operator-sandwich material already used in Section 3. That repetition supports the argument, but the pacing is slightly less forgiving for this first-time reader than A/B. The exercises remain achievable, and the extra explicit matrix work may be a benefit to readers who prefer concrete component calculations. C and D are very close in this packet and receive equal scores.

All four are mathematically accurate in the examples, formulas, and keyed questions reviewed. None has a substantive scope error: each treats finite systems, verifies local probabilities, establishes basis independence for the discarded system, explains local mixedness in a pure entangled state, and avoids interpreting reduction as physical collapse. Minor differences in notation and ordering do not affect learning. Readers who prefer direct amplitudes and a gentler progression may favor A/B; readers who learn best from explicit joint matrices and index-level calculations may favor C/D.
