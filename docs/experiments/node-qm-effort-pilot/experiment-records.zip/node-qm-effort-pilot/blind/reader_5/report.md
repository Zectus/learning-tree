# Evaluation: Partial Trace and Reduced Density Operators

## Scores

| Lesson | Conceptual clarity | Scaffolding and pacing | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.5 | 9.3 | 9.5 | 9.4 | 10.0 | 9.54 |
| B | 9.5 | 9.1 | 9.4 | 9.4 | 10.0 | 9.48 |
| C | 9.6 | 9.6 | 9.6 | 9.4 | 10.0 | 9.64 |
| D | 9.5 | 9.3 | 9.5 | 9.4 | 10.0 | 9.54 |

## Ranking and confidence

**C > A = D > B.** Confidence: **moderate**. The top three are exceptionally close, and a reader who prefers a more compact path may reasonably choose D or A over C.

## Evidence and decisive tradeoffs

All four lessons build from the same useful motivating case: the state with amplitudes \(\sqrt3/2\) and \(1/2\), and the question of how to predict arbitrary measurements on (A) when (B) is inaccessible. They correctly point out that computational-basis probabilities alone do not determine a general density matrix, then use a superposition outcome to motivate retaining coherences. Each derives the component rule by expanding the probability for (P\otimes I_B\), and each explains why the discarded-system index is matched and summed. The lessons also correctly establish local prediction equivalence, explain basis independence, and distinguish a mixed reduction from collapse or replacement of the joint state.

**C** ranks first because it makes the calculation steps easiest to follow for this first-time learner. In the worked state \((|00\rangle+|10\rangle+|11\rangle)/\sqrt3\), it writes the off-diagonal entry as \(c_{00}c_{10}^*+c_{01}c_{11}^*=1/3+0\), directly showing which amplitudes pair and why coherence survives. It also spells out what the partial inner-product map does to a basis ket before giving the outer-product rule. Those small explanations bridge notation and procedure particularly well. Its basis-change proof and worked plus/minus cancellation then give both a general argument and a concrete check. The main weakness is a dense stretch of formal derivation and properties (trace identity, positivity, and basis invariance); even with its helpful explanations, this is a lot of symbols in succession. This is a manageable load given the stated background, not a substantive flaw.

**A** is nearly tied with C. Its strongest feature is the especially explicit derivation from local probabilities, including the index expansion and an explanation that the partial trace returns a matrix rather than the scalar full trace. The calculation from a full (4\times4) matrix to \(\rho_A\), followed by checking a complex-basis probability both locally and jointly, gives strong transfer practice. Its basis-independence section is also unusually concrete: it proves the claim term by term and shows the cancellation for the opening state. The most important weakness is density: it places the full matrix example, basis-map formalism, proof of basis independence, state-purity comparison, and joint-state caveat in a long run. The active questions provide useful breaks, and no mathematical error or misleading physical claim appears.

**D** shares A's strengths and is a very strong, accurate lesson. The worked local probability and full matrix formula support practical use, while its final comparison of the pure joint state with a statistical mixture makes the limit of local information concrete: the same reduction gives a different probability for a joint projector. That is an especially useful transfer lesson. Compared with C, it gives less step-by-step unpacking at key points: its example reports the off-diagonal contribution as \(1/3+0\) without displaying the amplitude products, and its equivalent partial-trace expression is not illustrated on a basis ket. This is a modest scaffolding gap, though its concise phrasing may suit a reader who wants fewer intermediate steps. The lesson remains correct and coherent.

**B** teaches the same central ideas accurately and offers strong examples, including the contrast between local and joint predictions. Its strongest feature is the accessible tensor-term rule—an environment label mismatch removes a term while a local off-diagonal term can survive—which is useful for calculations and transfer. Its main weakness is pacing: Section 3 revisits the bra-ket map and tensor-term rule immediately after Section 2 has already derived the index recipe and local-probability identity, before proceeding to the pure-state formula and matrix example. The return is useful, but the transition can feel repetitive rather than like a clearly staged next step. C's more explicit amplitude-level example also makes that later calculation easier to imitate. These are small teaching differences; no substantive correctness issue was found.

The active questions across all four lessons are varied and relevant: they ask for reduced matrices with complex amplitudes, probabilities for nontrivial projectors, contributions in a changed environment basis, subsystem purities, and what local reductions do or do not determine about joint outcomes. The bonus problems extend practice to retaining the other subsystem and invariance under a unitary on the discarded subsystem. This is meaningful practice rather than question volume alone. I found no substantive mathematical errors in the worked calculations or answer keys. In particular, the equations consistently preserve local coherences when the environment labels match and avoid interpreting reduction as a physical measurement.

A different learner preference could change the choice among the leading lessons. Someone who benefits from explicit intermediate algebra is best served by C; a reader who prefers a compact exposition may favor D, while A provides a particularly detailed basis-invariance argument. B remains a sound choice for someone who finds the operator-term rule especially helpful, though its repeated introduction slightly weakens the flow.
