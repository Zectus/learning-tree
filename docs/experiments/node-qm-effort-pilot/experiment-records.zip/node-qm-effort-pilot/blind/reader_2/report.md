# Evaluation: Partial trace and reduced density operators

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding, pacing, and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.3 | 9.0 | 9.3 | 9.2 | 10.0 | 9.36 |
| B | 9.5 | 9.4 | 9.6 | 9.3 | 10.0 | 9.56 |
| C | 9.5 | 9.5 | 9.6 | 9.3 | 10.0 | 9.58 |
| D | 9.3 | 9.0 | 9.3 | 9.2 | 10.0 | 9.36 |

**Ranking:** C, B, A and D (tie). **Confidence:** High that A and D tie; moderate that C has a small edge over B.

## Evidence and tradeoffs

**Lesson C** ranks first by a narrow margin. Its strongest feature is the way it links the rule to both calculation and interpretation: it derives the reduced entries by matching the local probability formula, computes a complex off-diagonal entry in a worked state, and then checks a `|y_+>` probability using both the reduced and joint descriptions. In Section 4, it revisits the partial-inner-product maps and outer-product rule immediately before proving basis independence, which gives the reader a concrete footing for the completeness argument. The weakness is density: the derivation still moves through several index conventions and trace identities in quick succession, and the multiple-choice questions do not themselves provide worked answer feedback. These are manageable demands for the stated learner, not mathematical errors.

**Lesson B** is nearly tied. It has the most explicit setup of dimensions and index roles, derives the matrix entries by comparing two trace expressions, and makes useful novice-facing points such as why there is no division by the dimension of B. Its worked example gives the full joint matrix and extracts a complex reduced matrix entry, then checks a non-computational-basis probability. These details make it especially useful for transferring the recipe to arbitrary finite dimensions. Its main weakness relative to C is that the basis-independence section starts directly with the completeness proof and relies on the termwise outer-product rule from the previous section; C briefly refreshes that rule there, making this conceptual transition a little gentler. B's extra index detail is useful but also contributes to its high information load.

**Lessons A and D** are identical in the supplied packet and therefore tie. Their strongest feature is a clear conceptual arc: the opening example motivates keeping local probabilities, the index calculation gives the partial-trace rule, a `|+>` example demonstrates preserved interference, and the later sections separate basis choice from physical measurement and local mixedness from joint purity. The concrete comparison between the singlet and a mixture also makes clear why the reduction does not replace the joint state. The main weakness is that the exposition compresses the general index derivation and the proof that the result is a valid density operator into one dense section; an engaged beginner may need to pause over the primed indices and the positivity argument. This is mostly a pacing issue. The worked examples and questions remain accurate and useful.

All four lessons accurately handle complex conjugation, retained versus discarded indices, trace normalization, and the distinction between a calculation and physical collapse. Each offers achievable questions on complex off-diagonal entries, probabilities, basis changes, and mixedness; their answer keys are consistent with the calculations. No substantive correctness or scope error stood out. The difference between C and B is small, while A and D are the same lesson rather than meaningfully different alternatives.

A learner who prefers a compact through-line might choose A/D; one who likes explicit index bookkeeping and broad finite-dimensional examples might prefer B. A learner who benefits from a brief recap at the point of a new conceptual transition may prefer C.
