# Evaluation: Partial Trace and Reduced Density Operators

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding and cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.3 | 9.2 | 9.4 | 9.2 | 9.8 | 9.38 |
| B | 9.3 | 9.1 | 9.3 | 9.2 | 9.8 | 9.34 |
| C | 9.5 | 9.3 | 9.4 | 9.3 | 9.8 | 9.46 |
| D | 9.5 | 9.3 | 9.5 | 9.6 | 9.8 | 9.54 |

**Ranking:** D > C > A > B. **Confidence: medium-high.** The lessons are all accurate and teach the central procedure well, so the gaps reflect differences in sequencing and the final conceptual payoff rather than any serious defect.

## Evidence and tradeoffs

**D** is the strongest choice for this learner. It motivates reduction through the question of whether one must carry the full two-qubit state for local predictions, then derives the index rule from the trace probability identity. The worked state \(|\chi\rangle\) makes surviving local coherence visible, and Section 3 independently checks a superposition-basis probability against the joint calculation. Its distinctive strength is the later comparison between the pure entangled state and the actual mixture \(\tau_{AB}\): both reduce to the same local operator, but the joint projector \(Q\) yields probabilities 1 and 5/8. Question 5 reinforces that reduction preserves local predictions while losing information needed for joint ones. The main cost is a dense sequence of derivations and abstractions; the lesson asks the reader to hold several index conventions and trace identities in mind. That is a manageable load for an engaged reader, not a correctness problem.

**C** is close behind and shares D's clear opening, entry-by-entry calculation, probability check, and careful explanation that the discarded basis is a calculation choice. Its strongest feature is the compact proof of basis independence using unitary completeness, paired with the \(v_0,v_1\) and \(w_\pm\) example. Its main weakness relative to D is that it stops short of D's explicit opening-state comparison with a distinct joint mixture and the associated local-versus-joint measurement question. C does state that the joint state is not replaced and gives a Bell-state replacement question, so this is a smaller teaching opportunity than a misconception left unaddressed.

**A** gives a very complete route from local outcome probabilities to the partial-trace formula. Its especially useful feature is the sequence from the sandwich-map interpretation and tensor-product rule to an explicit joint matrix and reduced matrix; learners get both termwise and index-based ways to calculate. The worked \(y_+\) probability is also checked from both the reduced and joint descriptions. The main weakness is pacing: the explanations of the sandwich maps and rank-one tensor rule arrive in Section 3 and are substantially revisited in Section 4, making the lesson feel more repetitive and longer before the basis-independence point settles. The mathematics and question set remain strong.

**B** also has a strong probability-based derivation, accurate calculations, and useful active questions, including the weighted, unnormalized contributions in the alternate basis. Its best feature is that it connects the entry formula to a concrete worked matrix and later to invariance under a basis change. Compared with A, it moves the sandwich-map and tensor-term explanation later, into the basis-choice section; this makes the transition from its pure-state component formula to the matrix calculation slightly less scaffolded. That sequencing issue is modest, and its content is otherwise very close to A.

There are no material mathematical errors or scope violations in these four lessons. The displayed partial-trace formulas preserve the retained indices, sum the matching discarded indices, and support the stated local probability identities. The discussions also consistently distinguish tracing out on paper from a physical measurement or collapse. All four use substantial algebra, but their worked examples and answer opportunities make the reasoning achievable for the stated reader. A reader who prefers shorter exposition may favor C; a reader who values repeated term-by-term demonstrations may prefer A. For the specified actively engaged learner, D's extra local-versus-joint distinction is the most useful difference.
