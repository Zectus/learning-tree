# Evaluation of the four lessons

## Scores

| Lesson | Conceptual clarity | Scaffolding | Worked reasoning and transfer | Active learning | Correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.6 | 9.4 | 9.7 | 9.6 | 10.0 | **9.66** |
| B | 9.6 | 9.7 | 9.5 | 9.4 | 10.0 | **9.64** |
| C | 9.7 | 9.5 | 9.6 | 9.4 | 10.0 | **9.64** |
| D | 9.6 | 9.3 | 9.6 | 9.6 | 10.0 | **9.62** |

Ranking: **A > B = C > D**. Confidence: **medium**; the lessons are close, with no material correctness or scope failures.

## Evidence and tradeoffs

**A** is the strongest overall for this learner. Its key strength is a particularly complete path from the local-probability motivation to the index rule and then to computation. The state \(\chi\) is carried through a full joint matrix, reduced entry by entry, and used to verify a complex-basis probability against the joint calculation. Its basis-independence section also gives both the tensor outer-product rule and an explicit \(\lvert+\rangle,\lvert-\rangle\) cancellation, including the useful warning not to normalize the partial-inner-product vectors. Questions range from a three-dimensional environment calculation to mixedness, joint-versus-local predictions, and basis changes. The main weakness is density: the completeness proof, term rule, and explicit cancellation in Section 4 revisit the same invariance claim, adding some load after an already substantial index derivation. This is a modest pacing cost, not a conceptual gap.

**B** offers the gentlest pacing. It introduces the goal in plain language, defines the partial trace through the arbitrary local-projector probability, and follows with a compact entry formula and an example where local coherence survives because the environment labels match. Its strongest feature is the clear distinction between what the reduced state preserves and what it omits, reinforced by the joint-state comparison in Question 4. It also explicitly explains how the partial-inner-product sandwich acts on a product ket and distinguishes local mixedness from evidence of entanglement. The principal weakness is that its basis-independence section is more compressed than A's: it derives unitary cancellation and gives a vector example, but the learner gets fewer concrete term-by-term checks, and the core set has less transfer variety. The bonus items help, so this is a small difference in practice opportunity rather than a missing concept.

**C** is especially clear about notation and what the index operation does. It explains that the primes are separate labels, spells out how \(I_A\otimes\langle b\rvert\) acts, and states directly that the reduced matrix remains expressed in the chosen basis of A while the discarded-system basis disappears from the sum. Its explanation that local mixedness alone does not prove entanglement is a valuable precision point. The main weakness is a slight jump in the basis-invariance argument: after the unitary identity, its concrete example only displays the cancellation symbolically, without calculating the outer products as A does. As in B, the core practice set has four questions rather than A/D's five, although its questions and bonuses are useful. This may suit a learner who values explicit notation explanations and a cleaner presentation over a longer worked illustration.

**D** has a strong derivation from local probabilities and gives a useful outer-product rule before its full matrix calculation. It also includes the same broad practice range and explicit (y_+) probability check as A. Its strongest feature is this direct bridge between the general trace definition and a concrete entry-by-entry calculation. Its main weakness is sequence and repetition: Section 3 first explains the term rule and then restates the pure-state coefficient formula before the matrix example; the later invariance proof repeats the term logic in a shorter form. Compared with A, it does not provide the same general completeness argument over arbitrary discarded bases, while retaining much of the same length. Nothing is incorrect; this is a small organizational disadvantage.

All four lessons correctly use \(P\otimes I_B\), sum over a shared discarded index, preserve local coherences when environment labels match, and distinguish reduction from collapse or replacing the joint state. Their displayed calculations and answer keys are consistent. A reader who prefers a brisker, less elaborated treatment may favor B; one who wants explicit notation coaching may favor C. The overall differences are small, and that preference could change the choice among the top three.
