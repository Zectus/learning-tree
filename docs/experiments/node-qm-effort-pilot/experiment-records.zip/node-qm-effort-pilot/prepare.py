from pathlib import Path
import hashlib,json,shutil,uuid,difflib
r=Path(__file__).parent;m=json.loads((r/'manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for c in ['xhigh_original','xhigh_review']:
 n=Path('/workspace/lesson-author-913e87a6c1' if c=='xhigh_original' else '/workspace/lesson-author-5b967f21a9');d=r/'writers'/c;d.mkdir(parents=True,exist_ok=True);shutil.copyfile(n/'lesson.txt',d/'lesson.txt');m['authors'][c]['lesson_sha256']=sha(d/'lesson.txt')
 if c=='xhigh_review':
  for f in ['review.md','revision-notes.md']:shutil.copyfile(n/f,d/f)
assert sha(Path('/workspace/lesson-author-5b967f21a9/completed.txt'))==m['authors']['xhigh_original']['lesson_sha256']
(r/'xhigh-review.diff').write_text(''.join(difflib.unified_diff((r/'writers/xhigh_original/lesson.txt').read_text().splitlines(True),(r/'writers/xhigh_review/lesson.txt').read_text().splitlines(True),fromfile='original',tofile='self-review')))
n=Path('/workspace')/('lesson-eval-'+uuid.uuid4().hex[:10]);n.mkdir();m['neutral_root']=str(n)
for reader,order in m['orders'].items():
 d=n/reader;d.mkdir();packet=(r/'reader-context.txt').read_text()
 for label,c in zip('ABCD',order):packet+='\n\nLESSON '+label+'\n\n'+(r/'writers'/c/'lesson.txt').read_text()
 (d/'packet.txt').write_text(packet);shutil.copyfile(r/'grading-instructions.txt',d/'instructions.txt');m['packet_sha256'][reader]=sha(d/'packet.txt')
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(n)
