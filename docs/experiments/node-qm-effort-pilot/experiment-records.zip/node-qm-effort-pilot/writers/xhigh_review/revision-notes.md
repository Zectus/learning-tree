# Revision notes

Accepted: move the partial-inner-product maps, operator-sandwich formula, and tensor-term rule from the start of Section 3 to Section 4, immediately before the basis-independence argument. Section 3 now proceeds directly from the entry rule to the coefficient formula, worked matrix, and first application question. The moved block now states why this representation helps, and “reverse map” becomes “map in the other direction.”

Not adopted: additional questions, graphs, or expanded proofs. The existing explanations and transfer questions already cover the scope; no mathematical correction or broader rewrite was warranted.

Actual changes are limited to that relocation and the two prose edits. All equations, worked values, question blocks, answer keys, and structural markup are preserved. Checked every worked calculation and all seven keys independently; verified question markup and unchanged mathematical content. The supplied completed.txt remains byte-for-byte unchanged.
