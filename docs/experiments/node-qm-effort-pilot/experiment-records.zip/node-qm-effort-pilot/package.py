from pathlib import Path
from collections import Counter
import hashlib,json,shutil,zipfile
r=Path(__file__).parent;m=json.loads((r/'manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for c,q in m['authors'].items():
 assert sha(r/'writers'/c/'lesson.txt')==q['lesson_sha256']
 if q.get('reused_from'):assert sha(Path(q['reused_from']))==q['lesson_sha256']
assert sha(r/'original-prompt.txt')=='5309500d0c90745e7e666f2a10ed38a6b76c94783c29cf09317e13486e861b6c'
assert sha(Path('/workspace/lesson-author-5b967f21a9/completed.txt'))==m['authors']['xhigh_original']['lesson_sha256']
for reader,order in m['orders'].items():
 d=Path(m['neutral_root'])/reader;assert sha(d/'packet.txt')==m['packet_sha256'][reader]
 for f in ['report.md','scores.json']:assert (d/f).read_bytes()==(r/'blind'/reader/f).read_bytes()
for c in m['conditions']:assert Counter(order.index(c) for order in m['orders'].values())=={0:2,1:2,2:2,3:2}
struct=json.loads((r/'structural-audit.json').read_text());assert all(q['complete'] and q['questionsValid'] for q in struct.values())
log=json.loads((r/'launch-log.json').read_text());assert all(q['status']=='completed' for q in log['authors']+log['graders'])
assert all(q['spawn_arguments']['model']=='gpt-6.1-sol' and q['spawn_arguments']['reasoning_effort']=='xhigh' for q in log['authors'])
assert sha(Path('/workspace/learning-tree/js/learn/node-prompt.js'))=='f629442764c4a507f6a0dab6b1ea5551982ad1b9c52076d34746af9f21765ea8'
(r/'completion-checks.json').write_text(json.dumps({'two_low_lessons_reused_byte_identically':True,'both_new_sol_agents_6_1_xhigh':True,'same_original_prompt':True,'same_self_review_wrapper_except_paths':True,'fresh_revision_context_matches_prior_process':True,'eight_fresh_blind_graders_completed':True,'orders_balanced':True,'all_structure_checks_pass':True,'all_hashes_valid':True,'production_prompt_unchanged':True},indent=2)+'\n')
for c in m['conditions']:shutil.copyfile(r/'writers'/c/'lesson.txt',r/(c+'.txt'))
out=r/'experiment-records.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(r.rglob('*')):
  if f.is_file() and f.suffix!='.zip' and f.name!='archive.sha256':z.write(f,'node-qm-effort-pilot/'+str(f.relative_to(r)))
 for f in sorted(Path(m['neutral_root']).rglob('*')):
  if f.is_file():z.write(f,'node-qm-effort-pilot/grading-packets/'+str(f.relative_to(m['neutral_root'])))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
(r/'archive.sha256').write_text(sha(out)+'  experiment-records.zip\n')
d=Path('/workspace/learning-tree/docs/experiments/node-qm-effort-pilot');d.mkdir(parents=True,exist_ok=True)
for f in ['README.md','protocol.md','aggregate.json','content-audit.md','completion-checks.json','original-prompt.txt','low_original.txt','low_review.txt','xhigh_original.txt','xhigh_review.txt','experiment-records.zip','archive.sha256']:shutil.copyfile(r/f,d/f)
print(d)
