from pathlib import Path
from collections import Counter
import itertools,hashlib,json,shutil,statistics
r=Path(__file__).parent;m=json.loads((r/'manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ks=['conceptual_clarity','scaffolding','worked_reasoning_transfer','active_learning','correctness']
samples={a:[] for a in m['authors']};panels={};pairs={a+' vs '+b:{a:0,b:0,'ties':0} for a,b in itertools.combinations(m['conditions'],2)};deltas=[];first=Counter({c:0 for c in m['conditions']})
for reader,order in m['orders'].items():
 n=Path(m['neutral_root'])/reader;assert sha(n/'packet.txt')==m['packet_sha256'][reader]
 d=json.loads((n/'scores.json').read_text());assert sorted(x for g in d['ranking'] for x in g)==list('ABCD')
 dest=r/'blind'/reader;dest.mkdir(parents=True,exist_ok=True)
 for f in ['report.md','scores.json']:shutil.copyfile(n/f,dest/f)
 scores={};rank={}
 for i,g in enumerate(d['ranking']):
  for label in g:rank[order['ABCD'.index(label)]]=i
 for label,c in zip('ABCD',order):
  q=d['scores'][label];assert all(isinstance(q[k],(int,float)) and 0<=q[k]<=10 for k in ks)
  mean=statistics.mean(q[k] for k in ks)
  if abs(mean-q['overall'])>1e-8:deltas.append({'reader':reader,'label':label,'reported':q['overall'],'computed':mean})
  scores[c]=mean;samples[c].append({'reader':reader,'position':'ABCD'.index(label),'reported_overall':q['overall'],**q,'overall':mean})
 for c in rank:
  if rank[c]==0:first[c]+=1
 for a,b in itertools.combinations(m['conditions'],2):pairs[a+' vs '+b]['ties' if rank[a]==rank[b] else a if rank[a]<rank[b] else b]+=1
 panels[reader]={'order':order,'scores':scores,'ranking':[[order['ABCD'.index(x)] for x in g] for g in d['ranking']],'confidence':d['confidence'],'decisive_tradeoff':d['decisive_tradeoff']}
means={}
for c,ss in samples.items():
 assert len(ss)==8 and Counter(s['position'] for s in ss)=={0:2,1:2,2:2,3:2};assert sha(r/'writers'/c/'lesson.txt')==m['authors'][c]['lesson_sha256']
 means[c]={k:statistics.mean(s[k] for s in ss) for k in ks+['overall']}
out={'condition_means':means,'pairwise_preferences':pairs,'first_place_appearances_including_ties':dict(first),'panels':panels,'samples':samples,'reported_overall_differences':deltas}
(r/'aggregate.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['panels','samples']},indent=2))
