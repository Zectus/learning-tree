from pathlib import Path
import hashlib,json,shutil,zipfile
r=Path(__file__).parent;n=Path('/workspace/lesson-author-f872ca531d');app=Path('/workspace/learning-tree');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((r/'manifest.json').read_text());log=json.loads((r/'launch-log.json').read_text());process=json.loads((r/'process.json').read_text())
assert log['author']['first_turn_status']==log['author']['second_turn_status']=='completed'
assert sha(n/'limit_intuition.txt')==sha(r/'v1.txt')==log['v1_frozen_before_followup']['sha256']==process['original_lesson_sha256']
assert sha(r/'original-prompt.txt')==sha(n/'input.txt')==sha(Path('/workspace/node-critique-pilot/base-prompt.txt'))==m['input_sha256']
assert sha(r/'v2.txt')==sha(n/'v2.txt') and sha(r/'v2.txt')!=sha(r/'v1.txt')
assert process['critic_completion_status']=='completed' and process['additional_reviews']==0
args=process['critic_spawn_arguments'];assert args['model']=='gpt-6-luna' and args['fork_turns']=='none' and 'reasoning_effort' not in args
assert args['message']==(r/'critic-prompt.txt').read_text().rstrip('\n')
assert len(log['graders'])==4 and all(q['status']=='completed' for q in log['graders'])
assert log['author']['spawn_arguments']['model']=='gpt-6.1-sol' and log['author']['spawn_arguments']['reasoning_effort']=='low'
for reader,order in m['orders'].items():
 d=Path(m['neutral_root'])/reader;assert sha(d/'packet.txt')==m['packet_sha256'][reader]
 expected=(r/'reader-context.txt').read_text()
 for label,a in zip('AB',order):expected+='\n\nLESSON '+label+'\n\n'+(r/'writers'/a/'lesson.txt').read_text()
 assert expected==(d/'packet.txt').read_text()
 for f in ['report.md','scores.json']:assert (d/f).read_bytes()==(r/'blind'/reader/f).read_bytes()
struct=json.loads((r/'structural-audit.json').read_text());assert all(q['complete'] and q['questionsValid'] and all(not g['errors'] for g in q['graphs']) for q in struct.values())
assert sha(app/'js/learn/node-prompt.js')=='f629442764c4a507f6a0dab6b1ea5551982ad1b9c52076d34746af9f21765ea8'
agg=json.loads((r/'aggregate.json').read_text());assert agg['pairwise_preferences']['v2_wins']==4
checks={'author_model':'gpt-6.1-sol','author_effort':'low','first_delivery_completed_before_actual_second_message':True,'input_byte_identical_to_current_rendered_prompt':True,'original_delivery_immutable':True,'one_real_fresh_luna_critic_completed':True,'critic_message_matches_prepared_prompt':True,'four_fresh_blind_graders_completed':True,'orders_balanced_two_each':True,'all_packet_hashes_valid':True,'app_parser_and_graph_checks_pass':True,'underlying_question_keys_checked':5,'only_one_sentence_changed':True,'production_prompt_unchanged':True,'reported_mean_rounding_preserved':True}
(r/'completion-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
out=r/'experiment-records.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(r.rglob('*')):
  if p.is_file() and p.suffix!='.zip' and p.name!='archive.sha256':z.write(p,'node-delayed-critique-pilot/'+str(p.relative_to(r)))
 for p in sorted(Path(m['neutral_root']).rglob('*')):
  if p.is_file():z.write(p,'node-delayed-critique-pilot/grading-packets/'+str(p.relative_to(m['neutral_root'])))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
(r/'archive.sha256').write_text(sha(out)+'  experiment-records.zip\n')
docs=app/'docs/experiments/node-delayed-critique-pilot';docs.mkdir(parents=True,exist_ok=True)
for name in ['README.md','original-prompt.txt','second-message.txt','critic-prompt.txt','v1.txt','v2.txt','critique.md','revision-notes.md','aggregate.json','completion-checks.json','protocol.md','experiment-records.zip','archive.sha256']:shutil.copyfile(r/name,docs/name)
print(json.dumps({'all_checks_pass':True,'archive_bytes':out.stat().st_size,'report':str(docs/'README.md')},indent=2))
