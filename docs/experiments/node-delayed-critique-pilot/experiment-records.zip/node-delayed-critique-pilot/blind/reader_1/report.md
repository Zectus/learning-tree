# Evaluación de las lecciones

## Puntuaciones

| Criterio | Lección A | Lección B |
|---|---:|---:|
| Claridad conceptual y motivación | 9.5 | 9.7 |
| Andamiaje, ritmo y carga cognitiva | 9.5 | 9.6 |
| Razonamiento trabajado y transferencia | 9.5 | 9.6 |
| Preguntas de aprendizaje activo | 9.5 | 9.5 |
| Corrección y precisión matemática | 9.8 | 9.8 |
| **Promedio** | **9.56** | **9.64** |

**Clasificación:** B por encima de A. **Confianza:** alta, aunque la ventaja es pequeña; las lecciones son casi idénticas salvo una mejora puntual en la explicación inicial de B.

## Evaluación

Ambas lecciones enseñan bien la idea central para el lector previsto. Parten de una función con un hueco, separan los valores cercanos del valor en el punto y explican por qué una tabla orienta pero no demuestra el comportamiento de todas las entradas cercanas. La simplificación de \((x^2-4)/(x-2)\) a \(x+2\), válida solo para \(x\ne2\), sustenta la conclusión más allá de los seis valores tabulados. La igualdad \(f(x)-4=x-2\) relaciona directamente la distancia de la salida con la de la entrada.

B tiene una ventaja pequeña pero concreta en la sección 1: tras el ejemplo de una milésima, explicita que no hay una precisión final prefijada y que para cualquier distancia positiva solicitada basta tomar una entrada a menos de esa misma distancia de 2. Esto afina la intuición de «tan cerca como queramos» y hace más sólida la transición hacia la afirmación informal del límite. A sí dice que se puede pedir una cercanía aún mayor y conseguirla acercando más la entrada, de modo que transmite la idea; simplemente deja menos explícito el patrón general. No se introduce indebidamente la definición épsilon-delta.

El andamiaje de ambas es claro y apropiado: tabla, lectura de coordenadas, limitación visual del gráfico, álgebra, notación y distinción entre límite y valor asignado. El texto avisa que el trazo puede parecer continuo porque el formato no muestra un círculo abierto, y aclara que falta un solo punto. Esto resuelve una limitación de representación que podría confundir al principiante. La explicación de que (g(2)=9) mientras \(\lim_{x\to2}g(x)=4\), junto con el cambio aislado de (q(-1)), permite transferir la distinción a casos nuevos.

Las preguntas principales requieren aplicar las ideas, no repetir definiciones: simplificar otra función, detectar que una entrada cercana no obliga a que el resultado sea exactamente el límite, y razonar qué sucede al cambiar solo el valor en el punto. Las preguntas de práctica refuerzan dos matices importantes: una cantidad finita de datos no establece el comportamiento local general, y funciones con valores distintos en el punto pueden compartir límite. El feedback se limita a las respuestas indicadas; no hay explicaciones posteriores de por qué cada distractor falla. Eso es una oportunidad menor de mejora, pero no impide al lector activo razonar con el material previo.

La matemática es correcta en las dos lecciones. En particular, \(p(x)=(x^2-9)/(x-3)=x+3\) para (x\ne3), por lo que el límite es 6; y para (q(x)=2x+1\) cerca de (-1), el límite sigue siendo (-1) al cambiar el valor asignado en (-1). La formulación informal de la sección 2 incluye entradas permitidas suficientemente próximas y distintas de (a), y evita tratar una tabla como demostración. No encuentro errores sustantivos ni problemas de alcance.

El rasgo didáctico más fuerte de A es la cadena concreta que conecta tabla, hueco gráfico y diferencia algebraica; su debilidad más importante, relativa y menor, es que la explicación sobre precisión arbitraria en la sección 1 es algo menos explícita que la de B. La fortaleza principal de B es precisamente esa frase adicional, que articula con especial nitidez por qué el patrón funciona para cualquier grado de cercanía pedido; su debilidad principal es que comparte con A la ausencia de explicaciones de respuesta a las preguntas, una limitación de feedback menor. No hay una desventaja sustancial en ninguna.

La elección podría variar según la preferencia: quien agradezca la afirmación más explícita sobre cualquier precisión encontrará B algo más clara; para un lector satisfecho con una intuición informal basada en un ejemplo concreto, A ofrece esencialmente la misma experiencia con un poco menos de detalle en ese paso.
