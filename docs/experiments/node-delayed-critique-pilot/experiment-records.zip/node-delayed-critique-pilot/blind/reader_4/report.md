# Evaluación de las lecciones

## Puntuaciones

| Criterio | Peso | Lección A | Lección B |
|---|---:|---:|---:|
| Claridad conceptual y motivación | 20% | 9.5 | 9.3 |
| Andamiaje, ritmo y carga cognitiva | 20% | 9.4 | 9.2 |
| Razonamiento trabajado y transferencia | 20% | 9.5 | 9.3 |
| Preguntas de aprendizaje activo y oportunidades de respuesta | 20% | 8.8 | 8.8 |
| Corrección y precisión matemática | 20% | 9.8 | 9.7 |
| **Total igualmente ponderado** | **100%** | **9.4** | **9.3** |

## Ranking

1. **Lección A** — 9.4/10
2. **Lección B** — 9.3/10

**Confianza: alta.** Las lecciones son casi idénticas; la diferencia decisiva es una frase en la explicación inicial del límite.

## Evidencia y tradeoffs

Ambas lecciones construyen una explicación clara para un lector principiante. Parten de una función no definida en (x=2), ofrecen una tabla por ambos lados, explican cómo leer las coordenadas y avisan que el formato gráfico no puede dibujar un círculo abierto. La advertencia evita que el trazo aparentemente continuo se confunda con la gráfica completa. Después, la factorización muestra por qué la tabla sugiere (4), y el texto distingue explícitamente una tabla exploratoria de una justificación válida para todas las entradas permitidas cercanas. Esta secuencia conecta representación, cálculo y significado sin presuponer temas posteriores.

La principal ventaja de **A** está en la frase: «por pequeña que sea la distancia positiva que pidamos entre el resultado y (4), basta tomar una entrada cuya distancia a (2) sea menor que esa misma cantidad». Junto con (f(x)-4=x-2), esto explica con precisión cómo se logra una cercanía arbitrariamente exigente y por qué no hace falta usar (x=2). Es un detalle breve que da al lector una relación operativa más fuerte que la intuición de la tabla. **B** conserva el álgebra y el ejemplo de una milésima, y luego dice que podemos pedir «una cercanía aún mayor»; transmite la idea, pero no especifica tan claramente que cualquier tolerancia pedida se obtiene con una tolerancia igual para la entrada. Por eso A aventaja levemente a B en claridad, razonamiento transferible y precisión.

En ambas, las secciones siguientes consolidan distinciones importantes: la notación identifica (a) como entrada y (L) como destino; una aproximación como (f(1{,}99)=3{,}99) no es el límite; una función constante puede coincidir con su límite durante todo el acercamiento; y cambiar únicamente el valor en el punto no altera el comportamiento cercano. Los ejemplos de (g), (q), y el bonus de (u) y (v) hacen transferible la separación entre límite y valor asignado. Los cálculos son correctos: los límites de las preguntas son (6), (12) (sin poder inferir el valor exacto en (7{,}999)), y (-1); los dos bonus distinguen correctamente evidencia tabular de conclusión y valor puntual de límite.

Las preguntas de opción múltiple piden reconocer errores comunes y aplicar la idea a funciones distintas. Las tres preguntas principales cubren el límite con un hueco, la diferencia entre límite y evaluación puntual, y el efecto de cambiar el valor en el punto; los bonus amplían el juicio sobre evidencia y la comparación de funciones. Esto ofrece práctica significativa y manejable. La limitación compartida es que las respuestas son de selección múltiple y no se incluye una explicación de retroalimentación tras contestar. Un lector activo aún puede razonar cada opción, pero una breve explicación de por qué la respuesta correcta lo es —y por qué falla el distractor más tentador— reforzaría el aprendizaje.

La debilidad más importante de B es relativa y acotada: su formulación final de la primera explicación deja menos explícito el vínculo cuantitativo entre las distancias. No hay un error matemático sustantivo en ninguna lección ni un problema importante de alcance. La mención de tolerancias en A sigue siendo informal y está anclada directamente a una igualdad elemental; no introduce la definición épsilon-delta ni convierte la tabla en demostración.

Un lector que prefiera una explicación menos precisa y más conversacional podría encontrar B algo más ligera. Para el público descrito —que trabaja los ejemplos y quiere usar la idea en casos nuevos— A da una guía un poco más concreta sin añadir una carga apreciable. La diferencia es pequeña, por lo que un estilo personal podría invertir la preferencia, aunque no el balance general de evidencia.
