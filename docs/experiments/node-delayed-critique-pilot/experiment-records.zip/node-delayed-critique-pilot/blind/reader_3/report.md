# Evaluación de calidad didáctica

## Puntuaciones

| Criterio | Lección A | Lección B |
|---|---:|---:|
| Claridad conceptual y motivación | 9.5 | 9.7 |
| Andamiaje, ritmo y carga cognitiva | 9.5 | 9.6 |
| Razonamiento trabajado y transferencia | 9.5 | 9.7 |
| Preguntas de aprendizaje activo y oportunidades de retroalimentación | 9.5 | 9.5 |
| Corrección y precisión matemática | 10.0 | 10.0 |
| **Promedio** | **9.6** | **9.7** |

**Ranking:** 1.º Lección B; 2.º Lección A. **Confianza:** media-alta. La diferencia es pequeña: ambas enseñan muy bien el alcance informal del límite y comparten casi toda su secuencia y práctica.

## Evidencia y comparación

Las dos lecciones parten de una discontinuidad removible concreta, con tabla a ambos lados de (2), gráfica y explicación explícita de que la representación no dibuja círculos abiertos. La nota sobre el trazo que puede parecer continuo evita una posible confusión de lectura. Luego, la factorización para (x\ne2) muestra por qué la tabla sugiere (4) y permite extender el razonamiento a todas las entradas permitidas, sin tratar una lista finita como demostración. Esta combinación de exploración y respaldo algebraico es apropiada para el lector descrito.

La ventaja de B está en una frase de cierre del primer ejemplo: «por pequeña que sea la distancia positiva que pidamos entre el resultado y (4), basta tomar una entrada cuya distancia a (2) sea menor que esa misma cantidad». Hace explícito cómo se consigue una precisión arbitraria, en vez de dejar el paso apoyado principalmente en el ejemplo de una milésima. Es una mejora útil para captar qué significa “tan cerca como queramos”, sin introducir la notación ni la definición épsilon-delta. Puede resultar algo más abstracta que A, pero la igualdad previa \(f(x)-4=x-2\) prepara directamente ese razonamiento.

Aun así, A ya explica que la diferencia entre resultado y destino coincide con la distancia de la entrada al punto y que se puede pedir una cercanía mayor. Por eso, la omisión de la frase más general no constituye un defecto sustancial para este nivel: su enseñanza central sigue siendo clara. La ventaja de B es de precisión pedagógica, no una corrección de un error en A.

Ambas desarrollan bien las distinciones esenciales. La segunda sección separa límite, aproximación numérica y valor exacto de una evaluación; además aclara que una función constante también puede tener límite. La tercera aplica la idea al cambiar el valor asignado en el punto, manteniendo el comportamiento cercano. Las preguntas principales comprueban transferencia en contextos nuevos: simplificar otra expresión, evaluar una afirmación sobre una entrada particular y razonar qué pasa al cambiar solo el valor en el punto. Las bonificaciones refuerzan que una tabla finita solo sugiere un candidato y que dos funciones pueden compartir límite pese a valores distintos en el punto. Las respuestas indicadas son correctas.

La fortaleza más marcada de A es su secuencia accesible y su uso eficaz del ejemplo numérico para anclar la explicación. Su debilidad principal, en comparación con B, es que deja menos explicitado el paso desde “puedo acercarme más” hasta “cualquier precisión que solicite”; un lector que necesite esa generalización debe inferirla. La mayor fortaleza de B es cerrar ese hueco con una explicación breve y concreta. Su única pequeña desventaja es que esa oración añade una exigencia de abstracción; para un lector que se beneficia más de una exposición exclusivamente intuitiva, A podría sentirse más ligera.

No encuentro errores matemáticos sustantivos en ninguna lección. Las fórmulas, las conclusiones sobre límites y las respuestas de las preguntas concuerdan. La única preferencia relevante es cuánto explicitud general se quiere en la intuición: B ofrece una base algo más firme para problemas con precisión arbitraria, mientras que A conserva una presentación un poco menos abstracta. La cantidad de preguntas y la extensión similar no influyen en el ranking.
