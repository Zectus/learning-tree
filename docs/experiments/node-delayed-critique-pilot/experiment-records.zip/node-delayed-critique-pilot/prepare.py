from pathlib import Path
import json,hashlib,shutil,uuid,difflib
r=Path(__file__).parent;n=Path('/workspace/lesson-author-f872ca531d');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();log=json.loads((r/'launch-log.json').read_text())
assert sha(n/'limit_intuition.txt')==sha(r/'v1.txt')==log['v1_frozen_before_followup']['sha256']
for f in ['v2.txt','critique.md','revision-notes.md','process.json']:shutil.copyfile(n/f,r/f)
p=json.loads((r/'process.json').read_text());(r/'v1-v2.diff').write_text(''.join(difflib.unified_diff((r/'v1.txt').read_text().splitlines(True),(r/'v2.txt').read_text().splitlines(True),fromfile='v1',tofile='v2')))
m={'node':'limit_intuition','writer_model':'gpt-6.1-sol','writer_effort':'low','grader_model':'gpt-6-luna','conditions':['v1','v2'],'authors':{},'orders':{'reader_1':['v1_01','v2_01'],'reader_2':['v2_01','v1_01'],'reader_3':['v1_01','v2_01'],'reader_4':['v2_01','v1_01']},'packet_sha256':{},'input_sha256':sha(r/'original-prompt.txt')}
for stage in ['v1','v2']:
 a=stage+'_01';d=r/'writers'/a;d.mkdir(parents=True);shutil.copyfile(r/(stage+'.txt'),d/'lesson.txt');m['authors'][a]={'node':'limit_intuition','condition':stage,'pair':'01','source_path':str(r/(stage+'.txt')),'lesson_sha256':sha(r/(stage+'.txt'))}
neutral=Path('/workspace')/('lesson-eval-'+uuid.uuid4().hex[:10]);neutral.mkdir();m['neutral_root']=str(neutral)
for reader,order in m['orders'].items():
 d=neutral/reader;d.mkdir();packet=(r/'reader-context.txt').read_text()
 for label,a in zip('AB',order):packet+='\n\nLESSON '+label+'\n\n'+(r/'writers'/a/'lesson.txt').read_text()
 (d/'packet.txt').write_text(packet);shutil.copyfile(r/'grading-instructions.txt',d/'instructions.txt');m['packet_sha256'][reader]=sha(d/'packet.txt')
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');log['author']['second_turn_status']='completed';(r/'launch-log.json').write_text(json.dumps(log,indent=2)+'\n');print(neutral)
