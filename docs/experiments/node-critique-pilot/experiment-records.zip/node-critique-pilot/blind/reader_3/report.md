# Evaluación comparativa

| Criterio | Lección A | Lección B |
|---|---:|---:|
| Claridad conceptual y motivación | 9.2 | 9.4 |
| Andamiaje, ritmo y carga cognitiva | 9.1 | 9.2 |
| Razonamiento trabajado y transferencia | 9.2 | 9.5 |
| Preguntas y oportunidades de aprendizaje activo | 8.9 | 9.3 |
| Corrección y precisión matemática | 9.8 | 9.8 |
| **Total (promedio)** | **9.24** | **9.44** |

**Ranking:** B > A. **Confianza: alta.** Ambas enseñan bien la idea informal del límite y distinguen correctamente el comportamiento cerca del punto del valor en el punto. La ventaja de B es moderada y se debe a que hace más explícitos los puentes entre representación, razonamiento y transferencia.

La fortaleza principal de A es su explicación directa de por qué una tabla no demuestra un límite: contrasta las filas con la identidad (f(x)-4=x-2), válida para toda entrada permitida distinta de 2. También trata con precisión la limitación de la gráfica (el visor no dibuja círculos abiertos) y separa el valor exacto (f(1{,}99)=3{,}99) del límite exacto. Sus preguntas comprueban distinciones importantes; por ejemplo, la pregunta 3 pide reconocer qué no puede concluirse de cien filas. Su principal debilidad relativa es que la práctica demanda menos variedad de razonamiento: varias preguntas prueban la misma distinción entre límite y valor puntual mediante opciones, y no hay una explicación de respuesta que ayude a corregir una confusión después de responder. Aun así, la pregunta 3 y los dos ejercicios extra ofrecen práctica útil.

B gana por una secuencia algo más guiada. La tabla incluye explícitamente (x=2) como «No definida», luego la gráfica y su limitación, y después la notación y su lectura. A continuación enlaza las distancias (f(x)-4) y (x-2). En la segunda sección, una tabla comparativa distingue valor puntual, salida cercana y límite; esto puede ayudar a fijar una separación central del tema. Las preguntas aprovechan esa estructura: la pregunta 2 pide seguir qué cambia y qué permanece igual al modificar solo (h(3)), y la pregunta 3 interpreta datos que sugieren un límite sin garantizarlo. El ejercicio extra 2 transfiere la idea a dos funciones que coinciden en un entorno perforado. Su debilidad más importante es una leve repetición: la misma distinción entre evidencia numérica y garantía aparece varias veces, y la tabla comparativa vuelve a resumir una explicación ya dada. La repetición es manejable y puede servir de repaso.

No encuentro errores matemáticos sustanciales en ninguna lección. Las cancelaciones se restringen correctamente a entradas distintas del punto excluido; las conclusiones sobre los límites y los valores puntuales son correctas. Ambas explican que una tabla propone un candidato pero no establece por sí sola el comportamiento de todas las entradas cercanas, de acuerdo con el alcance informal solicitado. La precisión matemática alta no elimina del todo pequeñas oportunidades de pulido, como ofrecer retroalimentación razonada a las respuestas.

Un lector que prefiera una exposición más compacta podría elegir A: conserva el razonamiento central con menos recapitulación. Para el lector descrito, que trabaja las preguntas y las representaciones, B ofrece mejores apoyos para afianzar y transferir la idea.
