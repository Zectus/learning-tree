# Evaluación de las lecciones

| Criterio | Lección A | Lección B |
|---|---:|---:|
| Claridad conceptual y motivación | 9.2 | 9.6 |
| Andamiaje, ritmo y carga cognitiva | 9.1 | 9.5 |
| Razonamiento trabajado y transferencia | 9.0 | 9.6 |
| Preguntas y oportunidades de aprendizaje activo | 9.2 | 9.5 |
| Corrección y precisión matemática | 9.7 | 9.8 |
| **Promedio** | **9.24** | **9.60** |

**Clasificación:** B por delante de A. **Confianza:** alta.

Ambas lecciones enseñan bien la idea central: un límite trata de las salidas en entradas próximas y distintas del punto, y puede existir aunque el valor de la función en ese punto falte o sea otro. Las dos parten de una tabla y una gráfica, explican el hueco del trazador y luego justifican el patrón mediante una factorización. Sus tres preguntas principales comprueban distinciones importantes: hallar el candidato, separar límite y valor, y reconocer que una tabla finita no demuestra un límite. No detecté errores matemáticos sustantivos.

B tiene una ventaja de enseñanza concreta en la explicación de las distancias: después de simplificar a (x+1), muestra que (f(x)-2=x-1), de modo que la distancia de la salida a 2 es exactamente la distancia de la entrada a 1. Esto hace visible por qué el patrón continúa para entradas cada vez más cercanas. También anticipa una confusión útil al aclarar que acercarse no requiere que las salidas sean todas distintas ni que se muevan continuamente. La tabla que contrasta las preguntas sobre (f(a)) y sobre el límite es un apoyo compacto y directo. La segunda pregunta de práctica adicional amplía la transferencia a dos funciones que coinciden solo en un entorno perforado, una aplicación valiosa de la idea.

A también desarrolla correctamente una justificación transferible: al cancelar, (f(x)=x+2) para (x\ne2), y una entrada a distancia 0.001 de 2 produce una salida a distancia 0.001 de 4. Su fortaleza es mantener el hilo con claridad y conectar cada parte de la tabla y el gráfico con la interpretación. La debilidad comparativa es que la relación entre las dos distancias se ilustra, pero no se escribe explícitamente como (f(x)-4=x-2); B convierte esa comparación en una regla más fácil de reutilizar. A tampoco aclara expresamente que un límite puede tener salidas iguales al destino o repetidas, y sus ejercicios adicionales refuerzan principalmente variaciones de las distinciones ya presentadas.

La diferencia es de profundidad didáctica, no de corrección. En B, la función por casos explica con precisión qué valor se asigna en el punto y la práctica final permite razonar sobre qué datos locales bastan para conservar un límite. A es más breve y accesible para quien prefiera una exposición menos desarrollada; esa preferencia puede hacer que se sienta más ágil. Para un lector principiante que trabaja los ejemplos y busca herramientas reutilizables, B ofrece mejor apoyo.

La principal limitación menor de ambas es que su notación de límite se introduce informalmente, como corresponde al alcance, sin un ejemplo gráfico que marque físicamente el hueco abierto; el texto explica de forma adecuada la limitación del trazador. No es una deficiencia sustancial para este nodo.
