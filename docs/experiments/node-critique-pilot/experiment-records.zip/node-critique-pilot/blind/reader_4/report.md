# Evaluación de las lecciones

## Puntuaciones

| Criterio | Lección A | Lección B |
|---|---:|---:|
| Claridad conceptual y motivación | 9.4 | 9.3 |
| Andamiaje, ritmo y carga cognitiva | 9.3 | 9.2 |
| Razonamiento desarrollado y transferencia | 9.5 | 9.3 |
| Preguntas y oportunidades de aprendizaje activo | 9.4 | 9.2 |
| Corrección y precisión matemática | 10.0 | 10.0 |
| **Promedio** | **9.52** | **9.40** |

## Ranking

1. **Lección A** — 9.52
2. **Lección B** — 9.40

Confianza: **media-alta**. Ambas son lecciones muy sólidas y la diferencia es moderada, no una brecha fundamental de calidad.

## Evidencia y comparación

Las dos lecciones explican correctamente la idea central con una función que tiene un hueco: comienzan con tabla y gráfica, aclaran la limitación del visor para dibujar un círculo abierto y luego justifican el comportamiento general factorizando. En A, la identidad (f(x)-2=x-1) muestra directamente por qué la salida puede quedar tan cerca de 2 como se quiera. En B, (f(x)-4=x-2) hace el mismo trabajo. Ambas distinguen bien el límite del valor asignado en el punto y de una aproximación numérica, sin introducir la definición formal fuera de alcance.

A queda ligeramente por delante porque desarrolla con más continuidad la diferencia entre datos observados y una afirmación sobre todas las entradas suficientemente cercanas. Su sección 3 contrasta explícitamente la igualdad exacta de una fila, (f(0{,}999)=1{,}999), con el límite exacto 2, y explica qué aporta la relación algebraica que una tabla no puede establecer. La pregunta 3 convierte esa distinción en una decisión concreta ante datos a ambos lados de 4. Sus preguntas también tocan casos diversos: cambiar el valor en el punto, un límite aunque las salidas no igualen el destino y la invariancia al cambiar valores fuera del punto. Es su característica docente más fuerte: enlaza una explicación causal con varios casos transferibles.

B es igualmente clara al separar entorno y punto. Su pregunta 2 requiere simplificar una expresión para encontrar el límite y combinarlo con un valor puntual distinto, un buen ejercicio de aplicación. La sección 3 ofrece una advertencia pertinente sobre una tabla con cien observaciones, y los bonos prueban tanto una relación lineal de distancias como que incluir el punto en el dominio no determina el límite. Su punto más débil, en comparación, es que la práctica principal cubre menos tipos de transferencia: la primera pregunta comprueba sobre todo reconocimiento de una situación compatible y la tercera repite la cautela sobre muestras finitas. La explicación de la sección 2 sí introduce la aproximación concreta, pero A integra esa distinción con más fuerza en su secuencia de enseñanza.

No encuentro errores matemáticos sustantivos en ninguna. La simplificación de las funciones se restringe correctamente a entradas distintas del punto excluido, y ambas presentan sus conclusiones informales dentro del alcance indicado. Las gráficas y las tablas son coherentes con las fórmulas.

La característica más fuerte de B es su explicación compacta y clara del hueco y del valor puntual; su debilidad más importante es la menor variedad de razonamientos que exige la práctica central. Para quien prefiera una lectura más compacta y una pregunta algebraica directa, B podría ser la opción preferida. Para el lector promedio que practica los distintos límites de la idea, A ofrece una secuencia un poco más completa.
