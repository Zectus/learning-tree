from pathlib import Path
from collections import Counter
import hashlib,json,shutil,statistics,sys,uuid

r=Path(__file__).parent;m=json.loads((r/'manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--prepare' in sys.argv:
 assert 'neutral_root' not in m
 for a,meta in m['authors'].items():
  if meta.get('reused_from'):continue
  n=Path(meta['neutral_dir']);lesson=n/'lesson.txt'
  assert lesson.exists() and lesson.stat().st_size
  for name,h in meta['input_files_sha256'].items():assert sha(n/name)==h
  shutil.copyfile(lesson,r/'writers'/a/'lesson.txt');meta['lesson_sha256']=sha(lesson)
  for f in ['draft.txt','critique.md','revision-notes.md','process.json']:shutil.copyfile(n/f,r/'writers'/a/f)
  process=json.loads((n/'process.json').read_text());assert process['pre_critique_draft_sha256']==sha(n/'draft.txt')
 n=Path('/workspace')/('lesson-eval-'+uuid.uuid4().hex[:10]);n.mkdir();m['neutral_root']=str(n)
 for reader,order in m['orders'].items():
  d=n/reader;d.mkdir();packet=(r/'reader-context.txt').read_text()
  for label,a in zip('AB',order):packet+='\n\nLESSON '+label+'\n\n'+(r/'writers'/a/'lesson.txt').read_text()
  (d/'packet.txt').write_text(packet);shutil.copyfile(r/'grading-instructions.txt',d/'instructions.txt');m['packet_sha256'][reader]=sha(d/'packet.txt')
 (r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(n);sys.exit()

criteria=['conceptual_clarity','scaffolding','worked_reasoning_transfer','active_learning','correctness']
samples={a:[] for a in m['authors']};panels={};math_errors=[];preference=Counter({'current_wins':0,'critique_revision_wins':0,'ties':0})
for reader,order in m['orders'].items():
 n=Path(m['neutral_root'])/reader;assert sha(n/'packet.txt')==m['packet_sha256'][reader]
 d=json.loads((n/'scores.json').read_text());assert set(d['scores'])==set('AB');assert sorted(x for g in d['ranking'] for x in g)==list('AB')
 dest=r/'blind'/reader;dest.mkdir(parents=True,exist_ok=True)
 for f in ['report.md','scores.json']:shutil.copyfile(n/f,dest/f)
 for pos,(label,a) in enumerate(zip('AB',order)):
  q=d['scores'][label];assert all(isinstance(q[k],(int,float)) and 0<=q[k]<=10 for k in criteria)
  mean=statistics.mean(q[k] for k in criteria)
  if abs(mean-q['overall'])>.051:math_errors.append({'reader':reader,'label':label,'reported':q['overall'],'computed':mean})
  samples[a].append({'reader':reader,'position':pos,'reported_overall':q['overall'],**q,'overall':mean})
 groups=[[m['authors'][order['AB'.index(l)]]['condition'] for l in group] for group in d['ranking']]
 if len(groups[0])==2:preference['ties']+=1
 else:preference[groups[0][0]+'_wins']+=1
 panels[reader]={'order':order,'ranking':d['ranking'],'condition_ranking':groups,'confidence':d['confidence'],'decisive_tradeoff':d['decisive_tradeoff']}
summary={}
for a,ratings in samples.items():
 meta=m['authors'][a];assert len(ratings)==2 and set(q['position'] for q in ratings)=={0,1};assert sha(r/'writers'/a/'lesson.txt')==meta['lesson_sha256']
 summary[a]={'condition':meta['condition'],'replicate':meta['replicate'],'means':{k:statistics.mean(q[k] for q in ratings) for k in criteria+['overall']},'ratings':ratings}
condition={c:{k:statistics.mean(q['means'][k] for q in summary.values() if q['condition']==c) for k in criteria+['overall']} for c in m['conditions']}
out={'condition_means':condition,'pairwise_preferences':dict(preference),'samples':summary,'panels':panels,'arithmetic_discrepancies':math_errors}
(r/'aggregate.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'condition_means':condition,'pairwise_preferences':dict(preference),'arithmetic_discrepancies':math_errors},indent=2))
