from pathlib import Path
import hashlib,json,re,shutil,zipfile

r=Path(__file__).parent;app=Path('/workspace/learning-tree');m=json.loads((r/'manifest.json').read_text());l=json.loads((r/'launch-log.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(app/'js/learn/node-prompt.js')==m['source_sha256']
assert all(q['status']=='completed' for q in l['authors']+l['graders'])
obs=json.loads((r/'stage-observations.json').read_text())['hashes_observed_by_root_while_critics_running']
for a,q in m['authors'].items():
 d=r/'writers'/a;assert sha(d/'lesson.txt')==q['lesson_sha256'];assert sha(d/'input.txt')==q['input_sha256']
 if q.get('reused_from'):
  origin=Path(q['reused_from']['study'])/'writers'/q['reused_from']['author']/'lesson.txt';assert (d/'lesson.txt').read_bytes()==origin.read_bytes()
 else:
  p=json.loads((d/'process.json').read_text());assert p['pre_critique_draft_sha256']==obs[a]==sha(d/'draft.txt');assert p['critic_final_status']=='completed';args=p['critic_spawn_arguments'];assert args['model']=='gpt-6-luna' and args['fork_turns']=='none' and 'reasoning_effort' not in args
  assert sha(d/'lesson.txt')!=sha(d/'draft.txt')
  assert (d/'input.txt').read_bytes()==(r/'idea-2-prompt.txt').read_bytes()
for reader in m['orders']:
 d=Path(m['neutral_root'])/reader;assert sha(d/'packet.txt')==m['packet_sha256'][reader]
 for f in ['report.md','scores.json']:assert (d/f).read_bytes()==(r/'blind'/reader/f).read_bytes()
assert (r/'idea-2-prompt.txt').read_text()==(r/'base-prompt.txt').read_text()+(r/'prompt-addition.txt').read_text()
assert len({q['input_sha256'] for q in m['authors'].values() if not q.get('reused_from')})==1
struct=json.loads((r/'structural-audit.json').read_text());assert all(q['complete'] and q['questionsValid'] and all(not g['errors'] for g in q['graphs']) for q in struct.values())
keys=sum(len(re.findall(r'^\[(?:QUESTION|BONUS) \d+\]',(r/'writers'/a/'lesson.txt').read_text(),re.M)) for a in m['authors']);assert keys==20
(r/'completion-checks.json').write_text(json.dumps({'new_authors':2,'reused_controls':2,'fresh_critics':2,'fresh_blind_final_graders':4,'all_jobs_confirmed_complete':True,'controls_byte_identical':True,'new_prompt_is_base_plus_addition_only':True,'same_new_input_both_replicates':True,'draft_hashes_observed_during_critique_match_after_revision':True,'actual_luna_critics_completed_before_revisions':True,'all_final_packet_and_lesson_hashes_valid':True,'all_four_pairings_and_positions_balanced':True,'all_structure_checks_pass':True,'final_keys_checked':keys,'production_prompt_unchanged':True},indent=2)+'\n')
shutil.copyfile('/workspace/build_node_critique_pilot.py',r/'build.py')
out=r/'experiment-records.zip';files=[p for p in sorted(r.rglob('*')) if p.is_file() and p.suffix!='.zip' and p.name!='archive.sha256']
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,'node-critique-pilot/'+str(p.relative_to(r)))
 for p in sorted(Path(m['neutral_root']).rglob('*')):
  if p.is_file():z.write(p,'node-critique-pilot/grading-packets/'+str(p.relative_to(m['neutral_root'])))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for reader in m['orders']:assert hashlib.sha256(z.read('node-critique-pilot/grading-packets/'+reader+'/packet.txt')).hexdigest()==m['packet_sha256'][reader]
(r/'archive.sha256').write_text(sha(out)+'  experiment-records.zip\n')
docs=app/'docs/experiments/node-critique-pilot';docs.mkdir(parents=True,exist_ok=True)
for name in ['README.md','idea-2-prompt.txt','prompt-addition.txt','protocol.md','aggregate.json','content-audit.md','completion-checks.json','experiment-records.zip','archive.sha256']:shutil.copyfile(r/name,docs/name)
print(json.dumps({'report':str(docs/'README.md'),'candidate_prompt':str(docs/'idea-2-prompt.txt'),'archive_bytes':out.stat().st_size,'all_checks_pass':True,'production_prompt_unchanged':True},indent=2))
