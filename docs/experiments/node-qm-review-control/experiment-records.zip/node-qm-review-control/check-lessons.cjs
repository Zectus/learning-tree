const fs=require('fs'),path=require('path');
const {loadApp}=require('/workspace/learning-tree/test/harness');const format=require('/workspace/learning-tree/js/learn/generation-format');
const root=process.argv[2],m=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8')),app=loadApp();const result={};
try{
for(const [id,meta] of Object.entries(m.authors)){
 const text=fs.readFileSync(path.join(root,'writers',id,'lesson.txt'),'utf8');app.window.auditText=text;
 const parse=app.ev('parseTxtSession(auditText)');const checks={node:meta.node,condition:meta.condition,complete:format.lessonIsComplete(text),sectionCount:parse.sections.length,mainCount:parse.questions.size,bonusCount:parse.bonuses.size,questionsValid:[...parse.questions.values(),...parse.bonuses.values()].every(q=>q.valid),graphs:[]};
 for(const match of text.matchAll(/\[GRAPH\]([\s\S]*?)\[\/GRAPH\]/g)){
  app.window.auditGraphText=match[1];const g=app.ev('parseGraphBody(auditGraphText)');const errors=[];
  const required=g.type==='function2d'?['xrange']:g.type==='parametric2d'?['trange']:['xrange','yrange'];
  for(const key of required)if(!g[key]||g[key].length!==2||!g[key].every(Number.isFinite)||g[key][0]>=g[key][1])errors.push('invalid/missing '+key);
  const expressions=[];
  if(g.type==='surface3d')expressions.push(g.z);else if(g.type==='vectorfield2d')expressions.push(g.u,g.v);else for(const tr of g.traces){app.window.auditExpr=tr.expr;expressions.push(...(g.type==='parametric2d'?app.ev('splitTopLevelComma(auditExpr)'):[tr.expr]));}
  for(const q of [...g.points,...g.segments]){app.window.auditExpr=q.expr;expressions.push(...app.ev('splitTopLevelComma(auditExpr)'));}
  const scope={x:(g.xrange?.[0]??0)+.37*((g.xrange?.[1]??1)-(g.xrange?.[0]??0)),y:.37,t:(g.trange?.[0]??0)+.37*((g.trange?.[1]??1)-(g.trange?.[0]??0))};
  for(const slider of g.sliders)scope[slider.expr]=Number(slider.init);
  for(const expr of expressions){if(!expr){errors.push('missing expression');continue;}app.window.auditExpr=expr;app.window.auditScope=scope;try{app.ev('compileGraphExpr(auditExpr).evaluate(JSON.parse(JSON.stringify(auditScope)))');}catch(e){errors.push(expr+': '+e.message);}}
  checks.graphs.push({type:g.type,title:g.title,errors});
 }
 result[id]=checks;
}
}finally{app.window.close();}
fs.writeFileSync(path.join(root,'structural-audit.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({outputs:Object.keys(result).length,structurallyIncomplete:Object.entries(result).filter(([id,q])=>!q.complete||!q.questionsValid).map(([id])=>id),graphIssues:Object.entries(result).flatMap(([id,q])=>q.graphs.flatMap((g,i)=>g.errors.length?[{id,graph:i+1,errors:g.errors}]:[]))},null,2));
