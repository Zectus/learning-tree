# Revision notes

Accepted the critic’s two narrow clarifications: explicitly identified the joint matrix row and column label pairs before the trace derivation, and connected local projectors to outcomes of projective measurements in Section 3.

Did not introduce general measurement effects: the reader context reserves generalized measurements for a later lesson. Did not add a new checkpoint question, graph, or derivation; the existing examples and questions already provide useful checks, and extra material would add redundancy.

Preserved all examples, derivations, questions, answer keys, section structure, and app markup. No mathematical correction was warranted. Independently checked the contraction identities, basis-change conjugation, positivity argument, product reduction, numerical examples, and every answer key. Numerical calculations verified phase-sensitive reductions, local probabilities, purity, and the joint-probability contrast. Structural checks confirmed one answer tag and five options per question.

completed.txt was preserved byte for byte; its SHA-256 is recorded in process.json. One independent critic was used, and its saved review was read before these edits.
