# Revision notes

Accepted and applied:
- Explained the tensor-bra action on a product ket immediately after the sandwich formula, so the unfamiliar operation has a concrete meaning before use in the basis-independence argument.
- Expanded the worked off-diagonal entry into its two amplitude products before evaluating it, connecting the recipe to the surviving coherence.

Rejected as unnecessary:
- Additional questions, graphs, or longer treatment of mixed joint states and entanglement. The general index derivation already covers mixed inputs, the existing questions cover the central abilities, and symbolic matrix operations do not need a geometric plot.
- Changes to answer tags, calculations, section order, or scope: independent checking found no mathematical error.

The full final lesson is in lesson.txt. completed.txt was read only and preserved exactly. All original app markup and question content are preserved.
