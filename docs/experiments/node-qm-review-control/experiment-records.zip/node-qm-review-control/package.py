from pathlib import Path
from collections import Counter
import hashlib,json,shutil,zipfile,itertools
r=Path(__file__).parent;app=Path('/workspace/learning-tree');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((r/'manifest.json').read_text());log=json.loads((r/'launch-log.json').read_text());agg=json.loads((r/'aggregate.json').read_text())
assert len(log['revision_agents'])==2 and all(q['status']=='completed' for q in log['revision_agents'])
assert len(log['graders'])==6 and all(q['status']=='completed' for q in log['graders'])
for q in log['revision_agents']:
 a=q['spawn_arguments'];assert a['model']=='gpt-6.1-sol' and a['reasoning_effort']=='low' and a['fork_turns']=='none' and a['message']==m['wrappers'][q['condition']]
for q in log['graders']:
 a=q['spawn_arguments'];assert a['model']=='gpt-6-luna' and a['fork_turns']=='none' and 'reasoning_effort' not in a
original=m['original_source'];s=Path(original['study'])/'writers'/original['author'];assert sha(s/'lesson.txt')==sha(r/'original.txt')==m['authors']['original']['lesson_sha256']
assert sha(s/'prompt.txt')==sha(r/'original-prompt.txt')==sha(Path('/workspace/qm-current-render-check/writers/task_01/prompt.txt'))
assert sha(app/'js/learn/node-prompt.js')==original['metadata']['variant_sha256']
source=json.loads((r/'original-writer-provenance.json').read_text());assert source['status']=='completed' and source['spawn_arguments']['model']=='gpt-6.1-sol' and source['spawn_arguments']['reasoning_effort']=='low' and source['first_complete_sha256']==sha(r/'original.txt')
for c,folder in m['revision_directories'].items():
 n=Path(folder);assert sha(n/'completed.txt')==sha(r/'original.txt');assert sha(n/'input.txt')==sha(r/'original-prompt.txt');assert (n/'reader-context.txt').read_bytes()==(r/'reader-context.txt').read_bytes()
 for name in ['lesson.txt','review.md','revision-notes.md']:assert (n/name).read_bytes()==(r/'writers'/c/name).read_bytes()
 assert sha(r/'writers'/c/'lesson.txt')==m['authors'][c]['lesson_sha256']
p=json.loads((r/'writers/luna_review/process.json').read_text());a=p['critic_spawn_arguments'];assert a['model']=='gpt-6-luna' and a['fork_turns']=='none' and 'reasoning_effort' not in a
assert a['message']==(r/'critic-prompt.txt').read_text().rstrip('\n') and p['critic_final_completion_status']=='completed' and p['completed_txt_sha256']==sha(r/'original.txt') and p['review_count']==1 and p['review_read_before_revision']
assert set(tuple(o) for o in m['orders'].values())==set(itertools.permutations(m['conditions']))
for reader,order in m['orders'].items():
 d=Path(m['neutral_root'])/reader;assert sha(d/'packet.txt')==m['packet_sha256'][reader]
 expected=(r/'reader-context.txt').read_text()
 for label,c in zip('ABC',order):expected+='\n\nLESSON '+label+'\n\n'+(r/'writers'/c/'lesson.txt').read_text()
 assert (d/'packet.txt').read_text()==expected
 assert (d/'instructions.txt').read_bytes()==(r/'grading-instructions.txt').read_bytes()
 for f in ['report.md','scores.json']:assert (d/f).read_bytes()==(r/'blind'/reader/f).read_bytes()
assert not agg['reported_overall_differences']
struct=json.loads((r/'structural-audit.json').read_text());assert len(struct)==3 and all(q['complete'] and q['questionsValid'] for q in struct.values())
math=json.loads((r/'math-audit.json').read_text());assert math['all_exact_checks_pass'] and math['questions_unchanged'] and math['underlying_questions']==6
checks={'reused_originals':1,'original_selected_by_replicate_not_score':True,'original_prompt_byte_identical_to_current_app_render':True,'new_sol_revision_agents':2,'both_sol_6_1_low_and_fresh_history':True,'identical_original_inputs_in_both_branches':True,'starting_lesson_immutable':True,'one_real_fresh_luna_critic_completed':True,'six_fresh_blind_luna_graders_completed':True,'all_six_orders_used':True,'each_version_twice_per_position':True,'packet_and_output_hashes_valid':True,'all_six_underlying_question_keys_checked':True,'all_eighteen_key_occurrences_unchanged':True,'all_structure_checks_pass':True,'exact_math_checks_pass':True,'grade_arithmetic_exact':True,'grader_attribution_errors_documented_without_rescore_or_exclusion':True,'production_prompt_unchanged':True}
(r/'completion-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
for c in ['self_review','luna_review']:shutil.copyfile(r/'writers'/c/'lesson.txt',r/(c+'.txt'))
shutil.copyfile('/workspace/node-prompt-optimization/lib/check-lessons.cjs',r/'check-lessons.cjs')
shutil.copyfile('/workspace/node-prompt-optimization/lib/render.mjs',r/'render.mjs')
(r/'current-render-config.json').write_bytes(Path('/workspace/qm-current-render-check/config.json').read_bytes())
out=r/'experiment-records.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(r.rglob('*')):
  if f.is_file() and f.suffix!='.zip' and f.name!='archive.sha256':z.write(f,'node-qm-review-control/'+str(f.relative_to(r)))
 for f in sorted(Path(m['neutral_root']).rglob('*')):
  if f.is_file():z.write(f,'node-qm-review-control/grading-packets/'+str(f.relative_to(m['neutral_root'])))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for reader in m['orders']:assert hashlib.sha256(z.read('node-qm-review-control/grading-packets/'+reader+'/packet.txt')).hexdigest()==m['packet_sha256'][reader]
(r/'archive.sha256').write_text(sha(out)+'  experiment-records.zip\n')
docs=app/'docs/experiments/node-qm-review-control';docs.mkdir(parents=True,exist_ok=True)
for f in ['README.md','protocol.md','original-prompt.txt','original.txt','self_review.txt','luna_review.txt','critic-prompt.txt','aggregate.json','content-audit.md','math-audit.json','completion-checks.json','experiment-records.zip','archive.sha256']:shutil.copyfile(r/f,docs/f)
print(json.dumps({'all_checks_pass':True,'archive_bytes':out.stat().st_size,'report':str(docs/'README.md')},indent=2))
