from pathlib import Path
import sympy as s,json,re
r=Path(__file__).parent;I=s.I

def pure(v):return v*v.conjugate().T

def ptrace(M,na,nb):return s.Matrix(na,na,lambda a,ap:s.simplify(sum(M[a*nb+b,ap*nb+b] for b in range(nb))))

def purity(M):return s.simplify(s.trace(M*M))

def prob(M,v):return s.simplify((v.conjugate().T*M*v)[0])
chi=s.Matrix([1,0,1,1])/s.sqrt(3);rho=ptrace(pure(chi),2,2);assert rho==s.Matrix([[1,1],[1,2]])/3
plus=s.Matrix([1,1])/s.sqrt(2);assert prob(rho,plus)==s.Rational(5,6)
opening=s.Matrix([s.sqrt(3)/2,0,0,s.Rational(1,2)]);op=ptrace(pure(opening),2,2);assert op==s.diag(s.Rational(3,4),s.Rational(1,4)) and purity(op)==s.Rational(5,8)
q1=s.Matrix([1,I,0,1])/s.sqrt(3);assert ptrace(pure(q1),2,2)==s.Matrix([[2,I],[-I,1]])/3
q2=s.Matrix([[s.Rational(1,2),-I/4],[I/4,s.Rational(1,2)]]);assert prob(q2,s.Matrix([1,I])/s.sqrt(2))==s.Rational(3,4)
# General phase cancellation for arbitrary complex local vectors in Q3.
z=s.Symbol('z',complex=True);v0=s.Matrix(s.symbols('a0 a1',complex=True));v1=s.Matrix(s.symbols('b0 b1',complex=True));theta=s.symbols('theta',real=True)
wplus=(v0+s.exp(-I*theta)*v1)/s.sqrt(2);wminus=(v0-s.exp(-I*theta)*v1)/s.sqrt(2)
assert (pure(wplus)+pure(wminus)-pure(v0)-pure(v1)).applyfunc(s.simplify)==s.zeros(2)
singlet=s.Matrix([0,1,-1,0])/s.sqrt(2);mix=s.diag(0,s.Rational(1,2),s.Rational(1,2),0);pp=s.kronecker_product(plus,plus)
assert purity(ptrace(pure(singlet),2,2))==purity(ptrace(mix,2,2))==s.Rational(1,2)
assert prob(pure(singlet),pp)==0 and prob(mix,pp)==s.Rational(1,4)
b1=s.Matrix([1,0,1,0,1,1])/2;br=ptrace(pure(b1),2,3);assert br==s.Matrix([[s.Rational(1,2),s.Rational(1,4)],[s.Rational(1,4),s.Rational(1,2)]]) and purity(br)==s.Rational(5,8)
p=s.symbols('p',real=True);b2=s.diag(p,1-p);assert prob(b2,plus)==s.Rational(1,2)
# Every question block is byte-for-byte unchanged across all three versions.
blocks=lambda t:re.findall(r'\[(?:QUESTION|BONUS) \d+\][\s\S]*?\[/(?:QUESTION|BONUS)\]',t)
base=blocks((r/'original.txt').read_text());assert len(base)==6
for c in ['original','self_review','luna_review']:assert blocks((r/'writers'/c/'lesson.txt').read_text())==base
result={'all_exact_checks_pass':True,'worked_reduction':str(rho),'worked_plus_probability':'5/6','opening_local_purity':'5/8','question_keys':['C','D','B','A','E','C'],'underlying_questions':6,'key_occurrences_across_three_versions':18,'questions_unchanged':True,'q1_reduction':str(ptrace(pure(q1),2,2)),'q2_probability':'3/4','q3_phase_cancellation_symbolically_verified':True,'q4_joint_probabilities':['0','1/4'],'bonus1_purity':'5/8','bonus2_probability':'1/2','method':'SymPy exact arithmetic for examples and symbolic phase cancellation; root separately read general derivations, scope, distractors and edits.'}
(r/'math-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
