# Evaluation: Partial Trace and Reduced Density Operators

## Scores

| Lesson | Conceptual clarity | Scaffolding | Worked reasoning and transfer | Active learning | Correctness | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.5 | 9.2 | 9.6 | 9.1 | 10.0 | 9.48 |
| B | 9.6 | 9.3 | 9.6 | 9.2 | 10.0 | 9.54 |
| C | 9.5 | 9.2 | 9.6 | 9.1 | 10.0 | 9.48 |

**Ranking:** B > A = C. **Confidence:** High that all three teach the scope well; moderate that B's small wording gains merit the narrow lead.

## Evidence and tradeoffs

All three begin with the same useful motivation: keep only the state needed for measurements on accessible system A, while explicitly saying that reduction is a calculation and does not select an outcome or collapse the joint state. The opening state then connects local probabilities to a reduced matrix for arbitrary local outcomes. This prepares the reader for the general construction rather than presenting a formula without a reason.

The shared core is strong and mathematically sound. The trace expansion shows why the environment index is summed while the local row and column survive; the pure-state formula ρ_A[ a,a' ] = Σ_b c_ab c*_{a'b} supports a worked example with surviving local coherence. The lessons also verify local predictions in a superposition basis, show invariance under a change of discarded-system basis, and contrast a mixed reduction with a pure entangled joint state. The examples and questions cover phases, local probabilities, basis changes, and the danger of treating a reduced state as preserving joint correlations. I found no substantive mathematical or scope error.

**B** earns a narrow lead. It tells the reader explicitly that the joint-matrix row is labeled by (a,b) and its column by (a',b'), and it spells out that the projector identity preserves each outcome probability of a local projective measurement. Those additions make two important index and scope points easier to locate. B also trims A's/C's explanation of how the sandwich factor acts on a product ket; that sentence was a useful concrete unpacking, so the lead is small rather than decisive. B's strongest feature is this extra labeling and explicit connection to outcome probabilities. Its main weakness, shared across the set, is that multiple-choice answers provide little worked feedback explaining why a tempting alternative is wrong.

**A and C** are effectively tied: their teaching content and questions match, apart from their lesson labels. Their strongest feature is the same explicit unpacking of the sandwich expression, which explains how the environment bra leaves a vector on A. Their main weakness is that the index notation is introduced without B's direct reminder of which pair labels the row and which labels the column; a careful reader can infer it from the definition, but that inference adds friction. A and C retain a correct statement that the identity holds for every local projector, though they do not add B's sentence linking each projective-measurement outcome to that identity.

Across all three, the pacing is purposeful but dense: the general trace derivation, positivity argument, and unitary basis-change proof ask the reader to track several indices and operators. The examples and plain-language reminders keep this manageable for the stated learner, who already knows trace-based probability calculations. The questions are achievable and meaningful, including calculations and conceptual distinctions; explanatory answer feedback would make them more useful for diagnosing mistakes. These are refinements to an otherwise complete lesson, not substantial teaching failures. A learner who prefers a more explicit ket-level explanation may prefer A or C; one who benefits most from explicit index labels and a direct probability statement may prefer B.
