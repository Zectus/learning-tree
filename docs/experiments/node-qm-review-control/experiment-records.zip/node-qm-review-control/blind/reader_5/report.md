# Independent lesson evaluation

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding and pacing | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.4 | 9.1 | 9.3 | 9.0 | 10.0 | 9.36 |
| B | 9.2 | 9.0 | 9.2 | 9.0 | 10.0 | 9.28 |
| C | 9.5 | 9.3 | 9.6 | 9.0 | 10.0 | 9.48 |

**Ranking:** C > A > B. **Confidence:** High that all three teach the target accurately and effectively; moderate on the close ordering of A and C, whose differences are small.

## Evidence and tradeoffs

All three lessons start with a concrete entangled state, establish that a local density operator must reproduce probabilities beyond the computational basis, and carefully distinguish a partial trace from a measurement or collapse. They then derive the index rule, demonstrate surviving local coherence, verify a local probability two ways, establish basis independence, and explain mixed local states alongside pure joint states. This is a sound teaching arc for the stated background. The main cognitive cost is the long, notation-heavy derivation; an actively engaged learner can follow it, but several consecutive abstract identities demand attention.

**Lesson C ranks first.** Its strongest feature is the explicit bridge from the sandwich expression to an action on a product basis vector: “(I_A ⊗ ⟨b|)|ac⟩ = ⟨b|c⟩|a⟩” makes the partial trace expression more interpretable rather than leaving it as formal notation. It also spells out the worked off-diagonal entry as “c₀₀c₁₀* + c₀₁c₁₁*,” connecting the rule directly to the example and making the surviving coherence easy to audit. Its main weakness is that it remains dense: this added explanation sits inside a section already containing a trace expansion, matrix-entry rule, and two equivalent constructions. The lesson also offers no explanatory answer feedback in the visible question text. These are manageable limits, not correctness problems.

**Lesson A ranks a close second.** Its strongest teaching feature is its especially careful orientation to the indices: it says explicitly that the row is labeled by a,b, the column by a′,b′, and the primes distinguish labels. It also directly says that every local projective outcome is represented by a projector and hence has its probability preserved. These small explanations make the formal proof easier to enter and interpret. Its most important weakness relative to C is that two useful derivation links are compressed: the bra-ket sandwich is not unpacked on a product vector, and the worked coherence entry is abbreviated to “1/3 + 0” rather than showing which amplitudes contribute. A reader can still reconstruct both from the surrounding definitions, but C better supports independent calculation.

**Lesson B ranks third, narrowly.** It has the same accurate central derivation and useful examples as A, with strong practice on complex phases, local probabilities, basis changes, and distinguishing local from joint predictions. Its strongest feature is this breadth of practice: the main questions and two bonus items ask the learner to use the rule in varied settings. Its most important weakness is a pair of removals that make the main argument slightly less explicit than A: it omits the row/column label orientation and the sentence explaining that each local projective outcome is included in the probability-preservation claim. Neither omission makes the math wrong, but they leave a first-time reader with fewer signposts in a symbol-heavy passage. C adds helpful explanation to this same version, which puts B a little behind.

The mathematical content and answer keys are consistent across the lessons. For example, the complex off-diagonal term in Question 1 follows from multiplying amplitudes with the same environment index; the 5/6 probability for |+⟩ in the worked state agrees with both reduced and joint calculations; the changed-environment-basis sum cancels its cross terms; and Question 4 correctly preserves local purity while distinguishing a joint measurement. I found no substantive correctness or scope error. The active-learning set is meaningful and achievable, but answers are multiple choice and the packet supplies no worked feedback after a response, so the learner must use the derivations to diagnose mistakes.

A learner who prefers compact prose and already feels comfortable tracking paired indices might prefer B's slightly leaner presentation. A learner who benefits from explicit notation cues may prefer A. For the stated average first-time learner, C's concrete unpacking of the key operation and its explicit amplitude calculation make it the strongest choice overall.
