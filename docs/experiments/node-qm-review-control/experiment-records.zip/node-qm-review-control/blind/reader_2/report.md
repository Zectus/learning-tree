# Independent lesson evaluation

## Scores

| Lesson | Conceptual clarity and motivation | Scaffolding, pacing, cognitive load | Worked reasoning and transfer | Active learning | Correctness and precision | Overall |
|---|---:|---:|---:|---:|---:|---:|
| A | 9.3 | 9.0 | 9.2 | 9.4 | 10.0 | 9.38 |
| B | 9.4 | 9.3 | 9.4 | 9.4 | 10.0 | 9.50 |
| C | 9.5 | 9.5 | 9.6 | 9.4 | 10.0 | 9.60 |

**Ranking:** C > B > A. **Confidence:** moderately high. The lessons share the same strong core, and the ranking rests on small differences in how explicitly they unpack a few steps, not on a major gap in teaching quality.

## Evidence and tradeoffs

All three lessons motivate the reduction with a useful local-measurement question, start from an entangled two-qubit state, and correctly distinguish a calculation from a physical measurement or collapse. The trace expansion explains why the environment index is matched and summed, and the formula for pure-state entries is followed by a coherent example. The later comparison of local and joint purity addresses the central conceptual point: the subsystem can be mixed while the joint state remains pure. The alternative-basis derivation and the χ example make basis independence concrete. Their four main questions test complex conjugation and index handling, local probability prediction, invariance under a basis change, and the difference between preserving local and joint predictions. Bonus problems extend practice to a three-dimensional environment and a mixed joint preparation.

**Lesson C ranks first.** Its strongest feature is the extra unpacking at the points most likely to trip up a first-time learner: it explicitly evaluates the bra-ket sandwich on a product basis vector, says the right-hand factor performs the matching operation, and writes the actual terms in the worked off-diagonal entry, (c_{00}c_{10}^*+c_{01}c_{11}^*). These additions make it easier to connect the abstract operator formula to the index rule without changing the mathematical level. The important weakness is modest: the derivation is still notation-dense, and much of the justification is compact symbolic work. An engaged learner can follow it, but may need to pause and track indices. No substantive mathematical error stood out.

**Lesson B ranks second.** Its strongest feature is orientation and scope: it explicitly identifies the joint matrix row and column as paired labels and clarifies that the local-projector identity preserves each outcome of a local projective measurement. Those details help prevent index swaps and sharpen the claim. Its main weakness, relative to C, is that the sandwich expression and the example's off-diagonal arithmetic are less fully narrated; a learner who loses track of which tensor factor a bra acts on has to infer that step. The example gives the result and the reason the coherence survives, so this is a small scaffolding gap, not a mathematical defect.

**Lesson A ranks third, closely.** Its strongest feature is an especially direct motivation: it first checks a candidate local state against an arbitrary superposition-basis outcome, making clear why matching computational-basis probabilities alone is insufficient. The rest supplies a rigorous derivation, useful worked examples, and an appropriate set of questions. Its main weakness is that the matrix-entry notation is introduced with less orientation than in B, and its worked off-diagonal entry is compressed to (1/3+0) without showing the amplitude products. That leaves more reconstruction to the learner. The derivation remains correct and usable for the stated audience.

Correctness is strong across the set. In particular, the complex off-diagonal term in Question 1 has the stated sign under ((\rho_A)_{aa'}=\sum_b c_{ab}c_{a'b}^*\); Question 2 gives (3/4) for the displayed (y+) outcome; and the worked χ example gives (p(+)=5/6). The purity values and the singlet-versus-mixture comparison are also consistent. The lessons correctly caution that a reduced state does not preserve joint correlations and that local mixedness by itself does not prove entanglement. I found no substantial scope or correctness error. The main limitation shared across the lessons is density: the index proof, positivity argument, and unitary-basis proof arrive in succession. The stated prerequisites make this manageable for an active learner, though some readers will want to work each line rather than read straight through.

A learner who prefers a very direct opening and is already comfortable with index notation may prefer A. A learner who especially values explicit explanation of notation and algebra is more likely to benefit from C; B offers a middle ground with particularly clear row/column labeling. These preferences could narrow the practical choice, while C remains the strongest overall for the stated first-time learner.
