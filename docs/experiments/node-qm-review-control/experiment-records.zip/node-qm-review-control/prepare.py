from pathlib import Path
import json,hashlib,shutil,uuid,difflib
r=Path(__file__).parent;m=json.loads((r/'manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert 'neutral_root' not in m
for c,folder in m['revision_directories'].items():
 n=Path(folder);assert sha(n/'completed.txt')==m['authors']['original']['lesson_sha256'];assert sha(n/'input.txt')==sha(r/'original-prompt.txt');assert (n/'reader-context.txt').read_bytes()==(r/'reader-context.txt').read_bytes()
 for name in ['lesson.txt','review.md','revision-notes.md']:shutil.copyfile(n/name,r/'writers'/c/name)
 if c=='luna_review':shutil.copyfile(n/'process.json',r/'writers'/c/'process.json')
 m['authors'][c]['lesson_sha256']=sha(r/'writers'/c/'lesson.txt')
 (r/'writers'/c/'changes.diff').write_text(''.join(difflib.unified_diff((r/'original.txt').read_text().splitlines(True),(n/'lesson.txt').read_text().splitlines(True),fromfile='original',tofile=c)))
n=Path('/workspace')/('lesson-eval-'+uuid.uuid4().hex[:10]);n.mkdir();m['neutral_root']=str(n)
for reader,order in m['orders'].items():
 d=n/reader;d.mkdir();packet=(r/'reader-context.txt').read_text()
 for label,a in zip('ABC',order):packet+='\n\nLESSON '+label+'\n\n'+(r/'writers'/a/'lesson.txt').read_text()
 (d/'packet.txt').write_text(packet);shutil.copyfile(r/'grading-instructions.txt',d/'instructions.txt');m['packet_sha256'][reader]=sha(d/'packet.txt')
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');log=json.loads((r/'launch-log.json').read_text())
for q in log['revision_agents']:q['status']='completed'
(r/'launch-log.json').write_text(json.dumps(log,indent=2)+'\n');print(n)
